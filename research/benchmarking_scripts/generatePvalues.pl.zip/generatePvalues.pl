#!/usr/bin/perl
#
#by Kristin Y. Rozier
#01/24/2005
#
#This software has been determined to be outside the scope of NASA NPG 2210 and therefore is not considered as controlled software.
#
#This program may be freely redistributed and/or modified under the terms of the enclosed software agreement. NASA is neither liable nor responsible for maintenance, updating, or correction of any errors in the software provided. Use of this software shall not be construed to constitute the grant of a license to the user under any NASA patent, patent application or other intellectual property.
#
#You should have received a software agreement along with this program. If not, please refer to Section 4 of: http://opensource.arc.nasa.gov/pdf/NASA_Open_Source_Agreement_1.3.txt
############################################################################
# generatePvalues.pl
#
#This program spits out a Promela program to feed into SPIN which causes SPIN to nondeterministically choose all possible value combinations for all of the possible boolean variables. With no flags, the simple (though exponential in the number of variables) model is produced. The -r flag produces a reduced (but not universal) version of this model and the -l flag produces a linearly-sized version with the same (full) functionality. For small numbers of variables, the exponential model is actually the smallest, which is why this is the default.
#
# Inputs: 
#      the number of variables which need to be represented
#      --help will produce a usage message
#      -r to produce reduced (in both size and functionality) Promela program
#      -l to produce a linearly-sized Promela program
#
# Outputs:
#      Promela program in the current directory enumerating
#                      all possible variable value combinations
#      definition file in the current directory listing the 
#                      corresponding #define statements
#
# Usage: generatePvalues.pl number_of_variables
#
# Output file format:
#     bool P1,P2;
#     
#     /* define an active procedure to generate values for P1 and P2 */
#     
#     active proctype generateValues()
#     {
#     do
#        :: atomic{P1 = 0; P2 = 0;}
#        :: atomic{P1 = 0; P2 = 1;}
#        :: atomic{P1 = 1; P2 = 0;}
#        :: atomic{P1 = 1; P2 = 1;}
#     od
#     }
#
# -r reduced file format:
#     /* define an active procedure to generate values for P1 and P2 */
#     
#     active proctype generateValues()
#     {
#     do
#        :: P1 = 0;
#        :: P1 = 1;
#        :: P2 = 0;
#        :: P2 = 1;
#     od
#     }
#
# -l linear file format:
#     /* define an active procedure to generate values for A and B */
#     
#     active proctype generateValues()
#     {
#     do
#       ::atomic{
#         if
#           :: true -> P1 = 0;
#           :: true -> P1 = 1;
#         fi;
#         if
#           :: true -> P2 = 0;
#           :: true -> P2 = 1;
#         fi;
#       }
#     od
#     }
#
#General Strategy:
#
# 1) Write non-deterministic value choice function to pan_in file
# 2) Write #defines to pan.ltl file
# 3) Use files like so: `spin -f "<>( formula )" >> pan.ltl`



use FileHandle;      #for open() 


#################### Setup ####################

#Check for correct number and type of command line arguments

if (@ARGV == 2) {
    $r = shift @ARGV;
    if ($r eq "-r") {
	print "Switching to reduced Promela program generation\n";
	$reduced = 1;
    } #end if
    elsif ($r eq "-l") {
	print "Switching to linear Promela program generation\n";
	$linear = 1;
    } #end elsif
    else {
	$ARGV[0] = "--help"	
    } #end else
} #end if
if (@ARGV != 1) {
    die "Usage: generatePvalues.pl [-r | -l] number_of_variables\n";
} #end if
elsif ($ARGV[0] == "--help") {
    #print "argv[0] is $ARGV[0]\n";
    die "generatePvalues.pl: This program spits out a Promela program to feed into SPIN which causes SPIN to nondeterministically choose all possible value combinations for all of the possible boolean variables.\n\n The variable names are: p1, p2, p3 ... Usage: generatePvalues.pl [-r | -l] number_of_variables
\twhere:
\t-r to produce reduced (in both size and functionality) Promela program
\t-l to produce a linearly-sized Promela program\n";
} #end elsif

##### Get command line argument(s) #####

if ( !( ($ARGV[0] =~ /^\d+$/ ) && ($ARGV[0] > 0) ) ) {
    die "ERROR: Expecting positive integer argument\n";
} #end if
else {
    $num_vars = $ARGV[0];
} #end else


#################### Create Promela Files ####################

#Create and open output files
#Name files for the number of variables they correspond to:

#Promela input file
$pFile = "${num_vars}Pvars.pml";
open(PFILE, ">$pFile") or die "Could not create $pFile";
print "Creating $pFile\n";

#Define file
$dFile = "${num_vars}Pvars.define";
open(DFILE, ">$dFile") or die "Could not create $dFile";
print "Creating $dFile\n";


### Set up strings of lines to print to the files ###

print PFILE "bool P1";  #Ex: bool P1,P2;
print DFILE "#define p1   P1\n";


if (($reduced) || ($linear)) {

    if ($reduced) {
	$case_string .= "   :: P1 = 0;\n   :: P1 = 1;\n";
    } #end if
    else { #linear
	$case_string .= "      if\n        :: true -> P1 = 0;\n        :: true -> P1 = 1;\n      fi;\n";
    } #end else

    for ($i = 2; $i <= $num_vars; $i++) {
	
	#First, form the variable name strings to use in this round of the loop
	
	$this_Var = "";
	$this_var = "";

	#create the current variable names
	$this_Var .= "P${i}";
	$this_var .= "p${i}";
	
	#Second, fill in the strings
	
	print PFILE ",${this_Var}";
	if ($reduced) {
	    $case_string .= "   :: $this_Var = 0;\n   :: $this_Var = 1;\n";
	} #end if
	else { #linear
	    $case_string .= "      if\n        :: true -> $this_Var = 0;\n        :: true -> $this_Var = 1;\n      fi;\n";
	} #end else
	print DFILE "#define $this_var   $this_Var\n";
	
    } #end for
} #end if $reduced/$linear
else {

    $case_string[0] = "   :: atomic{ P1 = 0; ";
    $case_string[1] = "   :: atomic{ P1 = 1; ";

    for ($i = 2; $i <= $num_vars; $i++) {
	
	#First, form the variable name strings to use in this round of the loop
	
	$this_Var = "";
	$this_var = "";

	#create the current variable names
	$this_Var .= "P${i}";
	$this_var .= "p${i}";
	
	#Second, fill in the strings
	
	print PFILE ",${this_Var}";
	for ($k = 0; $k < @case_string; $k++) {
	    $temp[2*$k]   = $case_string[$k]."$this_Var = 0; ";
	    $temp[2*$k+1] = $case_string[$k]."$this_Var = 1; ";
	} #end for
	@case_string = @temp; #replace @case_string

	print DFILE "#define $this_var   $this_Var\n";
	
    } #end for

    for ($k = 0; $k < @case_string; $k++) {
	$case_string[$k] = $case_string[$k]."}";
    } #end for

} #end else (not reduced)


### Finish off the strings of lines and print them to the files ###

$dec_string .= ";\n";
print PFILE "$dec_string\n";
print PFILE "/* procedure to generate all value combinations for $num_vars variables */\n\n";

print PFILE "active proctype generateValues()\n{\ndo\n";
if ($reduced) {
    print PFILE $case_string;
} #end if $reduced
elsif ($linear) {
    print PFILE "   ::atomic{\n";
    print PFILE $case_string;
    print PFILE "   }\n";
} #end elsif
else {
    for ($k = 0; $k < @case_string; $k++) {
	print PFILE "$case_string[$k]\n";
    } #end for
} #end else (not reduced)
print PFILE "od\n}\n";

print DFILE "\n"; #add an extra newline for prettiness

#close the output files
close (PFILE) or die "Could not close $pFile";
close (DFILE) or die "Could not close $dFile";
