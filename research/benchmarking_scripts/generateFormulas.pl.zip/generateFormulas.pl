#!/usr/bin/perl
#
#by Kristin Y. Rozier
#
#This software has been determined to be outside the scope of NASA NPG 2210 and therefore is not considered as controlled software.
#
#This program may be freely redistributed and/or modified under the terms of the enclosed software agreement. NASA is neither liable nor responsible for maintenance, updating, or correction of any errors in the software provided. Use of this software shall not be construed to constitute the grant of a license to the user under any NASA patent, patent application or other intellectual property.
#
#You should have received a software agreement along with this program. If not, please refer to Section 4 of: http://opensource.arc.nasa.gov/pdf/NASA_Open_Source_Agreement_1.3.txt
############################################################################
#generateFormulas.pl
#
#     This program generates a test set of LTL formulas using the methods described in "Improved automata generation for linear temporal logic" by Daniele, Guinchiglia, and Vardi. The formulas are first generated in SPIN syntax and then in other, tool-specific syntaxes and fed to LTL translators to produce automata in the form of Promela never-claims to input to SPIN.
#
#     The formulas are written in a standard format; it is presumed that they will be converted to any tool-specific format necessary after having been read in by the appropriate program.
#
# Inputs: (all are required; order matters)
#      L : formula length
#      N : number of variables
#      P : probability of choosing temporal operators 
#      (--help will produce a usage message)
#      no inputs: just generate all values of L, N, and P
#
# Outputs: (INCOMPLETE)
#
# Usage: generateFormulas.pl
#


use FileHandle;      #for open() 


#Set the directory where all of the formulas will be stored
$formula_dir = "./formulas";

#If the formula directory doesn't exist, create it
if (! (-d $formula_dir) ) {
    mkdir("$formula_dir", 0755) or die "Cannot mkdir $formula_dir: $!";
} #end if
elsif (! (-w $formula_dir) ) { #check for write permission
    die "ERROR: formula directory $formula_dir is not writable!";
} #end elseif



#################### Argument Setup ####################

#Check for correct number and type of command line arguments

if ($ARGV[0] =~ /--help/) {
    die "generateFormulas.pl: \n\tWith no arguments: generate a wide range of formula files\n\tWith 3 arguments: generate files for specified L, N, P (order matters)\n";
} #end if

if (@ARGV == 3) {
    print "Reading command-line arguments:\n";
    ($L, $n, $P) = @ARGV;
    print "L = $L; N = $n; P = $P\n";
    if ($L !~ /^\d+\.?\d*$/ 
	|| $n !~ /^\d+\.?\d*$/ 
	|| $P !~ /^\d+\.?\d*$/ ) {
	die "Require 3 numerical arguments: L, N, P\n";
    } #end if
} #end if

elsif (@ARGV != 0) {
    die "Usage: generateFormulas.pl [optional: specify all of L, N, and P, in that order]\n";
} #end elsif

else {print "Generating formulas for ranges of L, N, and P...\n";}


#################### Generation of Formulas ####################

### Set up the generation variables

$F = 500; #number of formulas to generate in one test set
print "F is $F\n";
print OUT "F is $F\n";

@N = qw(a b c d e); #array of variables
print "N is @N\n";
print OUT "N is @N\n";

@Llist = (5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90, 95, 100);
print "L = (@Llist)\n";
print OUT "L = (@Llist)\n";

@Plist = (1/3, 0.5, 0.7, 0.95); #array of probabilities to try
print "P = (@Plist)\n";
print OUT "P = (@Plist)\n";

@operators = qw(! X && || U V); #array of operators: 
#order is very important here: unary then binary then temporal:
#not, next time, and, or, (strong) until, and V = not(not u1 U not u2)


##################################################################
#
# Functions: 
# 
#    generate_formula: generates one formula
#
##################################################################


### Define a recursive function to use to generate each formula
sub generate_formula {

    my $L = $_[0];
    my $S;
    
    #print "generate_formula here: L is $L, N is $n, and P is $P\n";
    
    if ($L == 1) { #randomly choose one variable
	return "$N[int(rand($n))]";
    } #end if
    elsif ($L == 2) { #randomly choose one variable and one unary operator
	return "($operators[int(rand(2))] ($N[int(rand($n))]))";
    } #end elsif
    else {
	#choose an operator $op
	$r = rand; #r is a random variate [0, 1)

	#choose an operator with certain probabilities...
	if ($r <= $P/2) { #choose U
	    #choose S such that 1 <= S <= L - 2
	    $S = int(1+rand($L - 2));
	    #print "S is $S\t";
	    my $T = $L - $S - 1;
	    #print "T is $T\n";
	    #print "Returning formula of length $S + $T = $L, op = U\n";
	    return  "(".&generate_formula($S)
		.") U ("
		       .&generate_formula($T).")";	
	    #print "$formula\n";
	    #return $formula;
	} #end if U
	elsif ($r <= $P) { #choose V
	    #choose S such that 1 <= S <= L - 2
	    $S = int(1+rand($L - 2));
	    #print "S is $S\t";
	    my $T = $L - $S - 1;
	    #print "T is $T\n";
	    #print "Returning formula of length $S + $T = $L, op = V\n";
	    return "( !( ( !(".&generate_formula($S)
		.")) U (!("
		.&generate_formula($T)."))) )";	
	    #print "$formula\n";
	    #return $formula;
	} #end elsif
	else { #the other operators have an equal chance so pick randomly
	    $op_index = int(rand(4));
	    if ($op_index < 2) { #we have a unary operator
		#print "Returning formula of length $L, op = $operators[$op_index]\n";
		return "($operators[$op_index] ("
		       .&generate_formula($L - 1)
		       ."))";	
		#print "$formula\n";
		#return $formula;
	    } #end if
	    else { #we have a binary operator
		#choose S such that 1 <= S <= L - 2
		$S = int(1+rand($L - 2));
		#print "S is $S\t";
		my $T = $L - $S - 1;
		#print "T is $T\n";
		my $op = "$operators[$op_index]";		
		#print "Returning formula of length $S + $T = $L, op = $op\n";
		return "(".&generate_formula($S)
		       .") $op ("
		       .&generate_formula($T).")";	
		#print "$formula\n";
		#return $formula;
	    } #end else binary
	} #end else choose non-temporal operator
    } #end else $L > 2
	   
} #end generate_formula


##################################################################
#
# Main Program: 
# 
#    Generate output files, each containing a set of formulas with
#       the same L, N, P values,.
#
#
##################################################################


if (@ARGV == 3) {

    print "\n\nN = $n, L = $L, P = $P:\n";

    #Create an output file for each set of formulas data
    $FormFile = "${formula_dir}/P${P}N${n}L${L}.form";
    open(FORMULAS, ">$FormFile") or die "Could not open $FormFile";
    
    for ($f = 0; $f < $F; $f++) { #generate $F formulas
	
	$formula = &generate_formula($L);
	print FORMULAS "$formula\n";

    } #end for each formula
    
    close(FORMULAS) or die "Could not close $FormFile";
    #return; #exit since we just needed to generate this one set
    die;
} #end if


#################### Generate the sets of formulas ####################

for ($n = 1; $n <= @N; $n++) { #for n variables

    for ($l = 0; $l < @Llist; $l++) { #for each length
	$L = $Llist[$l];

	for ($p = 0; $p < @Plist; $p++) { #for each probability
	    $P = $Plist[$p];
	    
	    print "\n\nN = $n, L = $L, P = $P:\n";
	    
            #Create an output file for each set of formulas data
	    $FormFile = "${formula_dir}/P${P}N${n}L${L}.form";
	    open(FORMULAS, ">$FormFile") or die "Could not open $FormFile";
	    
	    for ($f = 0; $f < $F; $f++) { #generate $F formulas
		
		$formula = &generate_formula($L);
		print FORMULAS "$formula\n";

	    } #end for each formula

	    close(FORMULAS) or die "Could not close $FormFile";
	    
	} #end for each temporal probability

    } #end for each length

} #end for n variables

