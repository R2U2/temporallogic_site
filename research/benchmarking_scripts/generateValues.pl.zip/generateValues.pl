#!/usr/bin/perl
#
#by Kristin Y. Rozier
#01/24/2005
#
#This software has been determined to be outside the scope of NASA NPG 2210 and therefore is not considered as controlled software.
#
#This program may be freely redistributed and/or modified under the terms of the enclosed software agreement. NASA is neither liable nor responsible for maintenance, updating, or correction of any errors in the software provided. Use of this software shall not be construed to constitute the grant of a license to the user under any NASA patent, patent application or other intellectual property.
#
#You should have received a software agreement along with this program. If not, please refer to Section 4 of: http://opensource.arc.nasa.gov/pdf/NASA_Open_Source_Agreement_1.3.txt
############################################################################
# generateValues.pl
#
#This program spits out a Promela program to feed into SPIN which causes SPIN to nondeterministically choose all possible value combinations for all of the possible boolean variables. With no flags, the simple (though exponential in the number of variables) model is produced. The -r flag produces a reduced (but not universal) version of this model and the -l flag produces a linearly-sized version with the same (full) functionality. For small numbers of variables, the exponential model is actually the smallest, which is why this is the default.
#
# Inputs: 
#      the number of variables which need to be represented
#      --help will produce a usage message
#      -r to produce reduced (in both size and functionality) Promela program
#      -l to produce a linearly-sized Promela program
#
# Outputs:
#      Promela program in the current directory enumerating
#                      all possible variable value combinations
#      definition file in the current directory listing the 
#                      corresponding #define statements
#
# Usage: generateValues.pl number_of_variables
#
# Output file format:
#     bool A,B;
#     
#     /* define an active procedure to generate values for A and B */
#     
#     active proctype generateValues()
#     {
#     do
#        :: atomic{A = 0; B = 0;}
#        :: atomic{A = 0; B = 1;}
#        :: atomic{A = 1; B = 0;}
#        :: atomic{A = 1; B = 1;}
#     od
#     }
#
# -r reduced file format:
#     /* define an active procedure to generate values for A and B */
#     
#     active proctype generateValues()
#     {
#     do
#        :: A = 0;
#        :: A = 1;
#        :: B = 0;
#        :: B = 1;
#     od
#     }
#
# -l linear file format:
#     /* define an active procedure to generate values for A and B */
#     
#     active proctype generateValues()
#     {
#     do
#       ::atomic{
#         if
#           :: true -> A = 0;
#           :: true -> A = 1;
#         fi;
#         if
#           :: true -> B = 0;
#           :: true -> B = 1;
#         fi;
#       }
#     od
#     }
#
#General Strategy:
#
# 1) Write non-deterministic value choice function to pan_in file
# 2) Write #defines to pan.ltl file
# 3) Use files like so: `spin -f "<>( formula )" >> pan.ltl`



use FileHandle;      #for open() 


#################### Setup ####################

#Check for correct number and type of command line arguments

if (@ARGV == 2) {
    $r = shift @ARGV;
    if ($r eq "-r") {
	print "Switching to reduced Promela program generation\n";
	$reduced = 1;
    } #end if
    elsif ($r eq "-l") {
	print "Switching to linear Promela program generation\n";
	$linear = 1;
    } #end elsif
    else {
	$ARGV[0] = "--help"	
    } #end else
} #end if
if (@ARGV != 1) {
    die "Usage: generateValues.pl [-r | -l] number_of_variables\n";
} #end if
elsif ($ARGV[0] == "--help") {
    #print "argv[0] is $ARGV[0]\n";
    die "generateValues.pl: This program spits out a Promela program to feed into SPIN which causes SPIN to nondeterministically choose all possible value combinations for all of the possible boolean variables.\n\n The variable names are: a, b, c, ..., aa, bb, cc, ... Usage: generateValues.pl [-r | -l] number_of_variables
\twhere:
\t-r to produce reduced (in both size and functionality) Promela program
\t-l to produce a linearly-sized Promela program\n";
} #end elsif

##### Get command line argument(s) #####

if ( !( ($ARGV[0] =~ /^\d+$/ ) && ($ARGV[0] > 0) ) ) {
    die "ERROR: Expecting positive integer argument\n";
} #end if
else {
    $num_vars = $ARGV[0];
} #end else


#################### Create Promela Files ####################

#Create and open output files
#Name files for the number of variables they correspond to:

#Promela input file
$pFile = "${num_vars}vars.pml";
open(PFILE, ">$pFile") or die "Could not create $pFile";
print "Creating $pFile\n";

#Define file
$dFile = "${num_vars}vars.define";
open(DFILE, ">$dFile") or die "Could not create $dFile";
print "Creating $dFile\n";


### Set up strings of lines to print to the files ###

print PFILE "bool A";  #Ex: bool A,B;
print DFILE "#define a   A\n";

$Var = 'B';
$var = 'b';
$num_chars = 1; #number of characters in each variable


if (($reduced) || ($linear)) {

    if ($reduced) {
	$case_string .= "   :: A = 0;\n   :: A = 1;\n";
    } #end if
    else { #linear
	$case_string .= "      if\n        :: true -> A = 0;\n        :: true -> A = 1;\n      fi;\n";
    } #end else

    for ($i = 1; $i < $num_vars; $i++) {
	
	#First, form the variable name strings to use in this round of the loop
	
	$this_Var = "";
	$this_var = "";

	#create the current variable names
	for ($j = 0; $j < $num_chars; $j++) {
	    $this_Var .= $Var;
	    $this_var .= $var;
	} #end for
	
	#Second, fill in the strings
	
	print PFILE ",${this_Var}";
	if ($reduced) {
	    $case_string .= "   :: $this_Var = 0;\n   :: $this_Var = 1;\n";
	} #end if
	else { #linear
	    $case_string .= "      if\n        :: true -> $this_Var = 0;\n        :: true -> $this_Var = 1;\n      fi;\n";
	} #end else
	print DFILE "#define $this_var   $this_Var\n";
	
	#Set up variable names for the next round of the loop
	
	$Var++;
	$var++;
	
	if ( ($i + 1)%26 == 0) {
	    #reset variable names:
	    $Var = 'A';
	    $var = 'a';
	    $num_chars++; #increase the number of chars per variable
	} #end if
	
    } #end for
} #end if $reduced/$linear
else {

    $case_string[0] = "   :: atomic{ A = 0; ";
    $case_string[1] = "   :: atomic{ A = 1; ";

    for ($i = 1; $i < $num_vars; $i++) {
	
	#First, form the variable name strings to use in this round of the loop
	
	$this_Var = "";
	$this_var = "";

	#create the current variable names
	for ($j = 0; $j < $num_chars; $j++) {
	    $this_Var .= $Var;
	    $this_var .= $var;
	} #end for
	
	#Second, fill in the strings
	
	print PFILE ",${this_Var}";
	for ($k = 0; $k < @case_string; $k++) {
	    $temp[2*$k]   = $case_string[$k]."$this_Var = 0; ";
	    $temp[2*$k+1] = $case_string[$k]."$this_Var = 1; ";
	} #end for
	@case_string = @temp; #replace @case_string

	print DFILE "#define $this_var   $this_Var\n";
	
	#Set up variable names for the next round of the loop
	
	$Var++;
	$var++;
	
	if ( ($i + 1)%26 == 0) {
	    #reset variable names:
	    $Var = 'A';
	    $var = 'a';
	    $num_chars++; #increase the number of chars per variable
	} #end if
	
    } #end for

    for ($k = 0; $k < @case_string; $k++) {
	$case_string[$k] = $case_string[$k]."}";
    } #end for

} #end else (not reduced)


### Finish off the strings of lines and print them to the files ###

$dec_string .= ";\n";
print PFILE "$dec_string\n";
print PFILE "/* procedure to generate all value combinations for $num_vars variables */\n\n";

print PFILE "active proctype generateValues()\n{\ndo\n";
if ($reduced) {
    print PFILE $case_string;
} #end if $reduced
elsif ($linear) {
    print PFILE "   ::atomic{\n";
    print PFILE $case_string;
    print PFILE "   }\n";
} #end elsif
else {
    for ($k = 0; $k < @case_string; $k++) {
	print PFILE "$case_string[$k]\n";
    } #end for
} #end else (not reduced)
print PFILE "od\n}\n";

print DFILE "\n"; #add an extra newline for prettiness

#close the output files
close (PFILE) or die "Could not close $pFile";
close (DFILE) or die "Could not close $dFile";
