#!/usr/bin/perl
#
#by Kristin Y. Rozier
#
#This software has been determined to be outside the scope of NASA NPG 2210 and therefore is not considered as controlled software.
#
#This program may be freely redistributed and/or modified under the terms of the enclosed software agreement. NASA is neither liable nor responsible for maintenance, updating, or correction of any errors in the software provided. Use of this software shall not be construed to constitute the grant of a license to the user under any NASA patent, patent application or other intellectual property.
#
#You should have received a software agreement along with this program. If not, please refer to Section 4 of: http://opensource.arc.nasa.gov/pdf/NASA_Open_Source_Agreement_1.3.txt
############################################################################
# Eformula.pl
#
# Input: n = the number of subformulas of the form "F pi" which will be AND'ed together in the output formula
# 
# Output: an LTL formula of the form E(n) = & _{i=1} ^{n} F pi
#
# Usage: Eformula.pl n
#

# System Description
#
# - n variables: p1 .. pn

# Purpose: to create scaleable formulas as described in "Larger Automata and Less Work for LTL Model Checking" by Geldenhuys and Hansen



#################### Argument Setup ####################

#Check for correct number and type of command line arguments
if ($ARGV[0] =~ /^-v?/) {
    $verbose = 1;
    shift(@ARGV);
} #end if
else {
    $verbose = 0;
} #end else

if (@ARGV != 1) {
    die "Usage: Eformula.pl n\n\tproduces an n-part formula of the form E(n) = & _{i=1} ^{n} F pi\n\tUse flag -v for verbose, human-readable output.\n";
} #end if

$n = $ARGV[0];

#Check that we have an integer
if (($n !~ /^\d+?/) || ($n <= 0)) {
    die "Error: Expecting a positive integer as input; Got $n\n";
} #end if


#################### Generation of the Formula ####################
$pattern = "(F p1)"; #initialize the pattern

for ($i = 2; $i <= $n; $i++) {
    $pattern = "($pattern && (F p$i))";
} #end for

if ($verbose == 1) {
    print "\nComputer readable: ";
} #end if
print "$pattern\n";
