/**
* @file   main.c
* @Author Johannes Geist (johannesgeist@nasa.gov)
* @date   February, 2014
* @brief  The main program logic (opening interface, program rtr2u2 and log results)
*
*/
#include "includes.h"
#include "rs232.h"
#include "functions.h"

FILE *binprogfile = NULL;
FILE *errorlog = NULL;
FILE *rrlog = NULL;
FILE *siminfile = NULL;
int rs232fd = 0;

static void my_close_handler(int sig, siginfo_t *siginfo, void *context){
	printf("Signal caught! Program will close all files and terminate the program!\n");
	fprintf(errorlog,"Program terminated by SIGINT\n");
	fclose(binprogfile);
	fclose(rrlog);
	fclose(errorlog);
	if (SIMULATION){
		fclose(siminfile);
	}
	close(rs232fd);
	exit(1);
}

int main (int argc, char *argv[])
{
	//simulation variables
	float sizetemp = (float)LOGDATAWIDTH/8;
	int atomicsinputsize = ceil(sizetemp);
	unsigned char atomicsinput [atomicsinputsize];

	unsigned int k = 0;
	unsigned int j;
	unsigned int l;
	unsigned int m;

	int index;
	int v,z, g;

	bool programming_not_finished = true;
	int pingcounter = 1;
    char bayesname[16];
	unsigned int acnumber = 0;
	unsigned int posteriormarginals = 0;
	float posteriormarginalsfloat;
	unsigned int temp;
	int testsamplecounter = 0;

	int bayesnamelen = 0;
	//past time ltl log var
	unsigned int ptaddr = 0;
	unsigned int ptvalue = 0;
	//future time ltl log var
	unsigned int ftaddr = 0;
	unsigned int ftvalue = 0;
	unsigned int ftsyncvalue = 0;
	unsigned int ftsyncempty = 0;
	unsigned int ftasyncvalue = 0;
	unsigned int fttimestamp = 0;
	//current timestamp for past time logging
	unsigned int tscounter = 0;
	unsigned int timestamp = 0;

	unsigned int pdamount = 0;

	unsigned int indicators = 0;
	unsigned int bytetmp = 0;
	unsigned int bytemask = 0;

	bool ftlogging = false;
	bool initial = true;
	
	memset(atomicsinput, 0b00000000, atomicsinputsize*sizeof(unsigned char));
    memset(binprogarray, 0b00000000, sizeof(binprogarray[0][0])*127*COMMUNICATIONCYCLES);
	
	portname = "/dev/ttyUSB0";
   
	int charcounter = 0;

	time_t t = time(NULL);
	struct tm tm = *localtime(&t);

	struct sigaction act;
	memset (&act, '\0', sizeof(act));

	act.sa_sigaction = &my_close_handler;
	act.sa_flags = SA_SIGINFO;

	unsigned char rs232sendbuf[9] = {RS232_START_TRASH,RS232_READY,RS232_START_SENDING,RS232_BAYES_FIN,RS232_PROG_FINISHED,RS232_GOOD,RS232_BAYES_HEADER,RS232_AC_HEADER, RS232_FULL_ONE};

	if(sigaction(SIGINT, &act, NULL) < 0){
		perror("sigaction");
		return 1;
	}

	/*****************************************************************************************
	* Check for enough parameters for program execution
	* 6 for a simulation - pre recorded sensor data is sent to the hardware and evaluated
	* 5 for normal run - sensor data are fed into the hardware from a external tool in real time
	*****************************************************************************************/
	
	if(SIMULATION){
		if(argc != 6){
			printf("Usage: %s binary_program_file error_log_file result_log_file bayesian_network_name simulation_data_file\n", argv[0]);
			return -1;
		}
	}
	else{
		if (argc != 5){
			printf("Usage: %s binary_program_file error_log_file result_log_file bayesian_network_name\n", argv[0]);
			return -1;
		}
	}

	/************************************************************************************
	* Initialization of serial interface and open every file
	************************************************************************************/
	
	// Open binary program file
	open_file(&binprogfile, argv[1], 'r');

	// Open error log file
	open_file(&errorlog, argv[2], 'w');

	// Open log file for result logging
	open_file(&rrlog, argv[3], 'w');

	//Open replacement files for serial interface (reading and writing)
	if (FILEUSE){
		rs232teststimuli = open ("rs232teststimuli.dat", O_RDONLY);
		if(rs232teststimuli == 0){
			printf("Could not open rs232teststimuli.dat!\n");
			return -1;
		}

		rs232writefile = open ("rs232rec.dat", O_WRONLY);
		if(rs232writefile == 0){
			printf("Could not open rs232rec.dat!\n");
			return -1;
		}
	}
	else{
		//Open serial interface
		rs232fd = open (portname, O_RDWR | O_NOCTTY | O_NDELAY); 
		if(rs232fd < 0){
			printf("Could not open Serial Interface, look at the log for more information\n");
			fprintf(errorlog,"error %d opening %s: %s \n", errno, portname, strerror (errno));
			return -1;
		}
		else{
			fcntl(rs232fd, F_SETFL, 0);
		}
		//Initialization of serial interface
		//Set speed to 115,200 bps, 8n1 (no parity)
		set_interface_attribs (rs232fd, B115200, 0);  
		//Set no blocking  
		set_blocking (rs232fd, 1);                
		
		printf("All files successfully open and serial interface awaits data!\n");
	}

	/************************************************************************************
	* main program body
	************************************************************************************/
	
	printf("Starting parsing binary program in internal structure!\n");
	fprintf(errorlog,"Starting parsing binary program in internal structure!\n");
	fprintf(errorlog,"Binary program:\n");
	//Read binary program into internal structure 
	//[internal structure consists of up to 200, 8 bit width and 126 entries long array] - two dimensional array 
	//one communication cycle can send 126 bytes then a new cycle must be started
	prepare_binary_program(&binprogfile, &errorlog, &argv[1]);
	printf("Parsing of binary program successfully finished.\n");

	/************************************************************************************
	* Establish communication and send send required data to hardware. 
	* Communication protocol: 
	* -) send ping to board and wait for response 
	* -) when RS232_READY signal is received send header file will be send
	*    header consists of a flag (MSB) and the amount of bytes to follow (up to 126)
	* -) Then the program waits for an acknowledge, when RS232_START_SENDING is received 
	*    then the program it self is transmitted
	* -) When the maximum amout of bytes, of one communication cycle is reached a new cycle
	*    is started, until the complete program is transferred. 
	************************************************************************************/
	printf("Establishing connection to hardware and transmitting program file.\n");
	while(programming_not_finished){	
      printf("STARTTRASH: ");
		rs232_write(rs232fd, &rs232sendbuf[0]);
		fprintf(errorlog,"Ping # %d has been send to the board, waiting for a response\n",pingcounter);
		pingcounter++;
		if(DEBUG){ 
			//sleep (1);
			printf("Waiting for Ready signal! - AA\n");
			fflush(stdout);
		}
		//waiting for RS232_READY signal
		rs232_read(rs232fd, &errorlog);
		if(rs232buffer[0] == RS232_READY){
			//send header information 
			printf("Ready Signal received\n");
			fprintf(errorlog,"Response received\n");
         printf("HEADER: ");
			rs232_write(rs232fd, &binprogarray[0][k]);
			fprintf(errorlog,"Header has been send to the board, waiting for a response\n");

			if(DEBUG){
				printf("Waiting for start signal - 55!\n");
				fflush(stdout);
			}
			//waiting for RS232_START_SENDING
			rs232_read(rs232fd, &errorlog);
			
			if(rs232buffer[0] == RS232_START_SENDING){
				fprintf(errorlog,"Acknowledge signal received, beginning sending binary program.\n");
				if(k < column){
					for(j=1;j<=126;j++){
						rs232_write(rs232fd, &binprogarray[j][k]);
					}
					fprintf(errorlog,"#%d 126 byte block sent to hardware!\n",k);
					k++;
				}
				else{
					for(l=1;l<=line-1;l++){
						rs232_write(rs232fd, &binprogarray[l][k]);
					}
					programming_not_finished = false;
					fprintf(errorlog,"Binary program transmitted to rtr2u2.\n");
               //printf("k: %d, l: %d, x: %d\n",k,l, column);
					break;
				}
				//goto start;
				continue;
			}
			else{
				fprintf(errorlog,"START_SENDING:Wrong identifier received. expected %x but received %c\n",RS232_START_SENDING,rs232buffer[1]);                             
				//goto start;
				continue;
			}
		}
		else{
			fprintf(errorlog,"READY:Wrong identifier received. expected %x but received %c\n",RS232_READY,rs232buffer[0]);                             
			//goto start;
			continue;
		}
	}
	printf("Binary program successfully transmitted!\n");
	
	/************************************************************************************
	* Current configuration can display a name for the Bayesian network on a 16 character display
	* This has no effect on the execution and is simply for presentation purpose and a better overview
	************************************************************************************/
	
	//read given Bayesian network name into buffer 
	printf("----------------BAYES NAME----------------------\n");
	bayesnamelen = strlen(argv[4]);
	if (bayesnamelen >16){
		printf("The Bayesian name provided is too long, please restart program and provide a name with a maximum of 16 character!\n");
		fprintf(errorlog,"The Bayesian name: %s has to many characters, it has %d characters, but only 16 are allowed!\n",argv[4],bayesnamelen);
		return -1;
	}
	else{
		strcpy(bayesname,argv[4]);
	}
	
	while(bayesname[charcounter] != '\0'){
		charcounter++;
	}
	printf("%s\n",bayesname);
	for(z=charcounter;z<=16;z++){
		bayesname[z] = 0x20;
	}
	//Establish communication cycle 
	rs232_write(rs232fd, &rs232sendbuf[0]);
   
	pingcounter++;
	fprintf(errorlog,"Ping #%d has been send to the board, waiting for a response\n",pingcounter);

	if(DEBUG){
		printf("Waiting for ready signal! - AA\n");
		fflush(stdout);
	}

	//waiting for RS232_READY signal
	rs232_read(rs232fd, &errorlog);
   if(rs232buffer[0] == RS232_READY){
		rs232_write(rs232fd, &rs232sendbuf[6]);
		fprintf(errorlog,"Displaying name for experiment has been sent\n");

		if(DEBUG){
			printf("Waiting for start signal! - 55\n");
			fflush(stdout);
		}
		
		//waiting for RS232_START_SENDING
		rs232_read(rs232fd, &errorlog);
		if(rs232buffer[0] == RS232_START_SENDING){
			for(m = 0; m <= 15; m++){
			rs232_write(rs232fd, (unsigned char *)&bayesname[m]);
			}
		} 
		else{
			printf("Error: expected %#x, but received %#x.\n",rs232sendbuf[2],rs232buffer[0]);
			fprintf(errorlog,"Wrong identifier received. Program terminated. Expected %#x, but received %#x.\n",rs232sendbuf[2],rs232buffer[0]);
			return -1;
		}
	}
	else{
		printf("Error: expected %#x, but received %#x.\n",rs232sendbuf[1],rs232buffer[0]);
		fprintf(errorlog,"Wrong identifier received. Program terminated. Expected %#x, but received %#x.\n",rs232sendbuf[1],rs232buffer[0]);
		return -1;
	}
	
	printf("Finishing programming...\n");
	/************************************************************************************
	* Binary program and display name has been transmitted to rtr2u2, program has been 
	* successfully loaded. Remaining task: Letting rtr2u2 know, that programming is finished!
	************************************************************************************/
	
	if(DEBUG){
		printf("Waiting for Bayesian name programming fin signal! - 3C\n");
		fflush(stdout);
	}
	
	//waiting for RS232_BAYES_FIN
	rs232_read(rs232fd, &errorlog);
	if(rs232buffer[0] == RS232_BAYES_FIN){
	//establish last programming communication cycle
		rs232_write(rs232fd, &rs232sendbuf[0]);
		fprintf(errorlog,"Ping #%d has been sent to the board, waiting for a response\n",pingcounter);
		
		if(DEBUG){
			printf("Waiting for Ready signal! - AA\n");
			fflush(stdout);
		}

		//waiting for RS232_READY signal 
		rs232_read(rs232fd, &errorlog);
		if(rs232buffer[0] == RS232_READY){
			//sending programming finish signal
			rs232_write(rs232fd, &rs232sendbuf[4]);
		}
	}
	else{
		printf("Error: expected %#x but received %#x.\n",rs232sendbuf[3],rs232buffer[0]);
		fprintf(errorlog,"Wrong identifier received. Program terminated. Expected %#x but received %#x.\n",rs232sendbuf[3],rs232buffer[0]);
		return -1;
	}

	if(DEBUG){
		printf("Waiting for RS232_GOOD - C3.\n");
	}

	//waiting for RS232_GOOD signal
	rs232_read(rs232fd, &errorlog);
	if(rs232buffer[0] == RS232_GOOD){
		printf("Hardware board has been programmed, evaluation will start shortly\n");
		sleep(2);
	}
	else
	{
		printf("Received wrong identifier, Board has problems finishing programming. Please see error log for more information!\n");
		fprintf(errorlog,"Wrong identifier received. Received %#x but expected %#x.\n",rs232sendbuf[5], rs232buffer[0]);
		return -1;
	}

	/************************************************************************************
	* EVALUATION STATE: two modes available
	* 1.) SIMULATION - that means recorded data sets are transmitted to the board and after 
	*	   every update a corresponding response is received (tested and working February 2014)
	* 2.) REAL LIFE RUN - that means real life data is fed into the rtr2u2 framework and evaluated
	*     not implemented, due to missing hardware interface (February 2014)
	************************************************************************************/
	
	//open recorded data set
	if(SIMULATION){
		siminfile = fopen (argv[5], "r");
		if(siminfile == 0){                       
			printf("Could not open %s file\n",argv[5]);
			return -1;
		}
	}
	printf("EVALUATION:\n");

	fprintf(rrlog, "log %s | %d-%d-%d %d:%d:%d\n", bayesname, tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
	while(1){
		if(initial == false){
			testsamplecounter++;
			rs232_write(rs232fd, &rs232sendbuf[0]);
			fprintf(errorlog,"Ping # %d has been send to the board, waiting for a response\n",pingcounter);
			pingcounter++;
			if (DEBUG){
				printf("Waiting for Ready signal! - AA\n");
				fflush(stdout);
			}
			
			//waiting for RS232_READY
			rs232_read(rs232fd, &errorlog);
			if(rs232buffer[0] == RS232_READY){
				//send signal to board to switch into evaluation mode
				rs232_write(rs232fd, &rs232sendbuf[7]);
				printf("Signal for switching to evaluation mode has been sent to board, waiting for a response\n");
				fprintf(errorlog,"Header has been sent to board. rtr2u2 will switch to evaluation mode.\n");
				if(DEBUG){
					printf("Waiting for start signal - 55!\n");
					fflush(stdout);
				}

				//waiting for RS232_START_SENDING
				rs232_read(rs232fd, &errorlog);
				printf("\n");

				memset(atomicsinput, 0b00000000, atomicsinputsize*sizeof(unsigned char) );
				if(rs232buffer[0] == RS232_START_SENDING){
				//ready to receive recorded data 
				//Read binary representation of logged data into internal structure 
				//[internal structure consists of LOGDATAWIDTH divided by 8 and rounded to the next higher integer]
				prepare_atomics_input(&siminfile, &errorlog, atomicsinput, &argv[5]);
					for(g=sizeof(atomicsinput)-1;g>=0;g--){ 
					rs232_write(rs232fd, &atomicsinput[g]);
					fprintf(errorlog,"g:%d :%02X\n",g,atomicsinput[g]);
					}
					//printf("\n");
					for(v=0;v<=ceil(LOGDATAWIDTH/8)-1;v++){
						fprintf(errorlog,"%d:%d\n", (unsigned int)atomicsinput[v],v);
					}
					memset(atomicsinput, 0b00000000, atomicsinputsize*sizeof(unsigned char) );
				}
			}
			printf("Simulation sample # %d sent.\n",testsamplecounter);
			sleep(2);
		}

		/********************************************************************************
		* Logged data conists of the following parts
		* - current time stamp (time stamp is increased after every simulation sample)
		* - content of past time LTL evaluation (memory address : boolean value)
		* - content of future time LTL evaluation
		*   (memory address : synchron value : asynchron empty : asynchron value : time stamp asynchron output)
		* - if new reasoning values are available, then these will be logged too
		*   (Arithmetic Circuit number | Posterior Marginals value)
		********************************************************************************/
		
		printf("Waiting for corresponding evaluation data.\n"); 
		fprintf(rrlog,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		fprintf(rrlog,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

		//waiting for first byte of 4 byte time stamp
		rs232_read(rs232fd, &errorlog);		 

		//reading the 3 remaining bytes of the time stamp
		while(tscounter <= 3){
			temp = (int) rs232buffer[0];
			timestamp |=  (temp << tscounter*8);
			tscounter ++;
			rs232_read(rs232fd, &errorlog);		 
		}

			tscounter = 0;
			fprintf(rrlog,"\nTimestamp: %d\n \n",timestamp);
			printf("Current time stamp: %d \n", timestamp);
			timestamp = 0;
			fprintf(rrlog,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
			
			if(rs232buffer[0] != RS232_PT_LOG){
				printf("Error: Wrong identifier received. Expected 0xCC but received 0x%02X\n",(int)rs232buffer[0]);
				fprintf(errorlog,"Wrong identifier received. Program terminated. Expected 0xCC, but received %#x.\n",rs232buffer[0]);
				return -1;
			}

			/****************************************************************************
			* PAST TIME LTL LOG
			* (memory address : boolean value)
			****************************************************************************/
			fprintf(rrlog,"past time LTL memory dump:\n");
			fprintf(rrlog,"address  | value\n");

			//waiting for first memory entry
			rs232_read(rs232fd, &errorlog);	  
			printf("Got first memory entry!\n");
			do{
				ptvalue = 0;
				ptaddr =  (int)rs232buffer[0];
				
				//waiting for LTL formula value
				rs232_read(rs232fd, &errorlog);		 
								
				ptvalue = (int)rs232buffer[0];     
				if (ptvalue == 1){
					fprintf(rrlog,"  0x%02X   : true\n",ptaddr);
				}
				else{
					fprintf(rrlog,"  0x%02X   : false\n",ptaddr);
				}
				
				//waiting for LTL formula address
				rs232_read(rs232fd, &errorlog);
				
			} while(ptaddr < 255);
			ptaddr = 0;
			
			
			fprintf(errorlog,"Past time LTL memory content successfully logged!\n");
			printf("Past time LTL memory content successfully logged!\n");
			//Memory content of past time LTL evaluation logged, waiting for finish signal
			if (rs232buffer[0] != RS232_LOG_END){
				printf("Error: Didn't received past time logging end signal.\n");
				return -1;
			}

			/****************************************************************************
			* FUTURE TIME LTL LOG
			* (memory address : synchron value : asynchron empty : asynchron value : time stamp asynchron output)
			****************************************************************************/
			
			fprintf(rrlog,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
			fprintf(rrlog,"future time LTL memory dump:\n");
			//fprintf(rrlog,"address | sync value | async empty | async value | async timestamp\n");
			fprintf(rrlog,"address | sync value | async valid | async value | async timestamp\n");
	
			
			rs232_read(rs232fd, &errorlog);	  
			
			//if future time logging is hardware wise disabled then reasoning logging can start immediately 
			switch(rs232buffer[0])
			{
				case(RS232_FT_LOG):
				ftlogging = true;
				break;

				case(RS232_RR_LOG):
				ftlogging = false;
				break;

				default:
				printf("Neither received identifier for future time logging nor for reasoning logging\n");
				return -1;
				break;
			}

			if(ftlogging){
				//waiting for first memory entry
				rs232_read(rs232fd, &errorlog);	  
								
				do{
					ftaddr =  (int)rs232buffer[0];
					
					//waiting for LTL formula sync and async value as well as async empty flag
					rs232_read(rs232fd, &errorlog);
					
					ftvalue = (int)rs232buffer[0];
					ftsyncvalue = ((ftvalue & 0b0001100) >> 3);
					ftsyncempty = ((ftvalue & 0b0000010) >> 2);
					ftasyncvalue = (ftvalue & 0b0000001);

					//waiting for LTL formula async time stamp (byte 1)
					rs232_read(rs232fd, &errorlog);
					temp = (int)rs232buffer[0];
					fttimestamp |= (temp << 24);

					//waiting for LTL formula async time stamp (byte 2)
					rs232_read(rs232fd, &errorlog);
					temp = (int)rs232buffer[0];
					fttimestamp |= (temp << 16);

					//waiting for LTL formula async time stamp (byte 3)
					rs232_read(rs232fd, &errorlog);
					temp = (int)rs232buffer[0];
					fttimestamp |= (temp << 8);

					//waiting for LTL formula async time stamp (byte 4)
					rs232_read(rs232fd, &errorlog);
					temp = (int)rs232buffer[0];
					fttimestamp |= temp;

					//converting binary values in text
					fprintf(rrlog,"  0x%02X  :",ftaddr);
					binary_to_text(&rrlog, ftsyncvalue);
					binary_to_text(&rrlog, ftsyncempty);
					binary_to_text(&rrlog, ftasyncvalue);
					
					fprintf(rrlog," %d\n",fttimestamp);
					ftsyncvalue = 0;
					ftsyncempty = 0;
					ftasyncvalue = 0;
					fttimestamp = 0;

					//waiting for LTL formula address
					rs232_read(rs232fd, &errorlog);			
					
				//}while(ftaddr < 63);
				}while(ftaddr < 255);
				fprintf(rrlog,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				ftlogging = false;
			}
			ftaddr = 0;

			/****************************************************************************
			* RUNTIME REASONING EVALUATION
			* (Arithmetic Circuit number | Posterior Marginals value)
			****************************************************************************/
			fprintf(rrlog,"Evaluation results of Bayesian network\n");

			//waiting for reasoning logging enable signal
			rs232_read(rs232fd, &errorlog);	  
			if(rs232buffer[0] == RS232_RR_LOG){
				//waiting for information of Posterior Marginals amount (byte 1)
				rs232_read(rs232fd, &errorlog);	  
				temp = (int)rs232buffer[0];
				pdamount |= temp;

				//waiting for information of Posterior Marginals amount (byte 2)
				rs232_read(rs232fd, &errorlog);
				temp = (int)rs232buffer[0];
				pdamount |= (temp << 8);
				pdamount++;
				printf("pd amount: %d\n",pdamount);
				fprintf(errorlog,"Number of Posterior Marginals: %d\n", pdamount);

				//waiting for current indicators (byte 1)
				rs232_read(rs232fd, &errorlog);
				temp = (int)rs232buffer[0];
				indicators |= temp;

				//waiting for current indicators (byte 2)
				rs232_read(rs232fd, &errorlog);
				temp = (int)rs232buffer[0];
				indicators |= (temp << 8);

				//waiting for current indicators (byte 3)
				rs232_read(rs232fd, &errorlog);
				temp = (int)rs232buffer[0];
				indicators |= (temp << 16);
				fprintf(rrlog,"Indicators:");
				for(index=19;index>=0;index--){
					bytetmp = indicators;
					bytemask = (1 << index);
					bytetmp  = ((bytetmp & bytemask)>>index);
					fprintf(rrlog,"%d",bytetmp);
					printf("%d",bytetmp);
				}
				fprintf(rrlog,"\n");
				indicators = 0;
				fprintf(rrlog,"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");

				//waiting for first reasoning data
				rs232_read(rs232fd, &errorlog);
				do{
					temp = (int)rs232buffer[0];
					acnumber |= temp;
					//waiting for Arithmetic Circuit number (byte 2)
					rs232_read(rs232fd, &errorlog);
					temp = (int)rs232buffer[0];
					acnumber |= (temp << 8);
					printf("AC Node Number: %d - ",acnumber);

					//waiting for Posterior Marginals (byte 1)
					rs232_read(rs232fd, &errorlog);
					temp = (int)rs232buffer[0];
					posteriormarginals |= temp;

					//waiting for Posterior Marginals (byte 2)
					rs232_read(rs232fd, &errorlog);
					temp = (int)rs232buffer[0];
					posteriormarginals |= (temp << 8); 

					//waiting for Posterior Marginals (byte 3)
					rs232_read(rs232fd, &errorlog);
					temp = (int)rs232buffer[0];
					posteriormarginals |= (temp << 16);
					posteriormarginalsfloat = posteriormarginals * RESOLUTION;
					printf("Posterior Marginals: %f\n",posteriormarginalsfloat);
					fprintf(rrlog,"AC node number: %d | PM result: %f\n", acnumber, posteriormarginalsfloat);
					acnumber = 0;
					posteriormarginals = 0;
					
					//waiting for Arithmetic Circuit number (byte 1)
					rs232_read(rs232fd, &errorlog);
					pdamount--;
				}while(pdamount != 0);
			}
			else{
				printf("No new evaluation of the runtime reasoning unit!\n");
				fprintf(rrlog,"No new evaluation of the runtime reasoning unit!\n");
			}
			if(initial){
				initial = false;
			}
		}
		return 0;
	}
