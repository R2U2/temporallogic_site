/**
* @file   rs232.c
* @Author Johannes Geist (johannesgeist@nasa.gov.com)
* @date   Febuary, 2014
* @brief  function for rs232 interface
*
* This file includes all functions for opening the serial interface under a UNIX system.
*/

#include "includes.h"
#include "rs232.h"
#include "functions.h"

//set attributes of serial interface e.g. baudrate, parity, control signal
int set_interface_attribs (int fd, int speed, int parity)
{
	struct termios tty;
	memset (&tty, 0, sizeof tty);

	if (tcgetattr (fd, &tty) != 0)
	{
		printf("error %d from tcgetattr", errno);
		return -1;
	}
	//set input and output baudrate
	cfsetospeed (&tty, speed);
	cfsetispeed (&tty, speed);
	if(DEBUG){
		printf("Baudrate set to B115200.\n");
	}

	// read doesn't block
	tty.c_cc[VMIN]  = 0;            
	// 0.5 seconds read timeout
	tty.c_cc[VTIME] = 1;              
	if(DEBUG){

		printf("8bits, no break, no echo, read doesn't block,...\n");
	}

	// shut off xon/xoff ctrl
	// disable IGNBRK for mismatched speed tests; otherwise receive break
	// as \000 chars
	tty.c_iflag &= ~(IXON | IXOFF | IXANY);
	// no output processing 
	tty.c_oflag &= ~OPOST;          
	// ignore break signal
	tty.c_iflag &= ~IGNBRK;         
	// no signaling chars, no echo, no canonical processing
	tty.c_lflag = 0;                
	tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);

	// no remapping, no delays
	tty.c_oflag = 0;                

	// ignore modem controls
	tty.c_cflag |= (CLOCAL | CREAD);
	// 8-bit chars
	tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
	// shut off parity     
	tty.c_cflag &= ~(PARENB | PARODD);      
	tty.c_cflag &= ~CSTOPB;
	tty.c_cflag &= ~CRTSCTS;
	tty.c_cflag |= parity;

	// enable reading
	if (tcsetattr (fd, TCSANOW, &tty) != 0)
	{
		printf("error %d from tcsetattr", errno);
		return -1;
	}
	if(DEBUG){
		printf("Setup completed\n");
	}

	return 0;
}

//set if serial interface is blocking or not
void set_blocking (int fd, int should_block)
{
	struct termios tty;
	memset (&tty, 0, sizeof tty);

	if (tcgetattr (fd, &tty) != 0)
	{
		printf("error %d from tggetattr", errno);
		return;
	}

	tty.c_cc[VMIN]  = should_block ? 1 : 0;
	tty.c_cc[VTIME] = 1;            // 0.5 seconds read timeout

	if (tcsetattr (fd, TCSANOW, &tty) != 0)                                
	printf("error %d setting term attributes", errno);
}

//read data from serial interface
void rs232_read(int fd, FILE **errorlog){
	int err = 0;
	unsigned char *bitptr;

	if(FILEUSE){
		err = read(rs232teststimuli, &rs232buffer[0],9);
		bitptr = rs232buffer;
		rs232buffer[0] = set_bits(bitptr);
		printf("%x\n",rs232buffer[0]);
	}
	else {
		err = read(fd,&rs232buffer[0],1);
	}
	if(err < 0){
		printf("Error while reading RS232 interface. Please see error log for more details!\n");
		fprintf(*errorlog,"error %d reading %s: %s \n", errno, portname, strerror (errno));
		exit(EXIT_FAILURE);
	}
}

//write to serial interface
void rs232_write(int fd, unsigned char *message){
	if(FILEUSE){                                
      write(rs232writefile, message, 1);
	}
	else{
		write(fd, message, 1);    
      printf("%x\n",(int)message[0]);
	}
}
