/**
 * @file   rs232.h
 * @Author Johannes Geist (johannesgeist@nasa.gov.com)
 * @date   Febuary, 2014
 * @brief  header file for rs232 interface
 *
 */
 
#ifndef _RS232_H_
#define _RS232_H_

unsigned char rs232buffer[5];

int set_interface_attribs (int fd, int speed, int parity);
void set_blocking (int fd, int should_block);
void rs232_read(int fd, FILE **errorlog);
void rs232_write(int fd, unsigned char *message);

#endif