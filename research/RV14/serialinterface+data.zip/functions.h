#ifndef _FUNCTIONS_H_
#define _FUNCTIONS_H_

unsigned int column;
unsigned int line;

unsigned char set_bits(unsigned char *bit);
void open_file(FILE **file, char *argument, char mode);
void prepare_binary_program(FILE **binprog, FILE **errorlog, char **program_name);
void binary_to_text(FILE **log, unsigned int binary_value);
void prepare_atomics_input(FILE **inputfile, FILE **errorlog, unsigned char *atomicsinput, char **file_name);

#endif