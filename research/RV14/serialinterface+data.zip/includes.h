#ifndef _INCLUDES_H_
#define _INCLUDES_H_

#include <stdio.h>
#include <errno.h>
#include <termios.h>
#include <unistd.h> 
#include <stdbool.h>
#include <time.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <math.h>
#include <sys/select.h>


#define CEILING_POS(X) ((X-(int)(X)) > 0 ? (int)(X+1) : (int)(X))
#define CEILING_NEG(X) ((X-(int)(X)) < 0 ? (int)(X-1) : (int)(X))
#define CEILING(X) ( ((X) > 0) ? CEILING_POS(X) : CEILING_NEG(X) )

//hardware specific bytes for communication protocol
#define RS232_READY  0b10101010
#define RS232_START_SENDING 0b01010101
#define RS232_PROG_FINISHED  0b11111111
#define RS232_GOOD 0b11000011
#define RS232_BAYES_FIN 0b00111100
#define RS232_START_TRASH 0b11110000
#define RS232_BAYES_HEADER 0b00010000
#define RS232_AC_HEADER 0b00000000
#define RS232_PT_LOG 0b11001100
#define RS232_FT_LOG 0b00110011
#define RS232_RR_LOG 0b11110000
#define RS232_LOG_END 0b00001111
#define RS232_FULL_ONE 0b11111111

//general definition
#define TRUE 1
#define FALSE 0
#define DEBUG 1 

//definition for a hardware based run!
#define SIMULATION 1
//laser altimeter
//#define LOGDATAWIDTH 572 
//buffer overflow
#define LOGDATAWIDTH 21

//if no serial interface is used set to 1
#define FILEUSE 0 //works only with provided .mmc and .dat files! new serialinteraface simulations need recorded serial data from a simulation. first read in main has to be disabled! initial = false

//hardware defined resolution of probabilities (18 bit fix-point)
#define RESOLUTION 0.00000381469727

//char array for binary program first [127] = first entry is amount of 
//data bytes for one communication cycle (up to 126, this is a fixated value), 
//[200] = amount of communication cycles possible, this is variable!
#define COMMUNICATIONCYCLES 200
unsigned char binprogarray [127][COMMUNICATIONCYCLES];

//read buffer for serial interface
unsigned char rs232buffer[5];

//local file handler for testing purposes
int rs232teststimuli;
int rs232writefile;

//serial interface file handler
char *portname;

#endif
