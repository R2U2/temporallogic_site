/**
* @file   functions.c
* @Author Johannes Geist (johannesgeist@nasa.gov)
* @date   February, 2014
* @brief  This file contains function for the rtr2u2 Host software
*
*/

#include "includes.h"
#include "functions.h"

//get a character (0 or 1) and set the corresponding bit with the value in a byte
unsigned char set_bits(unsigned char *bit){
	unsigned char result = 0;
	int i = 0;
	for(i=0; i<8; i++){
		if (*bit == '1'){
			result |= (1 << (7-i));
			bit++;
		}
		else{
			result |= (0 << (7-i));
			bit++;
		}
	}
	return result;
}


void open_file(FILE **file, char *argument, char mode){

	if (mode == 'r'){
		*file = fopen(argument, "r");
	}
	else if (mode == 'w'){
		*file = fopen(argument, "w");
	}
	else {
		exit(EXIT_FAILURE);
	}
	
	if (file == 0){ 
		printf("Couldn't open %s file. Please check if file exists!\n",argument);
		exit(-1); 
	}
}

//read the binary file character wise and write it in the internal data structure
void prepare_binary_program(FILE **binprog, FILE **errorlog, char **program_name){
	unsigned char chtemp;
	unsigned int bit = 0;
	int instructioncounter = 0;
	int s, q;

	column = 0;
	line = 1;

	while(1){
		chtemp = fgetc(*binprog);
		//printf("%c",(char)chtemp);
		if((char)chtemp == '1'){                            
			binprogarray[line][column] |= 1 << (7-bit);
			//printf("%d:%d\n", (unsigned int)binprogarray[y][x],i);
		}
		else if ((char)chtemp == '0'){
			binprogarray[line][column] |= 0 << (7-bit); 
			//printf("%d:%d\n", (unsigned int)binprogarray[y][x],i);
		}
		else if ((char)chtemp == 'X'){
			binprogarray[line][column] |= 0 << (7-bit); 
		}
		else if ((char)chtemp == '\n'){
			if (DEBUG) {
				printf("Instruction #%d has been successfully read!\n",instructioncounter);
				instructioncounter++;     
			}
			continue;
		}
		else if((char) chtemp == EOF){
			printf("\nBinary program %s has been successfully read!\n", *program_name);
			break;
		}
		else{
			fprintf(*errorlog,"The wrong file for the binary program has been set. The file contained the invalid character %c!\n",chtemp);
			printf("Reading binary program failed!\n");
			exit(EXIT_FAILURE);
		}

		if(bit == 7){
			if(line == 126){
				line = 0;
				if(column == 200){
					printf("Reading binary program failed, too many data within the file. Please increase binprogarray size\n");
					fprintf(*errorlog,"Reading binary program failed, too many data within the file. Please increase binprogarray size\n");
					exit(EXIT_FAILURE);	
				}
				//first 1 is to signal bayes or memory interface programming
				//all other 1s are for amount of 8 bit datasets send to the board (126)
				binprogarray[0][column] = 0b11111110;
				column++;
			}
			bit=0;
			line++;
		}
		else{
			// fprintf(errorlog, "%d:%c | ",i,chtemp);
			bit++;
		}
	}

	binprogarray[0][column] = 0b10000000;
	binprogarray[0][column] |= (unsigned char) (line-1);
	
	for(q=0;q<=column;q++){
		fprintf(*errorlog,"-----------line#%d\n",q);
		for(s=0;s<=127;s++){
			fprintf(*errorlog,"%d:%d\n", (unsigned int)binprogarray[s][q],s);
		}
	}
}

//get the result byte and write the value in a file, in text form
void binary_to_text(FILE **log, unsigned int binary_value){
	if(binary_value == 0){
		fprintf(*log,"    false    :");
	}
	else if (binary_value == 1){
		fprintf(*log,"    true     :");
	}
	else if (binary_value == 2){
		fprintf(*log,"    maybe    :");
	}
	else{
		fprintf(*log,"    error    :");
	}
}

//read recorded atomics character wise and write it a internal data structure
void prepare_atomics_input(FILE **inputfile, FILE **errorlog, unsigned char *atomicsinput, char **file_name){
	unsigned char chtemp;
	unsigned int e=0;
	unsigned int p=0;
	
	while(1){
		chtemp = fgetc(*inputfile);
		if ((char)chtemp == '1'){                            
			atomicsinput[p] |= 1 << (7-e);
		}
		else if ((char)chtemp == '0'){
			atomicsinput[p] |= 0 << (7-e); 
		}
		else if ((char)chtemp == 'X'){
			atomicsinput[p] |= 0 << (7-e); 
		}
		else if ((char)chtemp == '\n'){
			p=0;
			e=0;
			break;
		}
		else if ((char)chtemp == EOF){
			printf("\nSimulation data file %s has been successfully read and applied!\n",*file_name);
			exit(EXIT_SUCCESS);
		}
		else{
			fprintf(*errorlog,"The wrong file for the simulation inputs has been set. The file contained the invalid character %c!\n",chtemp);
			printf("Reading simulation data file failed!\n");
			exit(EXIT_FAILURE);
		}

		if(e==7){
			fprintf(*errorlog,"p:%d : %02X\n",p,atomicsinput[p]);
			e=0;
			p++;
		}
		else{
			e++;
		}
	}
}

