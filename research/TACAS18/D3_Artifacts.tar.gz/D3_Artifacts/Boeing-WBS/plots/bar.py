import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter

f = plt.figure() # init the figure module
plt.rc('font', **{'size':20,'family': 'serif', 'serif': ['Times']})
plt.rc('text', usetex=True)
fig = f.add_subplot(111)
f.set_size_inches(12, 4)

N = 7
simple = (179, 236, 234, 227, 227, 248, 248)

ind = np.arange(N)  # the x locations for the groups
width = 0.2       # the width of the bars

# fig, fig = plt.subplots()
rects1 = fig.bar(ind, simple, width, color='r')

checkrp = (23, 23, 20, 25, 16, 21, 21)
rects2 = fig.bar(ind + width, checkrp, width, color='y')

checkrph1 = (10, 11, 11, 11, 11, 11, 11)
rects3 = fig.bar(ind + width + width, checkrph1, width, color='g')

checkrph2 = (11, 13, 14, 12, 12, 14, 15)
rects4 = fig.bar(ind + width + width + width, checkrph2, width, color='b')

# sgpa = (10, 11, 11, 12, 11, 14, 11)
# rects5 = fig.bar(ind + width + width + width + width, sgpa, width, color='m')

# add some text for labels, title and figes ticks
fig.set_ylabel('Number of checker \\ runs (log)')
fig.set_xlabel('Model number')
fig.set_xticks(ind + (3*width) / 2)
fig.set_xticklabels(('1', '2', '3', '4', '5', '6', '7'))

fig.legend((rects1[0], rects2[0], rects3[0], rects4[0]),
  ('single', '\\textsc{CheckRP}', '\\textsc{CheckRP + H1}', '\\textsc{CheckRP + H2}'),
  bbox_to_anchor=(0., 1.02, 1., .102),
  loc=1, ncol=5,
  mode="expand", borderaxespad=0.05, fontsize='x-small')
# fig.legend(bbox_to_anchor=(0.01, 0.91, 0.5, 0.), loc=1, ncol=5, mode="expand", borderaxespad=0.05, fontsize='small')
fig.set_yscale('log')
fig.yaxis.set_major_formatter(FormatStrFormatter('%2d'))

# set the aspect ratio
fig.set_aspect('auto')


def autolabel(rects):
    """
    Attach a text label above each bar displaying its height
    """
    for rect in rects:
        height = rect.get_height()
        fig.text(rect.get_x() + rect.get_width()/2., 1.005*height,
                '{\\large %d}' % int(height),
                ha='center', va='bottom')

autolabel(rects1)
autolabel(rects2)
autolabel(rects3)
autolabel(rects4)
# autolabel(rects5)
#
# save the figure
f.savefig("multi_property.pdf", bbox_inches='tight')

plt.show()