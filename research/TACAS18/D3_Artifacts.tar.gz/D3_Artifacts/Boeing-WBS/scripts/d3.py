# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

# This script runs the main d3 procedure on the Boeing-WBS models
# Note: Only property reduction is implemented
#
# It generates the reduced set of models, and model checks them
# with LTL properties dynamically.
#
# Author: Rohit Dureja <dureja@iastate.edu>

from property_dependence import find_dependencies
from extract_properties import get_properties
from dispatch import PropertyDispatch
import csv
import json
import time
import os
import shutil
import subprocess
import argparse


class ModelChecker:
  def mode_init(self, properties):
    self.pmap = {}
    for prop in properties:
      self.pmap[prop[0]] = prop[1]


  def result_from_file(self, instance, property):

    result_file = "../results/instance_" + str(instance) + "_results.json"

    with open(result_file) as json_file:
      data = json.load(json_file)

      return data[property]['result'], data[property]['time']


  def model_check(self, instance, properties):
    model = "../scripts/instances/instance_" + str(instance) + ".smv"

    template = open("../scripts/resources/cmds/check_property.cmd")
    contents = template.read()
    template.close()

    if len(properties) < 2:
      fields = {"model": model,
                "prop": self.pmap[properties[0]]}
    else:
      names = [self.pmap[property] for property in properties]
      fields = {"model": model,
                "prop": ' & '.join(names)}

    new = contents.format(**fields)

    # create a tmp directory if one doesn't exists
    if os.path.exists("checktemp" + str(instance) + "/") == False:
      os.mkdir("checktemp" + str(instance) + "/")

    # create the temporary cmd to send to nuXmv
    cmdfile = open("checktemp" + str(instance) + "/check.cmd", "w")
    cmdfile.write(new)
    cmdfile.close()

    # get the results from nuXmv
    [text_result, error] = run_nuXmv("../tools/nuXmv/bin/nuXmv -source checktemp" + str(instance) + "/check.cmd")
    if os.path.exists("checktemp" + str(instance) + "/") == True:
      shutil.rmtree("checktemp" + str(instance) + "/")
    if error == None:
      if "true" in text_result:
        return 'true'
      elif 'unknown' in text_result:
        return None
      else:
        return 'false'

# run nuXmv with the supplied cmd file
def run_nuXmv(binary, options = None):
  command = [binary]
  # for option in options:
  #   command.append(option)
  try:
    out = subprocess.check_output(binary, shell=True)
    return [out, None]
  except subprocess.CalledProcessError as err:
    return [None, err.returncode]

def dependence_find(instance):
  start = time.time()
  results = find_dependencies(instance)
  json.dump(results, open("../results/instance_" + str(instance) + "_dependencies.json", 'w'))
  end = time.time()
  print 'Time: %f' %(end-start)

def d3(options):
  mode = options.mode
  instance = options.instance
  threshold = options.threshold

  xml_file = "../scripts/instances/properties_" + str(instance) + ".xml"
  properties = get_properties(xml_file)
  dispatcher = PropertyDispatch([p[0] for p in properties], mode, instance, threshold)

  # read dependence
  dependencies = json.load(open("../results/instance_" + str(instance) + "_dependencies.json"))
  for relation in dependencies.keys():
    for dependence in dependencies[relation]:
      dispatcher.add_dependence(dependence[0], dependence[1], relation)


  mc = ModelChecker()
  mc.mode_init(properties)
  prop = dispatcher.get_property()

  ttime = 0
  ctr = 0
  while prop != None:
    (p1, p2) = prop
    if p2 == None:
      if options.not_storage:
        start = time.time()
        r1 = mc.model_check(instance, [p1])
        end = time.time()
        ttime = ttime + (end-start)
      else:
        r1, t1 = mc.result_from_file(instance, p1)
        ttime = ttime + t1
      result = True if r1 == 'true' else False
      dispatcher.add_verification_result(p1, result)
      ctr = ctr + 1
    else:
      if options.not_storage:
        start = time.time()
        r = mc.model_check(instance, [p1, p2])
        end = time.time()
        if r != None:
          ctr = ctr + 1
          ttime = ttime + (end-start)
        if r == 'true':
	  res = True
        elif r == 'false':
          res = False
        else:
	  res = None
      else:
        r1, t1 = mc.result_from_file(instance, p1)
        r2, t2 = mc.result_from_file(instance, p2)
        res = bool(r1) & bool(r2)
        ttime = ttime + t1 + t2
        ctr = ctr + 1

      if res:
        dispatcher.add_verification_result(p1, res)
        dispatcher.add_verification_result(p2, res)
      # remove node from affinity graph
      dispatcher.remove_node(p1)
      dispatcher.remove_node(p2)


    prop = dispatcher.get_property()

  print "Total properties checked: %d" %ctr
  print "Time: %f" %ttime

def individualcheck(instance):
  xml_file = "../scripts/instances/properties_" + str(instance) + ".xml"
  properties = get_properties(xml_file)
  mc = ModelChecker()
  mc.mode_init(properties)
  results = {}
  total_time = 0
  for property in properties:
    results[property[0]] = {}
    start = time.time()
    res = mc.model_check(instance, [property[0]])
    end = time.time()
    elapsed = end - start
    # print property[0], res
    results[property[0]]['time'] = elapsed
    results[property[0]]['result'] = res
    total_time = total_time + elapsed

  json.dump(results, open("../results/instance_" + str(instance) + "_results.json", 'w'))
  print 'Total properties checked: %d' %(len(properties))
  print 'Time: %f' %total_time

def parse_cmdline_args():
  # parse options
  parser = argparse.ArgumentParser(
    description='Run D^3 on the Boeing WBS models')

  # add arguments
  parser.add_argument('-i', dest='instance',
    action='store', required=True,
    type=int,
    help='Model number to check. Value between 1..7')

  parser.add_argument('-m', dest='mode',
    type=int, default = None,
    help = 'Heuristic to use for CheckRP (default = None)\
                \n 1: Maximum Dependence,\
                \n 2: Property Affinity')

  parser.add_argument('-t', dest='threshold',
    type=float, default = 1.0,
    help = 'Threshold to use for Property Affinity heuristic (default = 1.0)')

  parser.add_argument('--perform-checking', dest='not_storage',
    action='store_true', default=False,
    help = 'If specified, model checking is performed using nuXmv.\
            Otherwise, results are read from file (../results/).\
            NOTE: For D^3 with property affinity heuristic, model checking is always performed! ')

  parser.add_argument('--only-dependence', dest='dependence',
    action='store_true', default=False,
    help = 'Establish dependencies for all properties in \
            the model, and store results (../results/)')

  parser.add_argument('--only-individual', dest='individual',
    action='store_true', default=False,
    help = 'Check specified model one-by-one against properties,\
            and store results (../results/)')

  options = parser.parse_args()
  if options.individual:
    print 'Checking model against all properties.'
  elif options.dependence:
    print 'Only finding dependencies between properties for the model.'
  elif options.mode == None:
    print 'Running D^3 without any heuristic.'
  elif options.mode == 1:
    print 'Running D^3 with Maximum Dependence heuristic.'
  elif options.mode == 2:
    print 'Running D^3 with Property Affinity heuristic.'

  return options

if __name__ == "__main__":
  options = parse_cmdline_args()

  if options.individual:
    individualcheck(options.instance)
  elif options.dependence:
    dependence_find(options.instance)
  else:
    d3(options)
