# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

# Script to find dependencies between two LTL properties
# using LTL Satisfiability checking
import re
import os
import shutil
import subprocess
from extract_properties import get_properties
import xml.etree.ElementTree

LTLSAT_CMD_TEMPLATE = "../scripts/resources/cmds/ltlsat_template.cmd"
TMP_DIR = "ltltemp7/"
TEMPORARY_CMD = "temp.cmd"

UNIVERSAL_MODEL = "../scripts/instances/universal_"
PROPERTIES_XML = "../scripts/instances/properties_"


def find_dependencies(mode):

	MODEL = UNIVERSAL_MODEL + str(mode) + ".smv"
	XML_FILE = PROPERTIES_XML + str(mode) + ".xml"
	print MODEL

	read_properties = get_properties(XML_FILE)
	relations = ["(a->b)", "(!a->b)", "(!a->!b)"]

	print "Number of LTL properties: " + str(len(read_properties))

	results = {}
	results[relations[0]] = []
	results[relations[1]] = []
	results[relations[2]] = []

	for i in range(len(read_properties)):
		for j in range(len(read_properties)):
			if i != j:
				res = check_satisfiability(read_properties[i], read_properties[j], MODEL, relations[0])
				if res == 'unsat':
					results[relations[0]].append((read_properties[i][0], read_properties[j][0]))
	# remove the tmp directory
	shutil.rmtree(TMP_DIR, ignore_errors=True)

	return results

# check the satisfiability of the two properties against the universal model.
def check_satisfiability(property1, property2, model, relation):
	# open the ltlsat template file
	template = open(LTLSAT_CMD_TEMPLATE, "r")

	# read the contents and close the file
	contents = template.read()
	template.close()

	p1 = property1[1]
	p2 = property2[1]

	if relation == "(!a->b)":
		p1 = "!" + p1

	if relation == "(!a->!b)":
		p1 = "!" + p1
		p2 = "!" + p2
	# set the parameters
	fields = {'universal_model': model,
						'prop1' : p1,
						'prop2' : p2}

	# generate the resulting file contents
	new = contents.format(**fields)

	# create a tmp directory if one doesn't exists
	if os.path.exists(TMP_DIR) == False:
		os.mkdir(TMP_DIR)

	# create the temporary cmd to send to nuXmv
	cmdfile = open(TMP_DIR+TEMPORARY_CMD, "w")
	cmdfile.write(new)
	cmdfile.close()

	# get the results from nuXmv
	# print TMP_DIR+TEMPORARY_CMD
	[text_result, error] = run_nuXmv("../tools/nuXmv/bin/nuXmv",["-source", TMP_DIR+TEMPORARY_CMD])
	if error == None:
		if "false" not in text_result:
			return 'unsat'
		else:
			print property1[0], property2[0], "sat"
			return 'sat'

# run nuXmv with the supplied cmd file
def run_nuXmv(binary, options = None):
	command = [binary]
	for option in options:
		command.append(option)

	try:
		out = subprocess.check_output("../tools/nuXmv/bin/nuXmv -source " + TMP_DIR + "temp.cmd", shell=True)
		return [out, None]
	except subprocess.CalledProcessError as err:
		return [None, err.returncode]


if __name__ == "__main__":
    main()