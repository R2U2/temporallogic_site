# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

# Class file for Dispatch properties
# Author: Rohit Dureja
import sys
from sets import Set
import grouping
from coi import get_coi_vars

class Node(object):
  def __init__(self, value):
    self.value = value

class PropertyDispatch:
	# constructor function
	# properties: a list of property [name, property] to be checked
	# mode = 1 or 2
	# 			(1: maximum dependence)
	# 			(2: property affinity)
	# instance: current model number being checked (used to find coi)
	# threshold: value for heuristic 2
	def __init__(self, properties, mode = None, instance = None, threshold = None):
		self.properties = properties
		self.mode = mode
		self.instance = instance
		self.threshold = threshold

		# store the property verification results
		self.property_result = []
		for prop in self.properties:
			self.property_result.append(None)

		# stores the dependence graph
		self.dependence_graph = {}

		# stores the properties for verification order
		self.property_queue = []

		# initially, without and dependence, all properties are in queue
		for prop in properties:
			self.property_queue.append(prop)

		# if heuristic 2 is selected; generate graph for properties
		# based on Jaccard index
		if self.mode == 2:
			# find coi for all properties
			self.p_coi = []
			for i in range(len(self.properties)):
				p = properties[i]
				coi = get_coi_vars(self.instance, p)
				self.p_coi.append(coi)

			# graph for paired properties
			self.node_list = []
			self.graph = {}
			for i in range(len(self.properties)):
				self.node_list.append(Node(i))
				self.graph[self.node_list[i]] = []

			# find Jaccard index for paired properties
			for i in range(len(self.properties)-1):
				node = list()
				p1_coi = self.p_coi[i]
				for j in range(i+1, len(self.properties)):
					if i == j:
						print 'Error'
						break
					p2_coi = self.p_coi[j]
					idx = float(len(p1_coi.intersection(p2_coi)))/(len(p1_coi) + len(p2_coi) - len(p1_coi.intersection(p2_coi)))
					if idx >= self.threshold:
						node.append(self.node_list[j])
				for n in node:
					self.graph[self.node_list[i]].append(n)
					self.graph[n].append(self.node_list[i])

			pairs = list(grouping.generate_pairs(self.graph))
			for (i,j) in pairs:
				p1_coi = self.p_coi[i]
				p2_coi = self.p_coi[j]

	def remove_node(self, property):
		if self.mode == 2:
			idx = self.properties.index(property)
			self.node_list[idx].value = None

	def get_property(self):

		if len(self.property_queue) > 0:
			# H1 #######################
			if self.mode == 1:
				counts = [len(self.dependence_graph[node][True].keys()) for node in self.dependence_graph]
				pindexes = [node for node in self.dependence_graph.keys()]
				index = counts.index(max(counts))
				prop = pindexes[index]
				return (self.property_queue[self.property_queue.index(prop)], None)
			# ##########################

			# Default ##################
			if self.mode == None:
				return (self.property_queue[0], None)
			############################

			# H2 #######################
			if self.mode == 2:
				pairs = list(grouping.generate_pairs(self.graph))
				if len(pairs) > 0:
					max_score = 0
					for (i,j) in pairs:
						p1_coi = self.p_coi[i]
						p2_coi = self.p_coi[j]
						score = float(len(p1_coi.intersection(p2_coi)))/(len(p1_coi) + len(p2_coi) - len(p1_coi.intersection(p2_coi)))
						if score > max_score:
							max_score = score
							max_pair = (i,j)
					return (self.properties[i], self.properties[j])
				else:
				 return (self.property_queue[0], None)
			############################
		else:
			# print "No properties in queue"
			if None in self.property_result:
				print "Properties still remaining"
				sys.exit()
			return None

	# returns the dependence relation for the properties
	def __mode(self, dependence):
		if dependence == "(!a->!b)":
			return False, False, False
		if dependence == "(a->b)":
			return True, True, False
		if dependence == "(!a->b)":
			return False, True, False
		print "Incorrent dependence specified. Has to be one of the following choices:"
		print "1. (!a->!b)"
		print "2. (a->b)"
		print "3. (!a->b)"
		return 0, 0, True

	# adds a property to the dependence graph
	def __add_property(self, propertyname):
		self.dependence_graph[propertyname] = {True : {}, False: {}}

	def get_results(self):
		return self.property_result

	def get_graph(self):
		return self.dependence_graph

	# add a dependence relation to the graph
	def add_dependence(self, property1, property2, dependence):
		a, b, Error = self.__mode(dependence)
		if Error:
			return 0
		else:
			if property1 not in self.dependence_graph:
				self.__add_property(property1)
			self.dependence_graph[property1][a][property2] = b

			# add the property to the queue
			if property1 not in self.property_queue:
				self.property_queue.append(property1)

	# remove a dependence for the graph
	def __remove_property(self, propertyname):
		return self.dependence_graph.pop(propertyname, None)

	def add_verification_result(self, propertyname, result):
		if result == None:
			idx = self.properties.index(propertyname)
			self.property_result[idx] = 'NA'

			# remove the property from the queue
			self.property_queue.pop(self.property_queue.index(propertyname))

		else:

			# print propertyname, ": ", result
			# add the verification result
			idx = self.properties.index(propertyname)
			self.property_result[idx] = result

			# remove the property from the queue
			try:
				self.property_queue.pop(self.property_queue.index(propertyname))
			except:
				pass
			# print self.property_result

			# remove the property from the dependence graph if it exists
			if propertyname in self.dependence_graph:
				pproperties = self.__remove_property(propertyname)
				dep_properties = pproperties[result] # returns a dictionary
				# add the dependent properties to the local queue
				local_queue = dep_properties

				# the properties discovered NOT dependent are added to property queue
				for prop in pproperties[not result]:
					# add the property to the queue
					if prop not in self.property_queue:
						idx = self.properties.index(prop)
						if self.property_result[idx] == None:
							self.property_queue.append(prop)
							# print "Added to queue: ", prop

				# Perform BFS on the graph
				while local_queue != {}:
					props = local_queue.keys()
					for prop in props:
						# remove the property if it was in property verification queue
						if prop in self.property_queue:
							# print prop
							self.property_queue.remove(prop)
							self.remove_node(prop)
							# print "LOCAL", local_queue
							# print propertyname, " made ", prop, local_queue[prop]
							# print "Removed from queue: ", prop

						# add the verification result
						idx = self.properties.index(prop)
						if self.property_result[idx] == None:
							self.property_result[idx] = local_queue[prop]
						elif self.property_result[idx] == 'NA':
							print "Nice!"
							self.property_result[idx] = local_queue[prop]
						else: # result was already determined. check if there is a mismatch
							if self.property_result[idx] != local_queue[prop]:
								print "Mismatch!"
								sys.exit()
							else:
								None
								# print "The result correlates"

						# remove the property from the dependence graph if it exists
						if prop in self.dependence_graph:
							dep_properties = self.__remove_property(prop)[local_queue[prop]] # returns a dictionary
							# print "DEP", dep_properties
							local_queue[prop] = dep_properties

						# remove prop from the local queue
						# print "LLOO", local_queue
						local_queue.pop(prop, None)
						# print "LLOO", local_queue

				# print self.dependence_graph
				# print self.property_result
				# print self.property_queue



