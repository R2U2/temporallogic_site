set pp_list cpp
read_model -i {model}

go_bmc

write_coi_model -P {property} -C -o {outputfile}
quit