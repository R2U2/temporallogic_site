# script to check property with model

set on_failure_script_quits 1
set pp_list cpp
set counter_examples 0
set disable_syntactic_checks 1

# read the model
read_model -i {model}

# construct the fsm
go_bmc

# check the property for the model
check_property_as_invar_ic3 -L "{prop}"

quit
