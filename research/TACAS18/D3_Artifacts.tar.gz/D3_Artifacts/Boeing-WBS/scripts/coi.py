# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

import os
import shutil
import subprocess
from sets import Set

INSTANCES_FOLDER = "../scripts/instances/"
COI_CMD_TEMPLATE = "../scripts/resources/cmds/coi_variables.cmd"
TEMP_DIR = "coi_temp/"
TEMPORARY_CMD = "coi.cmd"

def get_coi_vars(instance, property):

  modelfile = "instance_" + str(instance) + ".smv"
  template = open(COI_CMD_TEMPLATE, 'r')

  contents = template.read()
  template.close()

  model = INSTANCES_FOLDER + modelfile

  fields = {'model': model,
            'property': property,
            'outputfile': TEMP_DIR+"vars.txt"}

  new = contents.format(**fields)

  # create a tmp directory if one doesn't exists
  if os.path.exists(TEMP_DIR) == False:
    os.mkdir(TEMP_DIR)

  # create the temporary cmd to send to nuXmv
  cmdfile = open(TEMP_DIR+TEMPORARY_CMD, "w")
  cmdfile.write(new)
  cmdfile.close()

  # get the results from nuXmv
  # print TEMP_DIR+TEMPORARY_CMD
  [text_result, error] = run_nuXmv("../tools/nuXmv/bin/nuXmv",["-source", TEMP_DIR+TEMPORARY_CMD])

  varfile = open(TEMP_DIR + "vars.txt", 'r')
  next(varfile)

  variables = ""
  for line in varfile:
    variables = variables + line.strip()

  varfile.close()
  variables = (variables.strip().replace('{', "").replace('}', "")).split(',')

  vars = Set()
  for v in variables:
    vars.add(str(v))

  # remove the tmp directory
  shutil.rmtree(TEMP_DIR, ignore_errors=True)

  return vars



# run nuXmv with the supplied cmd file
def run_nuXmv(binary, options = None):
  command = [binary]
  for option in options:
    command.append(option)

  try:
    out = subprocess.check_output("../tools/nuXmv/bin/nuXmv -source coi_temp/coi.cmd", shell=True)
    return [out, None]
  except subprocess.CalledProcessError as err:
    return [None, err.returncode]


if __name__ == "__main__":
    get_coi_vars(1, 'airspace_validation', "system_inst.ac_1.AC_maneuver_norm_guarantee")