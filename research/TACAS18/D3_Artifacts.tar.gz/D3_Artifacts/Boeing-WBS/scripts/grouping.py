# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.


class Node(object):
  def __init__(self, value, weight = None):
    self.value = value

def generate_pairs(nodes):
  """Generate pairs. Weed out duplicates."""
  visited_ids = set()
  for node_a_id in nodes:
    if node_a_id.value == None:
      continue
    for node_b_id in nodes[node_a_id]:
      if node_b_id.value == None:
        continue
      if node_b_id == node_a_id:
        raise ValueError # nodes shouldn't point to themselves
      if node_b_id in visited_ids:
        continue # we should have already found b->a
      yield(node_a_id.value, node_b_id.value)
    visited_ids.add(node_a_id)


def generate_triangles(nodes):
  """Generate triangles. Weed out duplicates."""
  visited_ids = set() # remember the nodes that we have tested already
  for node_a_id in nodes:
    if node_a_id.value == None:
      continue
    for node_b_id in nodes[node_a_id]:
      if node_b_id.value == None:
        continue
      if node_b_id == node_a_id:
        raise ValueError # nodes shouldn't point to themselves
      if node_b_id in visited_ids:
        continue # we should have already found b->a->??->b
      for node_c_id in nodes[node_b_id]:
        if node_c_id.value == None:
          continue
        if node_c_id in visited_ids:
          continue # we should have already found c->a->b->c
        if node_a_id in nodes[node_c_id]:
          yield([(node_a_id.value, node_b_id.value),
            (node_b_id.value, node_c_id.value),
            (node_c_id.value, node_a_id.value)])
    visited_ids.add(node_a_id) # don't search a - we already have all those cycles

def generate_quadrangles(nodes):
  """Generate quadrangles. Weed out duplicates."""
  visited_ids = set() # remember nodes that we have tested already
  for node_a_id in nodes:
    if node_a_id.value == None:
      continue
    for node_b_id in nodes[node_a_id]:
      if node_b_id.value == None:
        continue
      if node_b_id == node_a_id:
        raise ValueError
      if node_b_id in visited_ids:
        continue # we should have already found b->a->??->??->b
      for node_c_id in nodes[node_b_id]:
        if node_c_id.value == None:
          continue
        if node_c_id == node_b_id:
          raise ValueError
        if node_c_id == node_a_id:
          continue # we do not need a->b->a->??
        if node_c_id in visited_ids:
          continue
        for node_d_id in nodes[node_c_id]:
          if node_d_id.value == None:
            continue
          if node_d_id == node_c_id:
            raise ValueError
          if node_d_id == node_b_id:
            continue
          if node_d_id == node_c_id:
            continue
          if node_d_id in visited_ids:
            continue
          if node_a_id in nodes[node_d_id]:
            yield(node_a_id.value, node_b_id.value, node_c_id.value, node_d_id.value)
    visited_ids.add(node_a_id)

def generate_pentagons(nodes):
  """Generate pentagons. Weed out duplicates."""
  visited_ids = set() # remember nodes that we have tested already
  for node_a_id in nodes:
    if node_a_id.value == None:
      continue
    for node_b_id in nodes[node_a_id]:
      if node_b_id.value == None:
        continue
      if node_b_id == node_a_id:
        raise ValueError
      if node_b_id in visited_ids:
        continue # we should have already found b->a->??->??->b
      for node_c_id in nodes[node_b_id]:
        if node_c_id.value == None:
          continue
        if node_c_id == node_b_id:
          raise ValueError
        if node_c_id == node_a_id:
          continue # we do not need a->b->a->??
        if node_c_id in visited_ids:
          continue
        for node_d_id in nodes[node_c_id]:
          if node_d_id.value == None:
            continue
          if node_d_id == node_c_id:
            raise ValueError
          if node_d_id == node_b_id:
            continue
          if node_d_id == node_c_id:
            continue
          if node_d_id in visited_ids:
            continue
          for node_e_id in nodes[node_d_id]:
            if node_e_id.value == None:
              continue
            if node_e_id == node_d_id:
              raise ValueError
            if node_e_id == node_b_id:
              continue
            if node_e_id == node_c_id:
              continue
            if node_e_id == node_d_id:
              continue
            if node_e_id in visited_ids:
              continue
            if node_a_id in nodes[node_e_id]:
              yield(node_a_id.value, node_b_id.value, node_c_id.value, node_d_id.value, node_e_id.value)
    visited_ids.add(node_a_id)
