#!/bin/bash
# get nuXmv 1.1.1
NUXMV_TAR="nuXmv-1.1.0-linux64.tar.gz"
NUXMV_FOLDER="nuXmv-1.1.0-Linux"
wget --no-parent https://es.fbk.eu/tools/nuxmv/downloads/nuXmv-1.1.0-linux64.tar.gz
tar -xf $NUXMV_TAR
mv $NUXMV_FOLDER nuXmv
rm $NUXMV_TAR

# get OCRA
OCRA_TAR="ocra.tar.bz2"
OCRA_FOLDER="ocra-1.4.0"
wget --no-parent https://es.fbk.eu/tools/ocra/download/ocra.tar.bz2
tar -xf $OCRA_TAR
mv $OCRA_FOLDER ocra
rm $OCRA_TAR
