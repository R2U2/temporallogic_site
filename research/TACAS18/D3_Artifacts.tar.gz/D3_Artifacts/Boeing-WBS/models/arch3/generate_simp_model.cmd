read_model -i wbs_arch3.smv
flatten_hierarchy
build_flat_model
write_simplified_model_rel -r -o wbs_arch3_simp.smv
quit
