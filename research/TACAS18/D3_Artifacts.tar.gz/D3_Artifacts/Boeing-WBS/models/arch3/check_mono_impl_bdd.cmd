read_model -i wbs_arch3_simp.smv
go
check_property
time
show_property
quit
