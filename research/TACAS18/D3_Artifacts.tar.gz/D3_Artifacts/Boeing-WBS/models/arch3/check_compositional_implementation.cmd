time
ocra_check_composite_impl -i wbs_arch3.oss -m wbs_arch3.map -R
time
quit
