time
ocra_print_implementation_template -i wbs_arch3.oss -m wbs_arch3.map
time
quit
