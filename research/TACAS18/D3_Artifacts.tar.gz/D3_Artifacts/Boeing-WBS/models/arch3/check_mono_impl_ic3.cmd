read_model -i wbs_arch3.smv
go_bmc
check_property_as_invar_ic3
time
show_property
quit
