read_model -i wbs_arch1.smv
flatten_hierarchy
build_flat_model
write_simplified_model_rel -r -o wbs_arch1_simp.smv
quit
