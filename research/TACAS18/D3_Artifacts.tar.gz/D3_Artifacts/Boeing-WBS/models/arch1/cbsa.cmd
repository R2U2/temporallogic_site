set on_failure_script_quits
set dynamic_reorder 1
set bmc_length 3
ocra_compute_fault_tree -i wbs_arch1.oss -a ic3 -m wbs_arch1.map -x out/expanded_wbs_arch1.xml
time
quit
