time
ocra_check_composite_impl -i wbs_arch1.oss -m wbs_arch1.map -R
time
quit
