ocra_check_consistency -i wbs_arch1.oss
time
ocra_check_refinement
time
quit
