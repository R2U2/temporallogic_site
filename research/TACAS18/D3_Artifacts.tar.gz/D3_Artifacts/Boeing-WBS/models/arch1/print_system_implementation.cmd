set on_failure_script_quits 1
set ocra_discrete_time 1
time
ocra_print_system_implementation -i wbs_arch1.oss -m wbs_arch1.map -o wbs_arch1.smv
time
quit
