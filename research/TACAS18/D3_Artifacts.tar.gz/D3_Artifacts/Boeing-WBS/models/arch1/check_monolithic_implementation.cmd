read_model -i wbs_arch1.smv
go_bmc
time
check_property_as_invar_ic3
time
show_property
quit
