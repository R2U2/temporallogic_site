time
ocra_check_composite_impl -i wbs_arch2bis.oss -m wbs_arch2.map -R
time
quit
