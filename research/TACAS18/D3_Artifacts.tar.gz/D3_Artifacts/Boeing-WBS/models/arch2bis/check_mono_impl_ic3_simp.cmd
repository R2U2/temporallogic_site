read_model -i wbs_arch2bis_simp.smv
go_bmc
check_property_as_invar_ic3
time
show_property
quit
