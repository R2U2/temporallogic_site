read_model -i wbs_arch2bis.smv
flatten_hierarchy
build_flat_model
write_simplified_model_rel -r -o wbs_arch2bis_simp.smv
quit
