ocra_check_consistency -i wbs_arch2bis.oss
time
ocra_check_refinement
time
quit
