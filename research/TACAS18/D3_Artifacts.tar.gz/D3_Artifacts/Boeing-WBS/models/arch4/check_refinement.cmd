ocra_check_consistency -i wbs_arch4.oss
time
ocra_check_refinement
time
quit
