set on_failure_script_quits 1
set ocra_discrete_time 1
time
ocra_print_system_implementation -i wbs_arch4.oss -m wbs_arch4.map -o wbs_arch4.smv
time
quit
