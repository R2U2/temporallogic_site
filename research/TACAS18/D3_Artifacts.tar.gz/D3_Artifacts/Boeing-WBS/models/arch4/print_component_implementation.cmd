time
ocra_print_implementation_template -i wbs_arch4.oss -m wbs_arch4.map
time
quit
