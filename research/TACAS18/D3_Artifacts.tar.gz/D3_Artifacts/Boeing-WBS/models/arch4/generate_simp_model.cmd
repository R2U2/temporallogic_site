read_model -i wbs_arch4.smv
flatten_hierarchy
build_flat_model
write_simplified_model_rel -r -o wbs_arch4_simp.smv
quit
