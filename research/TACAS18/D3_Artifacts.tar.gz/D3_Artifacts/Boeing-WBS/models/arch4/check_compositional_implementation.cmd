time
ocra_check_composite_impl -i wbs_arch4.oss -m wbs_arch4.map -R
time
quit
