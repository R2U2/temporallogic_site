read_model -i wbs_arch2_simp.smv
go
check_property
time
show_property
quit
