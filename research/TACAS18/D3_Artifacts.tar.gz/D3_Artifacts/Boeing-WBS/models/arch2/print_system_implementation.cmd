set on_failure_script_quits 1
set ocra_discrete_time 1
time
ocra_print_system_implementation -i wbs_arch2.oss -m wbs_arch2.map -o wbs_arch2.smv
time
quit
