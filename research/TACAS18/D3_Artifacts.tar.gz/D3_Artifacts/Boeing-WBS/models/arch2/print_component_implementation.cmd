time
ocra_print_implementation_template -i wbs_arch2.oss -m wbs_arch2.map
time
quit
