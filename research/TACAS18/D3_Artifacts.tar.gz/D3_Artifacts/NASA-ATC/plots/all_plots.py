# script to generate combined plots of original and genpc and checkrp
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
import numpy as np
import json
import math
from random import shuffle
from matplotlib import rc


ctr1 = [39, 0, 0, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 39, 39, 39, 44, 44, 39, 39, 39, 44, 39, 39, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 39, 39, 39, 44, 44, 39, 39, 39, 50, 39, 39, 50, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 39, 39, 39, 44, 44, 39, 39, 39, 44, 39, 39, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 39, 39, 39, 44, 44, 39, 39, 39, 50, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 39, 39, 39, 44, 44, 39, 39, 39, 50, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 39, 39, 39, 44, 44, 39, 39, 39, 50, 39, 39, 50, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 44, 44, 39, 44, 44, 39, 44, 39, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 50, 44, 39, 50, 50, 50, 50, 50, 50, 50, 44, 39, 50, 49, 39, 50, 39, 50, 50, 44, 50, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 44, 44, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 44, 39, 50, 49, 39, 50, 50, 50, 50, 50, 50, 50, 44, 39, 50, 49, 39, 50, 44, 50, 50, 44, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 50, 44, 39, 50, 50, 50, 50, 50, 50, 50, 50, 39, 50, 50, 39, 50, 39, 50, 50, 44, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 50, 50, 39, 50, 50, 50, 50, 50, 50, 50, 50, 39, 50, 50, 39, 50, 50, 0, 50, 50, 50, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 35, 39, 39, 35, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 44, 39, 35, 44, 44, 35, 44, 39, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 35, 39, 39, 35, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 50, 44, 39, 50, 50, 50, 50, 50, 50, 50, 39, 35, 50, 44, 35, 50, 39, 50, 50, 44, 50, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 44, 44, 35, 44, 44, 35, 44, 44, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 35, 39, 39, 35, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 44, 39, 50, 49, 39, 50, 50, 50, 50, 50, 50, 50, 44, 35, 50, 49, 35, 50, 44, 50, 50, 49, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 50, 44, 39, 50, 50, 50, 50, 50, 50, 50, 39, 35, 50, 50, 35, 50, 39, 50, 50, 44, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 50, 50, 39, 50, 50, 50, 50, 50, 50, 50, 50, 35, 50, 50, 35, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 39, 35, 44, 44, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39, 39, 39, 39, 39, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 39, 35, 50, 44, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 44, 35, 44, 44, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39, 39, 39, 39, 39, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 44, 35, 50, 49, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 39, 35, 50, 50, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 35, 50, 50, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
ctr2 = [42, 0, 0, 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 0, 0, 0, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 46, 46, 46, 46, 46, 46, 0, 0, 0, 46, 46, 46, 46, 46, 46, 46, 46, 46, 0, 0, 0, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 0, 0, 0, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 0, 0, 0, 46, 46, 46, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 0, 0, 0, 45, 45, 45, 45, 45, 45, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 0, 0, 0, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 42, 42, 42, 42, 42, 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]


def main():
	# open the result file for reading the original results
	data_file = open("results_individual.json", "r")

	# load the contents from the file, which creates a new directory
	data_original = json.load(data_file)
	data_file.close()

	# open the result file for reading the genpc results
	data_file = open("results_genpc.json", "r")

	# load the contents from the file, which creates a new directory
	data_genpc = json.load(data_file)
	data_file.close()

	# open the result file for reading the checkrp results
	# data_file = open("collated_results_genpc_checkrp.json", "r")
	data_file = open("results_checkrp.json", "r")

	# load the contents from the file, which creates a new directory
	data_checkrp = json.load(data_file)
	data_file.close()

	# open the result file for reading the genpc + checkrp results
	# data_file = open("collated_results_genpc_checkrp.json", "r")
	data_file = open("results_d3.json", "r")

	# load the contents from the file, which creates a new directory
	data_d3 = json.load(data_file)
	data_file.close()

	# queries on data
	modes = ['airspace_validation', 'nominal_verification',\
				'nominal_validation', 'extended_validation',\
				'extended_verification']

	# #############################################################
	# #   QUERY: 	Generate a cumulative time vs instances plot
	# # 			for mode = nominal_validation and don't include
	# # 			instances that did not complete.
	# #	  NAME:	fig60.jpg
	# #############################################################
	mode = modes[2] # set mode to nominal_validation

	# original
	x1 = [] # x-values. will store in the instance number
	y1 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_original.keys():
		instance_time = 0
		if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
				data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
					instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x1.append(ctr)
			y1.append(time)
		ctr = ctr + 1

	# print the incomplete instances
	# print mode, "incomplete instances = ", len(incomplete)

	# genpc
	x2 = [] # x-values. will store in the instance number
	y2 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_genpc.keys():
		instance_time = 0
		if data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
				data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
					instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x2.append(ctr)
			y2.append(time)
		ctr = ctr + 1

	# genpc + checkrp
	x3 = [] # x-values. will store in the instance number
	y3 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 0.2
	ctr = 1
	for config in data_d3.keys():
		instance_time = 0
		if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
					data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
						instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x3.append(ctr)
			y3.append(time)
		ctr = ctr + 1

	# checkrp
	x4 = [] # x-values. will store in the instance number
	y4 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 0.2
	ctr = 1
	for config in data_checkrp.keys():
		instance_time = 0
		if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
					data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
						instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x4.append(ctr)
			y4.append(time)
		ctr = ctr + 1

	# plot the figure
	f = plt.figure() # init the figure module
	plt.rc('font', **{'size' : 26, 'family': 'serif', 'serif': ['Times']})
	plt.rc('text', usetex=True)
	plt.rcParams['xtick.major.size'] = 10
	plt.rcParams['xtick.major.width'] = 1
	plt.rcParams['xtick.minor.size'] = 5
	plt.rcParams['xtick.minor.width'] = 0.5
	plt.rcParams['ytick.major.size'] = 10
	plt.rcParams['ytick.major.width'] = 1
	plt.rcParams['ytick.minor.size'] = 5
	plt.rcParams['ytick.minor.width'] = 0.5
	f.set_size_inches(9, 6.5)
	fig = f.add_subplot(111)

	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 400)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

	# generate the y-axis major ticks
	y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 4)
	y_majorticks=  np.append(y_majorticks, y1[-1])
	# y_majorticks=  np.append(y_majorticks, y2[-1])
	y_majorticks=  np.append(y_majorticks, y3[-1])
	# y_majorticks=  np.append(y_majorticks, y4[-1])

	# generate the y-axis minor ticks
	y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+1, 0.4)

	# set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Count of configured instances (models)")
	fig.set_ylabel("Model checking time (in hours)")
	# fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
	# string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
	# fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
	fig.plot(x1,y1, '-bo', label='\\textsf{individual}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
	fig.plot(x2,y2, '-rs', label='\\textsc{GenPC}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
	fig.plot(x4,y4, '-c^', label='\\textsc{CheckRP + H1}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
	fig.plot(x3,y3, '-gd', label='\\textsc{$D^3$ + H1}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
	fig.legend(bbox_to_anchor=(0.01, 0.91, 0.5, 0.), loc=1, ncol=1, mode="expand", borderaxespad=0.05, fontsize='small')

	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# # enable the grid
	fig.grid(which='minor', alpha=0.1)
	fig.grid(which='major', alpha=0.3)

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+2])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	fig.set_aspect('auto')

	# # save the figure
	f.savefig("phase2_timing.jpg", bbox_inches='tight')


	# #############################################################
	# #   QUERY: 	Generate a cumulative time vs instances plot
	# # 			for mode = extended_validation and don't include
	# # 			instances that did not complete.
	# #	  NAME:	fig61.jpg
	# #############################################################
	mode = modes[3] # set mode to extended_validation

	# original
	x1 = [] # x-values. will store in the instance number
	y1 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_original.keys():
		instance_time = 0
		if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
				data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
					instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x1.append(ctr)
			y1.append(time)
		ctr = ctr + 1

	# print the incomplete instances
	# print mode, "incomplete instances = ", len(incomplete)

	# genpc
	x2 = [] # x-values. will store in the instance number
	y2 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_genpc.keys():
		instance_time = 0
		if data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
				data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
					instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x2.append(ctr)
			y2.append(time)
		ctr = ctr + 1

	# genpc + checkrp
	x3 = [] # x-values. will store in the instance number
	y3 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 1.5
	ctr = 1
	for config in data_d3.keys():
		instance_time = 0
		if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
					data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
						instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x3.append(ctr)
			y3.append(time)
		ctr = ctr + 1

	# checkrp
	x4 = [] # x-values. will store in the instance number
	y4 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 1.5
	ctr = 1
	for config in data_checkrp.keys():
		instance_time = 0
		if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
					data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
						instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x4.append(ctr)
			y4.append(time)
		ctr = ctr + 1

	# plot the figure
	f = plt.figure() # init the figure module
	plt.rc('font', **{'size':26,'family': 'serif', 'serif': ['Times']})
	plt.rc('text', usetex=True)
	plt.rcParams['xtick.major.size'] = 10
	plt.rcParams['xtick.major.width'] = 1
	plt.rcParams['xtick.minor.size'] = 5
	plt.rcParams['xtick.minor.width'] = 0.5
	plt.rcParams['ytick.major.size'] = 10
	plt.rcParams['ytick.major.width'] = 1
	plt.rcParams['ytick.minor.size'] = 5
	plt.rcParams['ytick.minor.width'] = 0.5
	fig = f.add_subplot(111)
	f.set_size_inches(9, 6.5)

	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 400)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

	# generate the y-axis major ticks
	y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 30)
	y_majorticks =  np.append(y_majorticks, y1[-1])
	# y_majorticks=  np.append(y_majorticks, y2[-1])
	y_majorticks =  np.append(y_majorticks, y3[-1])
	# y_majorticks=  np.append(y_majorticks, y4[-1])

	# generate the y-axis minor ticks
	y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+50, 3)
	print y_majorticks
	print y_minorticks

	# set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Count of configured instances (models)")
	fig.set_ylabel("Model checking time (in hours)")
	# fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
	# string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
	# fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
	fig.plot(x1,y1, '-bo', label='\\textsf{individual}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
	fig.plot(x2,y2, '-rs', label='\\textsc{GenPC}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
	fig.plot(x4,y4, '-c^', label='\\textsc{CheckRP + H1}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
	fig.plot(x3,y3, '-gd', label='\\textsc{$D^3$ + H1}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
	fig.legend(bbox_to_anchor=(0.01, 0.91, 0.5, 0.), loc=1, ncol=1, mode="expand", borderaxespad=0.05, fontsize='small')

	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# # enable the grid
	fig.grid(which='minor', alpha=0.1)
	fig.grid(which='major', alpha=0.3)

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+2])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	fig.set_aspect('auto')

	# # save the figure
	f.savefig("phase3_timing.jpg", bbox_inches='tight')

	#############################################################
	#   QUERY: 	Generate a cumulative time vs instances plot
	# 			for mode = nominal_verification and don't include
	# 			instances that did not complete.
	#	  NAME:	fig62.jpg
	#############################################################
	mode = modes[1] # set mode to nominal_verification

	# original
	x1 = [] # x-values. will store in the instance number
	y1 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_original.keys():
		instance_time = 0
		if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x1.append(ctr)
			y1.append(time)
		ctr = ctr + 1

	# print the incomplete instances
	# print mode, "incomplete instances = ", len(incomplete)

	# genpc
	x2 = [] # x-values. will store in the instance number
	y2 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_genpc.keys():
		instance_time = 0
		if data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x2.append(ctr)
			y2.append(time)
		ctr = ctr + 1

	# genpc + checkrp
	x3 = [] # x-values. will store in the instance number
	y3 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 0.9
	ctr = 1
	for config in data_d3.keys():
		instance_time = 0
		if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x3.append(ctr)
			y3.append(time)
		ctr = ctr + 1

	# checkrp
	x4 = [] # x-values. will store in the instance number
	y4 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 0.9
	ctr = 1
	for config in data_checkrp.keys():
		instance_time = 0
		if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x4.append(ctr)
			y4.append(time)
		ctr = ctr + 1

	# plot the figure
	f = plt.figure() # init the figure module
	plt.rc('font', **{'size':26,'family': 'serif', 'serif': ['Times']})
	plt.rc('text', usetex=True)
	plt.rcParams['xtick.major.size'] = 10
	plt.rcParams['xtick.major.width'] = 1
	plt.rcParams['xtick.minor.size'] = 5
	plt.rcParams['xtick.minor.width'] = 0.5
	plt.rcParams['ytick.major.size'] = 10
	plt.rcParams['ytick.major.width'] = 1
	plt.rcParams['ytick.minor.size'] = 5
	plt.rcParams['ytick.minor.width'] = 0.5
	fig = f.add_subplot(111)
	f.set_size_inches(9, 6.5)

	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 400)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

	# generate the y-axis major ticks
	y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 7)
	y_majorticks[-2] =  y3[-1]
	y_majorticks =  np.append(y_majorticks, y1[-1])
	# y_majorticks =  np.append(y_majorticks, y3[-1])
	# y_majorticks=  np.append(y_majorticks, y4[-1])

	# generate the y-axis minor ticks
	y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+4, 1)
	print y_majorticks
	print y_minorticks

	# set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Count of configured instances (models)")
	fig.set_ylabel("Model checking time (in hours)")
	# fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
	# string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
	# fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
	fig.plot(x1,y1, '-bo', label='\\textsf{individual}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
	fig.plot(x2,y2, '-rs', label='\\textsc{GenPC}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
	fig.plot(x4,y4, '-c^', label='\\textsc{CheckRP + H1}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
	fig.plot(x3,y3, '-gd', label='\\textsc{$D^3$ + H1}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
	fig.legend(bbox_to_anchor=(0.01, 0.91, 0.5, 0.), loc=1, ncol=1, mode="expand", borderaxespad=0.05, fontsize='small')

	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# # enable the grid
	fig.grid(which='minor', alpha=0.1)
	fig.grid(which='major', alpha=0.3)

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+2])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	fig.set_aspect('auto')

	# save the figure
	f.savefig("phase4_timing.jpg", bbox_inches='tight')

	#############################################################
	#   QUERY: 	Generate a cumulative time vs instances plot
	# 			for mode = extended verification and don't include
	# 			instances that did not complete.
	#	  NAME:	fig63.jpg
	#############################################################
	mode = modes[4] # set mode to extended_verification

	# original
	x1 = [] # x-values. will store in the instance number
	y1 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_original.keys():
		instance_time = 0
		if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x1.append(ctr)
			y1.append(time)
		ctr = ctr + 1

	# print the incomplete instances
	# print mode, "incomplete instances = ", len(incomplete)

	# genpc
	x2 = [] # x-values. will store in the instance number
	y2 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_genpc.keys():
		instance_time = 0
		if data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x2.append(ctr)
			y2.append(time)
		ctr = ctr + 1

	# genpc + checkrp
	x3 = [] # x-values. will store in the instance number
	y3 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 0.9
	ctr = 1
	for config in data_d3.keys():
		instance_time = 0
		if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x3.append(ctr)
			y3.append(time)
		ctr = ctr + 1

	# checkrp
	x4 = [] # x-values. will store in the instance number
	y4 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 0.9
	ctr = 1
	for config in data_checkrp.keys():
		instance_time = 0
		if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x4.append(ctr)
			y4.append(time)
		ctr = ctr + 1

	# plot the figure
	f = plt.figure() # init the figure module
	plt.rc('font', **{'size':26,'family': 'serif', 'serif': ['Times']})
	plt.rc('text', usetex=True)
	plt.rcParams['xtick.major.size'] = 10
	plt.rcParams['xtick.major.width'] = 1
	plt.rcParams['xtick.minor.size'] = 5
	plt.rcParams['xtick.minor.width'] = 0.5
	plt.rcParams['ytick.major.size'] = 10
	plt.rcParams['ytick.major.width'] = 1
	plt.rcParams['ytick.minor.size'] = 5
	plt.rcParams['ytick.minor.width'] = 0.5
	fig = f.add_subplot(111)
	f.set_size_inches(9, 6.5)

	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 400)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

	# generate the y-axis major ticks
	y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 10)
	y_majorticks[-1] = y1[-1]
	# y_majorticks =  np.append(y_majorticks, y1[-1])
	y_majorticks =  np.append(y_majorticks, y3[-1])
	# y_majorticks[-2] =  y3[-1]
	# y_majorticks=  np.append(y_majorticks, y4[-1])

	# generate the y-axis minor ticks
	y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+4, 1)
	print y_majorticks
	print y_minorticks

# set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Count of configured instances (models)")
	fig.set_ylabel("Model checking time (in hours)")
	# fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
	# string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
	# fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
	fig.plot(x1,y1, '-bo', label='\\textsf{individual}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
	fig.plot(x2,y2, '-rs', label='\\textsc{GenPC}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
	fig.plot(x4,y4, '-c^', label='\\textsc{CheckRP + H1}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
	fig.plot(x3,y3, '-gd', label='\\textsc{$D^3$ + H1}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
	fig.legend(bbox_to_anchor=(0.01, 0.91, 0.5, 0.), loc=1, ncol=1, mode="expand", borderaxespad=0.05, fontsize='small')
	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# # enable the grid
	fig.grid(which='minor', alpha=0.1)
	fig.grid(which='major', alpha=0.3)

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+3])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	fig.set_aspect('auto')

	# save the figure
	f.savefig("phase5_timing.jpg", bbox_inches='tight')

	# 	#############################################################
	# #   QUERY: 	Generate a cumulative time vs instances plot
	# # 			for mode = airspace validation and don't include
	# # 			instances that did not complete.
	# #	  NAME:	fig64.jpg
	# #############################################################
	mode = modes[0] # set mode to airspace_validation

	# original
	x1 = [] # x-values. will store in the instance number
	y1 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_original.keys():
		instance_time = 0
		if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
				data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
					instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x1.append(ctr)
			y1.append(time)
		ctr = ctr + 1

	# print the incomplete instances
	# print mode, "incomplete instances = ", len(incomplete)

	# genpc
	x2 = [] # x-values. will store in the instance number
	y2 = [] # y-values. will store the cumulative time
	incomplete = []

	time = 0
	ctr = 1
	for config in data_genpc.keys():
		instance_time = 0
		if data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
				data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
					instance_time += data_genpc[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x2.append(ctr)
			y2.append(time)
		ctr = ctr + 1

	# genpc + checkrp
	x3 = [] # x-values. will store in the instance number
	y3 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 0.2
	ctr = 1
	for config in data_d3.keys():
		instance_time = 0
		if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					if data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
					data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
						instance_time += data_d3[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x3.append(ctr)
			y3.append(time)
		ctr = ctr + 1

	# checkrp
	x4 = [] # x-values. will store in the instance number
	y4 = [] # y-values. will store the cumulative time
	incomplete = []

	# print "Total instances: ", len(data)
	time = 0.2
	ctr = 1
	for config in data_checkrp.keys():
		instance_time = 0
		if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			# instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					if data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
					data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
						instance_time += data_checkrp[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x4.append(ctr)
			y4.append(time)
		ctr = ctr + 1

	# plot the figure
	f = plt.figure() # init the figure module
	plt.rc('font', **{'size':26,'family': 'serif', 'serif': ['Times']})
	plt.rc('text', usetex=True)
	plt.rcParams['xtick.major.size'] = 10
	plt.rcParams['xtick.major.width'] = 1
	plt.rcParams['xtick.minor.size'] = 5
	plt.rcParams['xtick.minor.width'] = 0.5
	plt.rcParams['ytick.major.size'] = 10
	plt.rcParams['ytick.major.width'] = 1
	plt.rcParams['ytick.minor.size'] = 5
	plt.rcParams['ytick.minor.width'] = 0.5
	fig = f.add_subplot(111)
	f.set_size_inches(9, 6.5)


	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 400)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

	# generate the y-axis major ticks
	y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 2)
	y_majorticks[-1] = y1[-1]
	# y_majorticks =  np.append(y_majorticks, y1[-1])
	# y_majorticks =  np.append(y_majorticks, y3[-1])
	y_majorticks[-2] =  y3[-1]
	# y_majorticks=  np.append(y_majorticks, y4[-1])

	# generate the y-axis minor ticks
	y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+1, 0.2)
	print y_majorticks
	print y_minorticks

	# # set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Count of configured instances (models)")
	fig.set_ylabel("Model checking time (in hours)")
	# fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
	# string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
	# fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
	fig.plot(x1,y1, '-bo', label='\\textsf{individual}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
	fig.plot(x2,y2, '-rs', label='\\textsc{GenPC}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
	fig.plot(x4,y4, '-c^', label='\\textsc{CheckRP + H1}', markevery=100, markersize=15) # plot the main data
	# fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
	fig.plot(x3,y3, '-gd', label='\\textsc{$D^3$ + H1}', markevery=100, markersize=15) # plot the main data
	fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
	fig.legend(bbox_to_anchor=(0.01, 0.91, 0.5, 0.), loc=1, ncol=1, mode="expand", borderaxespad=0.05, fontsize='small')
	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# # enable the grid
	fig.grid(which='minor', alpha=0.1)
	fig.grid(which='major', alpha=0.3)

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+3])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	# fig.set_aspect('auto')

	# # save the figure
	f.savefig("phase1_timing.jpg", bbox_inches='tight')

#############################################################3
	x = [x for x in range(1, 1621)]

	shuffle(ctr2)
	y = [None if a == 0 else a for a in ctr2]

	tr = [z for z in y if z != None]
	mean = np.mean(np.array(tr))
	median = np.median(np.array(tr))
	dev = np.std(np.array(tr))
	print mean, median, dev


	# plot figure for nominal verification
	f = plt.figure() # init the figure module
	plt.rc('font', **{'size' : 12, 'family': 'serif', 'serif': ['Times']})
	plt.rc('text', usetex=True)
	plt.rcParams['xtick.major.size'] = 10
	plt.rcParams['xtick.major.width'] = 1
	plt.rcParams['xtick.minor.size'] = 5
	plt.rcParams['xtick.minor.width'] = 0.5
	plt.rcParams['ytick.major.size'] = 10
	plt.rcParams['ytick.major.width'] = 1
	plt.rcParams['ytick.minor.size'] = 5
	plt.rcParams['ytick.minor.width'] = 0.5
	fig = f.add_subplot(111)

	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 200)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

   # generate the y-axis major ticks
	y_majorticks = np.arange(25, 61, 10)
	# y_majorticks=  np.append(y_majorticks, y[-1])

	# generate the y-axis minor ticks
	y_minorticks = np.arange(25, 61, 1)

	# set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Count of configured instances (models)")
	fig.set_ylabel("Number of LTL \nproperties checked")
	# fig.set_title("Number of LTL properties checked for each instance \n(nominal verification)")
	fig.plot(x,y, 'ro', markersize = 2) # plot the main data
	# fig.plot([0, 1620], [med, med], 'k--') # plot a line for the last data value
	# fig.legend(loc='lower right')

	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# enable the grid
	fig.grid(which='minor', alpha=0.2)
	fig.grid(which='major', alpha=0.5)

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 25, np.amax(y_majorticks)+0.2])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	fig.set_aspect(10)

	# save the figure
	f.savefig("phase4_properties.jpg", bbox_inches='tight')

	shuffle(ctr1)
	y = [None if a == 0 else a for a in ctr1]

	tr = [z for z in y if z != None]
	mean = np.mean(np.array(tr))
	median = np.median(np.array(tr))
	dev = np.std(np.array(tr))
	print mean, median, dev

	# plot figure for nominal verification
	f = plt.figure() # init the figure module
	fig = f.add_subplot(111)

	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 200)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

   # generate the y-axis major ticks
	y_majorticks = np.arange(25, 61, 10)
	# y_majorticks=  np.append(y_majorticks, y[-1])

	# generate the y-axis minor ticks
	y_minorticks = np.arange(25, 61, 2)

	# set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Count of configured instances (models)")
	fig.set_ylabel("Number of LTL \nproperties checked")
	# fig.set_title("Number of LTL properties checked for each instance \n(extended verification)")
	fig.plot(x,y, 'ro', markersize = 2) # plot the main data
	# fig.plot([0, x[-1]], [y[-1], y[-1]], 'k--') # plot a line for the last data value
	# fig.legend(loc='lower right')

	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# enable the grid
	fig.grid(which='minor', alpha=0.2)
	fig.grid(which='major', alpha=0.5)

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 25, np.amax(y_majorticks)+0.2])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	fig.set_aspect(10)

	# save the figure
	f.savefig("phase5_properties.jpg", bbox_inches='tight')

	# # generate the y-axis minor ticks
	# y_minorticks = np.arange(0, math.ceil(y[-1])+1, 0.2)


if __name__ == "__main__":
	main()