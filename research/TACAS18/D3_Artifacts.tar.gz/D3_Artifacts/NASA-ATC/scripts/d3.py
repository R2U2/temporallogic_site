# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

# This script runs the D^3 algorithm on the NASA-AAC models.
#
# Author: Rohit Dureja <dureja@iastate.edu>

from genpc import get_configurations
from generator import generate_instances
from scenario import make_instance, parse_cmdline_args
from property_dependence import find_dependencies
from extract_properties import get_properties
from dispatch import PropertyDispatch
import csv
import json
import time
import argparse
import sys
import os
import subprocess
import shutil

VALIDATE_AIRSPACE = "resources/cmds/validate_airspace.cmd"
VALIDATE_NOMINAL = "resources/cmds/validate_nominal_model.cmd"
VALIDATE_EXTENDED = "resources/cmds/validate_extended_model.cmd"
VERIFY_NOMINAL = "resources/cmds/verify_nominal_model.cmd"
VERIFY_EXTENDED = "resources/cmds/verify_extended_model.cmd"

AIRSPACE_PROPERTIES = "../models/oss/airspace_properties.xml"
NOMINAL_PROPERTIES = "../models/oss/nominal_properties.xml"
EXTENDED_PROPERTIES = "../models/oss/extended_properties.xml"

class ModelChecker:
  def mode_init(self, mode, check):
    self.mode = mode
    self.filename = "../results/all_param_result_" + mode + ".json"
    self.data_file = open(self.filename, "rb")
    self.reader = csv.reader(self.data_file)
    self.check = check

    if self.mode == "airspace_validation":
      cmd_file = VALIDATE_AIRSPACE
      self.smv_file = "airspace.smv"

    elif self.mode == "nominal_validation":
      cmd_file = VALIDATE_NOMINAL
      self.smv_file = "nominal.smv"

    elif self.mode == "extended_validation":
      cmd_file = VALIDATE_EXTENDED
      self.smv_file = "extended.smv"

    elif self.mode == "nominal_verification":
      cmd_file = VERIFY_NOMINAL
      self.smv_file = "nominal.smv"

    elif self.mode == "extended_verification":
      cmd_file = VERIFY_EXTENDED
      self.smv_file = "extended.smv"

    self.cmd_table = {}
    # populate command table
    with open(cmd_file, 'r') as fp:
      for line in fp:
        if '-P' in line:
          cmd = line.split(' ')[0].strip()
          prop = line.split(' ')[-1].strip()
          self.cmd_table[prop] = cmd


    with open(self.filename, 'r') as fp:
      self.parsed_results = json.load(fp)

  def model_check(self, instance, property):
    if not self.check: # read from storage
      return self.parsed_results[str(instance)][property]["result"], self.parsed_results[str(instance)][property]["time"]
    elif self.check: # perform check using nuXmv
      command = self.cmd_table[property]

      model = "../scripts/instances/C_ALL_" + str(instance) + "/" + self.smv_file
      template = open("../scripts/resources/cmds/check_property.cmd")
      contents = template.read()
      template.close()

      if command == "check_ltlspec_klive":
        go = "go_bmc"
      elif command == "check_invar_ic3":
        go = "go_bmc"
      elif command == "check_ltlspec":
        go = "go"
      elif command == "check_invar":
        go = "go"

      fields = {"model": model,
                "prop": property,
                "command": command,
                "go": go}

      new = contents.format(**fields)

      # create a tmp directory if one doesn't exists
      if os.path.exists("checktemp" + str(instance) + "/") == False:
        os.mkdir("checktemp" + str(instance) + "/")

      # create the temporary cmd to send to nuXmv
      cmdfile = open("checktemp" + str(instance) + "/check.cmd", "w")
      cmdfile.write(new)
      cmdfile.close()

      # get the results from nuXmv
      start = time.time()
      [text_result, error] = run_nuXmv("../tools/nuXmv/bin/nuXmv -source checktemp" + str(instance) + "/check.cmd")
      end = time.time()
      elapsed = end - start
      if os.path.exists("checktemp" + str(instance) + "/") == True:
        shutil.rmtree("checktemp" + str(instance) + "/")
      if error == None:
        if "true" in text_result:
          print str(instance) + ": property = %s, result = %s, time = %f" %(property, 'True', elapsed)
          return 'True', elapsed
        elif 'unknown' in text_result:
          print str(instance) + ": property = %s, result = %s, time = %f" %(property, 'True', elapsed)
          return None, elapsed
        else:
          print str(instance) + ": property = %s, result = %s, time = %f" %(property, 'True', elapsed)
          return 'False', elapsed


# run nuXmv with the supplied cmd file
def run_nuXmv(binary, options = None):
  command = [binary]
  try:
    out = subprocess.check_output(binary, shell=True)
    return [out, None]
  except subprocess.CalledProcessError as err:
    return [None, err.returncode]

def d3(options):

  # get independent parameter list
  config = get_configurations()

  # 1.  generate preprocessor directives for configuration
  #     and get relations between models
  #     for example: relations[1] returns a list [2,3,4].
  #     this means that we can just check instance 1
  #     and the results will be same for 2, 3, and 4.
  # 2.  the numbeing refers to instances.list.csv
  # 3.  configurations in instances is checked by NuSMV
  # 4.  count contains number of instances
  count, instances, relations = generate_instances(config)

  print 'Count of reduced instances: %d' %(count)

  if options.generator:
    ### create all SMV files for instances
    ### uncomment this to generate SMV files
    ### only requires when regenerating C_ALL_x in the
    ### instances folder. If commented, the already
    ### generated files in the folder are used.
    for instance in instances:
      tmp = {}
      tmp["name"] = "C_ALL_%s" %instance[0]
      tmp["make_nominal.cmd"] = instance[1][-1]
      tmp["conf"] = instance[1][:-1]
      make_instance(tmp)
    print 'Created instances in ../scripts/instances/'
    sys.exit(0)
  else:
    if options.phase == 1:
      mode = "airspace_validation"
      xml_file = AIRSPACE_PROPERTIES
      cmd_file = VALIDATE_AIRSPACE
    elif options.phase == 2:
      mode = "nominal_validation"
      xml_file = NOMINAL_PROPERTIES
      cmd_file = VALIDATE_NOMINAL
    elif options.phase == 3:
      mode = "extended_validation"
      xml_file = EXTENDED_PROPERTIES
      cmd_file = VALIDATE_EXTENDED
    elif options.phase == 4:
      mode = "nominal_verification"
      xml_file = NOMINAL_PROPERTIES
      cmd_file = VERIFY_NOMINAL
    elif options.phase == 5:
      mode = "extended_verification"
      xml_file = EXTENDED_PROPERTIES
      cmd_file = VERIFY_EXTENDED
    else:
      print 'Specify checking phase!'
      sys.exit(-1)

  if options.dependence:
    start = time.time()
    results = find_dependencies(mode)
    end = time.time()
    timeline[mode] = end-start

    for res in results.keys():
      print res
      for entry in results[res]:
        print entry
    json.dump(results, open("../results/" + mode + "_dependencies.json", 'w'))
    print 'Dependence results stored in ../results/'
    sys.exit(0)

  mc = ModelChecker()
  mc.mode_init(mode, options.check)
  otime = 0
  for instance in instances:
    i = instance[0]
    properties = get_properties(cmd_file, xml_file)

    dispatcher = PropertyDispatch([p[0] for p in properties])
    # read dependence
    dependencies = json.load(open("../results/" + mode + "_dependencies.json"))
    for relation in dependencies.keys():
      for dependence in dependencies[relation]:
        dispatcher.add_dependence(dependence[0], dependence[1], relation)

    prop = dispatcher.get_property()
    ctr = 0
    ttime = 0
    while prop != None:
      result, time = mc.model_check(i, prop)
      ttime = ttime + time
      ctr = ctr + 1
      if result == 'True':
        result = True
      elif result == 'False':
        result = False
      elif result == 'unknown':
        result = None
      dispatcher.add_verification_result(prop, result)
      prop = dispatcher.get_property()

    print i + ": properties = %d of %d, time = %f" %(ctr, len(properties), ttime)
    otime = otime + ttime

  print 'Models Checked: %d' %(count)
  print 'Total Time: %.2f seconds or %0.2f hours' %(otime, otime/3600)

def parse_cmdline():
  # parse option
  parser = argparse.ArgumentParser(
    description='Run D^3 on the NASA ATC models',
    formatter_class=argparse.RawTextHelpFormatter)

  # add arguments
  parser.add_argument('-p', dest='phase',
    default=None,
    action='store',
    type=int,
    help='Checking phase for all models. Value between 1..5\
    \n1: Airspace Validation\
    \n2: Nominal Validation\
    \n3: Extended Validation\
    \n4: Nominal Verification\
    \n5: Extended Verification')

  parser.add_argument('--only-generate', dest='generator',
    action='store_true', default=False,
    help= 'Only generate the SMV models each reduced parameter\
          \nconfigurations.')

  parser.add_argument('--perform-checking', dest='check',
    action='store_true', default=False,
    help = 'If specified, model checking is performed using nuXmv.\
            \nOtherwise, results are read from file (../results/).')

  parser.add_argument('--only-dependence', dest='dependence',
    action='store_true', default=False,
    help = 'Establish dependencies for all properties in \
            \nthe model, and store results (../results/)')

  options = parser.parse_args()

  if options.dependence:
    if options.phase == None:
      print 'Error: Specify checking phase for property dependence.'
      sys.exit(-1)

  return options

if __name__ == "__main__":
  options = parse_cmdline()
  d3(options)