# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

# script to generate all instances using genPC
import genpc
import itertools
import copy
import csv

# original instances file
ORIGINAL_INSTANCE_LIST = "../scripts/instances.list.csv"


# Available parameter options
AC_MIX_VALUES =  ["AC_MIX_4_GSEP_0_SSEP",
                  "AC_MIX_3_GSEP_1_SSEP",
                  "AC_MIX_2_GSEP_2_SSEP",
                  "AC_MIX_1_GSEP_3_SSEP",
                  "AC_MIX_0_GSEP_4_SSEP"]

SA_VALUES = ["SSEP_SA_ATC_ATC",
             "SSEP_SA_ATC_SELF",
             "SSEP_SA_SELF_ATC",
             "SSEP_SA_SELF_SELF",
             "SSEP_SA_ATC_SATC",
             "SSEP_SA_SATC_ATC",
             "SSEP_SA_SELF_SATC",
             "SSEP_SA_SATC_SELF",
             "SSEP_SA_SATC_SATC"]

GSEP_TO_SSEP_VALUES = ["GSEP_SSEP_INFO_CURRENT",
                       "GSEP_SSEP_INFO_FAR"]

SSEP_TO_ATC_VALUES = ["SSEP_ATC_INFO_FAR"]

BURDEN_VALUES = ["BURDEN_UNDEF",
                 "B_SSEP",
                 "B_GSEP"]

BURDEN_HEADER = "burdening.h"

COM_STEPS_VALUES = ["COM_STEPS 2", "COM_STEPS 1"]

MAPS_VALUES = ["nominal_simple_cdr.map",
               "nominal.map",
               "nominal_nr_cdr.map"]

def generate_instances(results):
	# run genpc
	# results = genpc.get_configurations()

	# find total number of instances
	count = instance_count(results)

	# get the reduced instances list alongwith the dependence relations between instances
	reduced_instances, relations = generate_instance_list(results)
	# print reduced_instances
	# for key in relations.keys():
	# 	print key, len(relations[key])

	return count, reduced_instances, relations

# function that returns total count of instances
def instance_count(parameter_list):
	count = 0
	for plist in parameter_list:
		intcount = 1
		for param in plist[1:]:
			if param == "COM_STEPS":
				intcount = intcount*len(COM_STEPS_VALUES)
			if param == "BURDENING_RULE":
				intcount = intcount*len(BURDEN_VALUES)
			if param == "SSEP_SA_TS_SS":
				intcount = intcount*len(SA_VALUES)
			if param == "GSEP_SSEP_INFO_LEVEL":
				intcount = intcount*len(GSEP_TO_SSEP_VALUES)
			if param == "SSEP_ATC_INFO_LEVEL":
				intcount = intcount*len(SSEP_TO_ATC_VALUES)
			if param == "ACDR":
				intcount = intcount*len(MAPS_VALUES)
		count = count + intcount

	return count

# hash the original list to retrieve the instance number
# return a (key, value) store
def init_original_instances(filename):
	# read the original 1620 instance file
	ifile = open(filename, "rb")
	reader = csv.reader(ifile)

	parsed_instances = {}
	# parse each row of the CSV and hash it for easy lookup
	for row in reader:
		# append strings to resemble how parameter configurations appear
		# in the parameter value lists
		ac_mix = "AC_MIX_"+row[1].strip()
		ssep_sa = "SSEP_SA_"+row[2].strip()
		gsep_ssep = "GSEP_SSEP_INFO_"+row[3].strip()
		ssep_atc = "SSEP_ATC_INFO_"+row[4].strip()
		if row[5].strip() == "UNDEF":
			burden = "BURDEN_"+row[5].strip()
		else:
			burden = "B_"+row[5].strip()
		com_steps = "COM_STEPS "+row[6].strip()
		mmap = row[7].strip()+".map"

		# create the key
		key = "%s_%s_%s_%s_%s_%s_%s" %(ac_mix, ssep_sa, gsep_ssep, ssep_atc, burden, com_steps, mmap)
		parsed_instances[key] = row[0]

	ifile.close()

	# return the (key, value) store
	return parsed_instances

# function that generates instances using the reduced parameter list
def generate_instance_list(parameter_list):
	# stores the reduced instance list
	instance_list = []

	# store the relations between the instances
	# for example: relations[1] returns a list [2,3,4].
	# this means that we can just check instance 1
	# and the results will be same for 2, 3, and 4
	relations = {}

	# hash the original 1620 instances
	parsed_instances = init_original_instances(ORIGINAL_INSTANCE_LIST)

	# iterate over the list of lists returned by genPC
	for plist in parameter_list:
		# list to store instance configuration
		instance_config = []

		# these lists store possible values of the parameters
		# the boolean values represent whether the parameter has been enabled
		ac_mix  = []

		sa_values = []
		sa_values_set = False

		gsep_to_ssep = []
		gsep_to_ssep_set = False

		ssep_to_atc = []
		ssep_to_atc_set = False

		burden_values = []
		burden_values_set = False

		com_steps_values = []
		com_steps_values_set = False

		maps_values = []
		maps_values_set = False

		ac_mix.append(plist[0])

		# iteratively check which parameters need to be enabled
		if "COM_STEPS" in plist:
			com_steps_values_set = True
			com_steps_values = copy.copy(COM_STEPS_VALUES)
		else:
			com_steps_values.append(COM_STEPS_VALUES[0])

		if "BURDENING_RULE" in plist:
			burden_values_set = True
			burden_values = copy.copy(BURDEN_VALUES)
		else:
			burden_values.append(BURDEN_VALUES[0])

		if "SSEP_SA_TS_SS" in plist:
			sa_values_set = True
			sa_values = copy.copy(SA_VALUES)
		else:
			sa_values.append(SA_VALUES[0])

		if "GSEP_SSEP_INFO_LEVEL" in plist:
			gsep_to_ssep_set = True
			gsep_to_ssep = copy.copy(GSEP_TO_SSEP_VALUES)
		else:
			gsep_to_ssep.append(GSEP_TO_SSEP_VALUES[0])

		if "SSEP_ATC_INFO_LEVEL" in plist:
			ssep_to_atc_set = True
			ssep_to_atc = copy.copy(SSEP_TO_ATC_VALUES)
		else:
			ssep_to_atc.append(SSEP_TO_ATC_VALUES[0])

		if "ACDR" in plist:
			maps_values_set = True
			maps_values = copy.copy(MAPS_VALUES)
		else:
			maps_values.append(MAPS_VALUES[0])

		# perform the cross product of the enabled parameters
		for element in itertools.product(ac_mix, sa_values, gsep_to_ssep, ssep_to_atc, burden_values, com_steps_values, maps_values):
			key = ""
			dependent_instances = []
			el = list(element)
			key = "%s_%s_%s_%s_%s_%s_%s" %(el[0], el[1], el[2], el[3], el[4], el[5], el[6])
			if not parsed_instances.has_key(key):
				print "Error encountered!"
				return 0;
			else:
				# add the instance to be checked
				instance_list.append([parsed_instances[key], list(element)])

				# retrieve all other parameter values that are enclosed in element
				if sa_values_set == True:
					sa_value_dep = [el[1]]
				else:
					sa_value_dep = copy.copy(SA_VALUES)

				if gsep_to_ssep_set == True:
					gsep_to_ssep_dep = [el[2]]
				else:
					gsep_to_ssep_dep = copy.copy(GSEP_TO_SSEP_VALUES)

				if ssep_to_atc_set == True:
					ssep_to_atc_dep = [el[3]]
				else:
					ssep_to_atc_dep = copy.copy(SSEP_TO_ATC_VALUES)

				if burden_values_set == True:
					burden_values_dep = [el[4]]
				else:
					burden_values_dep = copy.copy(BURDEN_VALUES)

				if com_steps_values_set == True:
					com_steps_values_dep = [el[5]]
				else:
					com_steps_values_dep = copy.copy(COM_STEPS_VALUES)

				if maps_values_set == True:
					maps_values_dep = [el[6]]
				else:
					maps_values_dep = copy.copy(MAPS_VALUES)

				# take the cross product by fixing the true parameter values
				# while the false parameters can take any values from their domains
				for dependency in itertools.product([el[0]], sa_value_dep, gsep_to_ssep_dep, ssep_to_atc_dep, burden_values_dep, \
					com_steps_values_dep, maps_values_dep):
					inst = list(dependency)

					# generate the key
					dkey = "%s_%s_%s_%s_%s_%s_%s" %(inst[0], inst[1], inst[2], inst[3], inst[4], inst[5], inst[6])

					# check if instance is in the original set of 1620 instances.
					# if yes, retrieve  the instance number
					if parsed_instances.has_key(dkey):
						dependent_instances.append(parsed_instances[dkey])
					else:
						print "not in list"
						return 0

				# add the dependence relation list to the dict
				relations[parsed_instances[key]] = dependent_instances

	# return the reduced instance list and the relations
	return instance_list, relations

if __name__ == "__main__":
	main()