# helper script
# This script runs all the steps of the analysis for the AAC project.
#
# Configuration flags for the scenarios are defined in an external
# file, and are then used to instantiate multiple versions of the scenarios.
#
# After generation, validation and verification are performed,
# providing a way to assert which properties should hold and
# generating a report of the outocme of the analysis.
#
# Similar steps are then provided for the extended model + Fault Tree analysis.
#
# Author: Marco Gario <gario@fbk.eu>

from __future__ import print_function

import os
import shutil
import subprocess
import argparse
import datetime


#
RDIR = "resources/"
CMD_DIR = RDIR + "cmds/"
NUSMV_EXE = "../../tools/ocra/bin/ocra-linux64" # Path for OCRA
IDIR = "instances/"

SCENARIO_TEMPLATE = "../../models/oss/scenario_template.oss"
SCENARIO_INSTANCE_FNAME = "scenario_instance.oss"

# These SMV files contain the Properties to be verified.
# Moreover, they define monitor variables and DEFINEs that are
# useful to express the properties.
#
AIRSPACE_VALIDATION_SMV = "../../../models/smv_files/airspace_validation.smv"
SA_VALIDATION_SMV = "../../../models/smv_files/sa_validation.smv"
FAULT_COUNT_SMV = "../../../models/smv_files/fault_count.smv"
VERIFICATION_SMV = "../../../models/smv_files/verification.smv"

# All .map files should be in the mappings/ directory
# These are the default mappings.
AIRSPACE_MAP = "airspace.map"
NOMINAL_MAP = "nominal.map"
EXTENDED_MAP = "extended.map"

AIRSPACE_SMV = "airspace.smv"
NOMINAL_SMV = "nominal.smv"
EXTENDED_SMV = "extended.smv"

# These files should be in resources/
#  _ORDER: Order in which properties should be visualized in the report
#  _LIST: List of properties to consider
#  _RES: List of pairs (Property, Result) used for validation.
VERIFICATION_REPORT_ORDER = "verification.prop.order"
FAULT_TREE_ANALYSIS_LIST = "fta.list"
AIRSPACE_VALIDATION_RES = "airspace_validation.expected.txt"
SA_VALIDATION_RES = "sa_validation.expected.txt"
EXTENDED_VALIDATION_RES = "extended_validation.expected.txt"

# These files should be in resources/cmds/
MAKE_AIRSPACE_CMD = "make_airspace.cmd"
MAKE_NOMINAL_CMD = "make_nominal.cmd"
MAKE_EXTENDED_CMD = "make_extended.cmd"
MAKE_TEMPLATE_CMD = "make_template.cmd"
VALIDATE_AIRSPACE_CMD = "validate_airspace.cmd"
VALIDATE_NOMINAL_CMD = "validate_nominal_model.cmd"
VERIFY_NOMINAL_CMD = "verify_nominal_model.cmd"
VALIDATE_EXTENDED_CMD = "validate_extended_model.cmd"
VERIFY_EXTENDED_CMD = "verify_extended_model.cmd"
FAULT_TREE_ANALYSIS_CMD_TEMPLATE = "fta_template.cmd"

#####################################################################

def main(options):
    # Read instances description
    with open(options.instances) as fin:
        instances = eval(fin.read())

    # If given, run only the instance matching the name
    if options.instance_name is not None:
        name = options.instance_name
        candidates = [i for i in instances
                        if i["name"]== name]
        assert len(candidates) > 0, "Instance %s not found" % name
        assert len(candidates) < 2, "Multiple instance named %d found" % name
    else:
        candidates = instances

    # Run process for each instance
    for i in candidates:
        make_instance(i, options)

def make_instance(instance):
    # Make working dir
    target_dir = instance["name"]
    if not os.path.exists(target_dir):
        os.mkdir(target_dir)
    else:
        os.remove(os.path.join(target_dir, "log.txt"))

    def log(msg):
        print(msg)
        with open(os.path.join(target_dir, "log.txt"), "a") as log_file:
            t = datetime.datetime.now()
            log_file.write(str(t) + ": %s\n" % msg)

    log(instance)
    log("Started.")
    # Create scenario_instance.oss with CPP flags
    create_scenario_oss_instance(target_dir, instance)

    # Create SMV files
    create_airspace_model(target_dir, instance)
    create_nominal_model(target_dir, instance)
    create_extended_model(target_dir, instance)

    # if options.build_processed:
    #     log("Creating processed files.")
    #     process_files(target_dir, instance)

    # Exit if we only wanted to build the files
    # if options.build_only:
    subprocess.call(['mv', target_dir, IDIR])
        # return True

    # log("SMV Files created.")
    # if options.validate_airspace:
    #     log("START: Validate Airspace.")
    #     validate_airspace_model(target_dir, instance)
    #     log("END: Validate Airspace.")

    # if options.validate_nominal:
    #     log("START: Validate Nominal.")
    #     validate_nominal_model(target_dir, instance)
    #     log("END: Validate Nominal.")

    # if options.verify_nominal:
    #     log("START: Verify Nominal.")
    #     verify_nominal_model(target_dir, instance)
    #     log("END: Verify Nominal.")

    # if options.validate_extended:
    #     log("START: Validate Extended.")
    #     validate_extended_model(target_dir, instance)
    #     log("END: Validate Extended.")

    # if options.verify_extended:
    #     log("START: Verify Extended.")
    #     verify_extended_model(target_dir, instance)
    #     log("END: Verify Extended.")

    # if options.fault_trees:
    #     log("START: Compute Fault Tree.")
    #     fault_tree_analysis(target_dir, instance)
    #     log("END: Compute Fault Tree.")

    # # Make output more readable
    # if options.combine_report:
    #     combine_report(target_dir)

    # if options.clean_fta:
    #     clean_all_fta(target_dir)

def nusmv_script(target_dir, script_fname):
    """Run nusmv with the given script in the target_dir"""

    old_cwd = os.getcwd()
    os.chdir(target_dir)
    subprocess.call([NUSMV_EXE, "-source", script_fname])
    os.chdir(old_cwd)


def make_map_file(target_dir, instance, map_key, default, target_smv):
    """Utility function to create a map file from a template.

    If the configuration of the instance specifies a map file for
    map_key, then the map file is instantiated with the correct value,
    starting from MAKE_TEMPLATE_CMD. If the configuration is not
    specified, the default value is used instead.
    """

    if map_key in instance:
        mapfile =  instance[map_key]
    else:
        mapfile = default

    with open(CMD_DIR + MAKE_TEMPLATE_CMD, "r") as cmd_template:
        with open(os.path.join(target_dir, map_key), "w") as fout:
            fout.write(cmd_template.read().format(mapfile=mapfile,
                                                  smvfile=target_smv))


def create_scenario_oss_instance(target_dir, instance):
    """
    Create an .oss file in target_dir with the configuration flags
    for the given instance.
    """

    instance_path = os.path.join(target_dir, SCENARIO_INSTANCE_FNAME)

    with open(instance_path, "w") as fout:
        for c in instance["conf"]:
            fout.write("#define %s\n" % c)
        fout.write("\n\n")
        fout.write('#include "%s"\n' % SCENARIO_TEMPLATE)


def inject_properties(target_dir, smv_fname, prop_files):
    """
    Inject the #include for each property file in prop_files,
    within the given smv file. This #included is put inside the
    'system' MODULE. This module must exist.
    """

    smv_path = os.path.join(target_dir, smv_fname)
    # Read file
    with open(smv_path, "r") as fin:
        contents = fin.readlines()

    module_system_line_idx = -1
    for (idx, line) in enumerate(contents):
        if "MODULE system" in line:
            module_system_line_idx = idx
            break

    assert module_system_line_idx != -1, "'MODULE system' not found"

    for i, prop_file in enumerate(prop_files, start=1):
        contents.insert(module_system_line_idx + i,
                        '#include "%s"\n' % prop_file)

    with open(smv_path, "w") as fout:
        fout.write("".join(contents))


def assert_outcome(target_dir, outcome_fname, expected_fname):
    """Brutaly exit if the validation was not successfull."""

    outcome_path = os.path.join(target_dir, outcome_fname)
    with open(expected_fname, "r") as fexpected:
        expected = [l.split() for l in fexpected.readlines() if l]

    outcome = read_outcome.parse_outcome(outcome_path)
    for (name, val) in expected:
        if not read_outcome.check_expected_by_name(outcome, name, val):
            open("ERROR", "w").write("Unexpected value for %s\n" % name)
            print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            print("Unexpected value for %s" % name)
            print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!")
            exit(-3)
    return


def dict_from_report(fname):
    with open(fname, "r") as report:
        tmp = [l.split() for l in report.readlines()]

    res = dict((name, outcome)
               for name, outcome in tmp)
    prop_order = [name for name, _ in tmp]

    return res, prop_order

def combine_report(target_dir):
    nominal_res, prop_order = dict_from_report(os.path.join(target_dir,
                                                            "nominal_report.txt"))
    extended_res, _ = dict_from_report(os.path.join(target_dir,
                                                    "extended_report.txt"))

    new_res_list =["PropName, Nominal, Extended"]
    for name in prop_order:
        new_line = ",".join([name, nominal_res[name], extended_res[name]])
        new_res_list.append(new_line)

    with open(os.path.join(target_dir, "combined_report.csv"), "w") as report:
        for r in new_res_list:
            report.write(r + "\n")

def build_report(target_dir, outcome_fname, report_fname, prop_order_fname):
    """
    Provides a summary file of the properties.
    """

    outcome_path = os.path.join(target_dir, outcome_fname)
    report_path = os.path.join(target_dir, report_fname)
    outcome = read_outcome.parse_outcome(outcome_path)
    with open(prop_order_fname, "r") as fprop_order:
        prop_order = (line.strip() for line in fprop_order.readlines())

    with open(report_path, "w") as freport:
        print("#--------------------------------------------------------#")
        for prop in prop_order:
            res = read_outcome.get_result_by_name(outcome, prop)
            print("%s \t\t %s" % (prop, res))
            freport.write("%s \t\t %s\n" % (prop, res))
            print("#--------------------------------------------------------#")


def create_airspace_model(target_dir, instance):
    """
    Creates the airspace model for the given instance
    and injects the validation properties.
    """
    make_map_file(target_dir, instance, MAKE_AIRSPACE_CMD,
                  AIRSPACE_MAP, AIRSPACE_SMV)
    # Create airspace.smv by calling NuSMV/OCRA
    nusmv_script(target_dir, MAKE_AIRSPACE_CMD)
    # Inject #include of properties
    inject_properties(target_dir,
                      AIRSPACE_SMV,
                      [AIRSPACE_VALIDATION_SMV])


def create_nominal_model(target_dir, instance):
    """
    Creates the nominal model for the given instance
    and injects the validation and verification properties.
    """
    make_map_file(target_dir, instance, MAKE_NOMINAL_CMD,
                  NOMINAL_MAP, NOMINAL_SMV)
    # Create nominal.smv by calling NuSMV/OCRA
    nusmv_script(target_dir, MAKE_NOMINAL_CMD)
    # Inject #include of properties
    inject_properties(target_dir,
                      NOMINAL_SMV,
                      [VERIFICATION_SMV, SA_VALIDATION_SMV])

def validate_airspace_model(target_dir, instance):
    shutil.copy(CMD_DIR + VALIDATE_AIRSPACE_CMD, target_dir)
    nusmv_script(target_dir, VALIDATE_AIRSPACE_CMD)
    assert_outcome(target_dir, "airspace_validation.out",
                   RDIR + AIRSPACE_VALIDATION_RES)


def validate_nominal_model(target_dir, instance):
    shutil.copy(CMD_DIR + VALIDATE_NOMINAL_CMD, target_dir)
    nusmv_script(target_dir, VALIDATE_NOMINAL_CMD)
    assert_outcome(target_dir, "validation.out",
                   RDIR + SA_VALIDATION_RES)


def verify_nominal_model(target_dir, instance):
    shutil.copy(CMD_DIR + VERIFY_NOMINAL_CMD, target_dir)
    nusmv_script(target_dir, VERIFY_NOMINAL_CMD)
    build_report(target_dir,
                 "nominal_verification.out",
                 "nominal_report.txt",
                 RDIR + VERIFICATION_REPORT_ORDER)

def create_extended_model(target_dir, instance):
    """
    Creates the extended model for the given instance
    and injects the verification properties.
    """
    make_map_file(target_dir, instance, MAKE_EXTENDED_CMD,
                  EXTENDED_MAP, EXTENDED_SMV)

    # Create extended.smv by calling NuSMV/OCRA
    nusmv_script(target_dir, MAKE_EXTENDED_CMD)

    # Inject #include of properties
    inject_properties(target_dir,
                      EXTENDED_SMV,
                      [VERIFICATION_SMV,
                       FAULT_COUNT_SMV,
                       # We do not really need the validation
                       # properties but in that file some symbols are
                       # defined that are then used in verification. A
                       # proper solution would be to put those
                       # definitions in a third file.
                       SA_VALIDATION_SMV])

def verify_extended_model(target_dir, instance):
    shutil.copy(CMD_DIR + VERIFY_EXTENDED_CMD, target_dir)
    nusmv_script(target_dir, VERIFY_EXTENDED_CMD)
    build_report(target_dir,
                 "extended_verification.out",
                 "extended_report.txt",
                 RDIR + VERIFICATION_REPORT_ORDER)


def fault_tree_analysis(target_dir, instance):
    """
    Fault Tree Analysis is performed by instantiating multiple cmd
    commands. This makes it easier to interrupt it or just recompute
    partial results.
    """

    with open(RDIR + FAULT_TREE_ANALYSIS_LIST, "r") as fta_list_file:
        fta_list = fta_list_file.readlines()

    fta_list = [l.split() for l in fta_list]
    with open(CMD_DIR + FAULT_TREE_ANALYSIS_CMD_TEMPLATE, "r") as cmd_template:
        template = cmd_template.read()

    for outfile, propname in fta_list:
        with open(os.path.join(target_dir, "fta_%s.cmd" % outfile), "w") as fout:
            fout.write(template.format(outfile=outfile, propname=propname))

    for outfile, _ in fta_list:
        nusmv_script(target_dir, "fta_%s.cmd" % outfile)
        clean_fta(target_dir, outfile)

def clean_all_fta(target_dir):
    with open(RDIR + FAULT_TREE_ANALYSIS_LIST, "r") as fta_list_file:
        fta_list = [l.split() for l in fta_list_file.readlines()]

    for outfile, _ in fta_list:
        clean_fta(target_dir, outfile)

def clean_fta(target_dir, outfile):
    """
    Clean-up the output of the fault tree analysis and create the files:

      * outfile.cutsets
      * outfile.stats

    containing the cutsets and stats from the log.
    """
    cutsets_snippet = []
    stats_snippet = []
    phase = 0
    for line in open(os.path.join(target_dir, outfile), "r"):
        # This file can get pretty big, we should not load it all in
        # memory.
        if phase == 2:
            stats_snippet.append(line)
        elif phase == 1:
            if "STATISTICS" in line:
                phase = 2
                stats_snippet.append(line)
            else:
                cutsets_snippet.append(line)
        elif phase == 0:
            if "MINIMAL CUT SETS" in line:
                phase = 1
                cutsets_snippet.append(line)
            else:
                pass

    with open(os.path.join(target_dir, "%s.cutsets" % outfile), "w") as fout:
        for l in cutsets_snippet:
            fout.write(l)

    with open(os.path.join(target_dir, "%s.stats" % outfile), "w") as fout:
        for l in stats_snippet:
            fout.write(l)


def validate_extended_model(target_dir, instance):
    shutil.copy(CMD_DIR + VALIDATE_EXTENDED_CMD, target_dir)
    nusmv_script(target_dir, VALIDATE_EXTENDED_CMD)
    assert_outcome(target_dir, "validation_extended.out",
                   RDIR + EXTENDED_VALIDATION_RES)

def process_files(target_dir, instance):
    src_files = ["scenario_instance.oss", "airspace.smv",
                 "nominal.smv", "extended.smv"]

    for f in src_files:
        if os.path.exists(os.path.join(target_dir,f)):
             old_cwd = os.getcwd()
             os.chdir(target_dir)
             subprocess.call(["cpp", "-o", "%s.processed"% f, f])
             os.chdir(old_cwd)

def parse_cmdline_args():
    # Parse Options
    parser = argparse.ArgumentParser(
        description='Given a configuration for a scenario,'
                    'builds the scenario and perform several analysis.')
    parser.add_argument('--skip-build', dest="skip_build",
                        action='store_true', default=False,
                        help='Does not generate the OSS and SMV files.')
    parser.add_argument('--build-only', dest="build_only",
                        action='store_true', default=True,
                        help='Stop after generating the OSS and SMV files.')
    parser.add_argument('--build-processed', dest="build_processed",
                        action='store_true', default=False,
                        help='Additionally create a version of the SMV and OSS'
                        'files without pre-processor directives.')
    parser.add_argument('--skip-a-validation', dest='validate_airspace',
                        action='store_false', default=False)
    parser.add_argument('--skip-n', dest='skip_nominal',
                        action='store_true', default=False,
                        help='Skip nominal phase (validation+verification)')
    parser.add_argument('--skip-n-validation', dest='validate_nominal',
                        action='store_false', default=False,
                        help='Skip nominal model validation.')
    parser.add_argument('--skip-n-verification', dest='verify_nominal',
                        action='store_false', default=False,
                        help='Skip nominal model verification.')
    parser.add_argument('--skip-ext', dest='skip_extended',
                        action='store_true', default=False,
                        help='Skip extended phase (validation+verification)')
    parser.add_argument('--skip-ext-validation', dest='validate_extended',
                        action='store_false', default=False,
                        help='Skip extended model validation.')
    parser.add_argument('--skip-ext-verification', dest='verify_extended',
                        action='store_false', default=False,
                        help='Skip extended model verification.')
    parser.add_argument('--skip-fta', dest='fault_trees',
                        action='store_false', default=False,
                        help='Skip Fault Tree Analysis.')
    parser.add_argument('--combine-report', dest="combine_report",
                        action='store_true', default=False,
                        help='Combines the nominal and extended reports.')
    parser.add_argument('--clean-fta', dest="clean_fta",
                        action='store_true', default=False,
                        help='Make the outcome of FTA more readable.')
    # parser.add_argument('instances',
                        # help='python file containing instance definition')
    parser.add_argument('--name', dest='instance_name', default=None,
                        help='Run the analysis only on the instance with the' +
                             'given name (default: run all instances')

    options = parser.parse_args()

    if options.skip_nominal:
        options.verify_nominal = False
        options.validate_nominal = False

    if options.skip_extended:
        options.verify_extended = False
        options.validate_extended = False

    # Enable combine_report if both nominal and extended verification
    # are enabled.
    if options.verify_nominal and options.verify_extended:
        options.combine_report = True
    if options.fault_trees:
        options.clean_fta = True

    return options

if __name__ == "__main__":
    options = parse_cmdline_args()
    main(options)
