set on_failure_script_quits 1
set pp_list "cpp"
set ocra_discrete_time 1
set dynamic_reorder

# Print monolithic implementation
ocra_check_syntax -i scenario_instance.oss
ocra_print_system_implementation -m ../../models/mappings/{mapfile} -o {smvfile}

quit
