set on_failure_script_quits 1
set pp_list "cpp"
set ocra_discrete_time 1
set dynamic_reorder
set counter_examples 0

read_model -i airspace.smv
go


check_invar -P system_inst.AC-Com-INVAR
check_ctlspec -P system_inst.V-1-CTL
check_ctlspec -P system_inst.V-1-Predicted-Near-CTL
check_ctlspec -P system_inst.V-1-Predicted-Mid-CTL
check_ctlspec -P system_inst.V-1-Predicted-Far-CTL
check_ctlspec -P system_inst.V-2-CTL
check_ctlspec -P system_inst.V-2-CTL-G
check_ctlspec -P system_inst.V-2-Predicted-Near-CTL
check_ctlspec -P system_inst.V-2-Predicted-Mid-CTL
check_ctlspec -P system_inst.V-2-Predicted-Far-CTL
check_ctlspec -P system_inst.V-3-CTL
check_ctlspec -P system_inst.V-3-CTL-PRE
check_ctlspec -P system_inst.V-4-CTL
check_ctlspec -P system_inst.V-5-CTL-Near
check_ctlspec -P system_inst.V-5-CTL-Mid
check_ctlspec -P system_inst.V-5-CTL-Far
check_ctlspec -P system_inst.V-6-CTL-Near
check_ctlspec -P system_inst.V-6-CTL-Mid
check_ctlspec -P system_inst.V-6-CTL-Far

# This could be verified by contracts but is added here to make the
# flow more uniform
go_bmc

check_ltlspec_klive -P system_inst.ac_1.AC_initial_norm_guarantee
check_ltlspec_klive -P system_inst.ac_2.AC_initial_norm_guarantee
check_ltlspec_klive -P system_inst.ac_3.AC_initial_norm_guarantee
check_ltlspec_klive -P system_inst.ac_4.AC_initial_norm_guarantee

check_ltlspec_klive -P system_inst.ac_1.AC_no_nop_norm_guarantee
check_ltlspec_klive -P system_inst.ac_2.AC_no_nop_norm_guarantee
check_ltlspec_klive -P system_inst.ac_3.AC_no_nop_norm_guarantee
check_ltlspec_klive -P system_inst.ac_4.AC_no_nop_norm_guarantee

check_ltlspec_klive -P system_inst.ac_1.AC_maneuver_norm_guarantee
check_ltlspec_klive -P system_inst.ac_2.AC_maneuver_norm_guarantee
check_ltlspec_klive -P system_inst.ac_3.AC_maneuver_norm_guarantee
check_ltlspec_klive -P system_inst.ac_4.AC_maneuver_norm_guarantee

check_ltlspec_klive -P system_inst.ac_1.AC_maintain_current_norm_guarantee
check_ltlspec_klive -P system_inst.ac_2.AC_maintain_current_norm_guarantee
check_ltlspec_klive -P system_inst.ac_3.AC_maintain_current_norm_guarantee
check_ltlspec_klive -P system_inst.ac_4.AC_maintain_current_norm_guarantee

check_invar_ic3 -P system_inst.adsb_net.Net_ac_1_norm_guarantee
check_invar_ic3 -P system_inst.adsb_net.Net_ac_2_norm_guarantee
check_invar_ic3 -P system_inst.adsb_net.Net_ac_3_norm_guarantee
check_invar_ic3 -P system_inst.adsb_net.Net_ac_4_norm_guarantee

check_invar_ic3 -P system_inst.com.CommunicationLayer_connection_ac_1_norm_guarantee
check_invar_ic3 -P system_inst.com.CommunicationLayer_connection_ac_2_norm_guarantee
check_invar_ic3 -P system_inst.com.CommunicationLayer_connection_ac_3_norm_guarantee
check_invar_ic3 -P system_inst.com.CommunicationLayer_connection_ac_4_norm_guarantee

show_property -o airspace_validation.out
quit
