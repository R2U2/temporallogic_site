# script to check property with model

set on_failure_script_quits 1
set pp_list "cpp"
set ocra_discrete_time 1
set dynamic_reorder
set counter_examples 0

# read the model
read_model -i {model}

# construct the fsm
{go}

# check the property for the model
{command} -P {prop}

quit