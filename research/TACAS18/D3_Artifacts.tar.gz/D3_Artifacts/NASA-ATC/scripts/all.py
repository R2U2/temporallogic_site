# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.


# Script to generate SMV models for all possible parameter configurations.
from scenario import make_instance, parse_cmdline_args

AC_MIX_VALUES =  ["AC_MIX_4_GSEP_0_SSEP",
                  "AC_MIX_3_GSEP_1_SSEP",
                  "AC_MIX_2_GSEP_2_SSEP",
                  "AC_MIX_1_GSEP_3_SSEP",
                  "AC_MIX_0_GSEP_4_SSEP"]

SA_VALUES = ["SSEP_SA_ATC_ATC",
             "SSEP_SA_ATC_SELF",
             "SSEP_SA_SELF_ATC",
             "SSEP_SA_SELF_SELF",
             "SSEP_SA_ATC_SATC",
             "SSEP_SA_SATC_ATC",
             "SSEP_SA_SELF_SATC",
             "SSEP_SA_SATC_SELF",
             "SSEP_SA_SATC_SATC"]

GSEP_TO_SSEP_VALUES = ["GSEP_SSEP_INFO_CURRENT",
                       "GSEP_SSEP_INFO_FAR"]

SSEP_TO_ATC_VALUES = ["SSEP_ATC_INFO_FAR"]

BURDEN_VALUES = ["BURDEN_UNDEF",
                 "BURDEN_SSEP",
                 "BURDEN_GSEP"]

COM_STEPS_VALUES = ["COM_STEPS 2", "COM_STEPS 1"]

MAPS_VALUES = ["nominal_simple_cdr.map",
               "nominal.map",
               "nominal_nr_cdr.map"]

def generate_conf():
    for ac_mix in AC_MIX_VALUES:
        for sa in SA_VALUES:
            for g2s in GSEP_TO_SSEP_VALUES:
                for s2a in SSEP_TO_ATC_VALUES:
                    for b_rule in BURDEN_VALUES:
                        for com in COM_STEPS_VALUES:
                            yield [ac_mix, sa, g2s, s2a, b_rule, com]

def generate_instance():
    i = 0
    for conf in generate_conf():
        for map_file in MAPS_VALUES:
            i += 1
            yield {"name": "C_ALL_%d" % i,
                   "conf": conf,
                   "make_nominal.cmd" : map_file,
                   }

def generate_args(options):
    for instance in generate_instance():
        yield (instance, options)


def wrap_make_instance(args):
    instance, options = args
    make_instance(instance, options)

def instance_to_line(instance):
    l = [instance['name']]
    l += instance['conf']
    l += [instance['make_nominal.cmd']]
    return ", ".join(l)


if __name__ == "__main__":

    # options = parse_cmdline_args()
    for instance in generate_instance():
        make_instance(instance)
