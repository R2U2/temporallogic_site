# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.

import xml.etree.ElementTree

def get_properties(CMD_FILE, XML_FILE):
	# get the LTL property names from file
	datafile = open(CMD_FILE, 'r')
	prop = []
	for line in datafile:
		if 'ltl' in line:
			prop.append(line.strip().split(" ")[2])
		elif 'invar' in line:
			prop.append(line.strip().split(" ")[2])
	datafile.close()

	# get root of the XML tree
	properties = xml.etree.ElementTree.parse(XML_FILE).getroot()
	read_properties = []
	# iterate over the XML tree to extract property and name
	for pprop in properties.findall('property'):
		name = pprop.find('name').text
		if name in prop:
			ptype = pprop.find('type').text
			pformula = pprop.find('formula').text.split("IN")[0].strip()
			# print pformula
			# Convert the Invar properties to LTL by adding "G"
			if ptype == "Invar":
				pformula = "G("+pformula+")"
				ptype = "LTL"
			read_properties.append([name,pformula])
		else:
			properties.remove(pprop)

	return read_properties