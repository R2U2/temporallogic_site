# Copyright (c) 2017 Rohit Dureja

# Permission is hereby granted, free of charge, to any person obtaining a
# copy of this software and associated documentation files (the "Software"),
# to deal in the Software without restriction, including without limitation
# the rights to use, copy, modify, merge, publish, distribute, sublicense,
# and/or sell copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.


# helper script to extract results for all model-properties pairs
# from tne JSON file in ../plots/

import json
from extract_properties import get_properties

VALIDATE_AIRSPACE = "resources/cmds/validate_airspace.cmd"
VALIDATE_NOMINAL = "resources/cmds/validate_nominal_model.cmd"
VALIDATE_EXTENDED = "resources/cmds/validate_extended_model.cmd"
VERIFY_NOMINAL = "resources/cmds/verify_nominal_model.cmd"
VERIFY_EXTENDED = "resources/cmds/verify_extended_model.cmd"

AIRSPACE_PROPERTIES = "../models/oss/airspace_properties.xml"
NOMINAL_PROPERTIES = "../models/oss/nominal_properties.xml"
EXTENDED_PROPERTIES = "../models/oss/extended_properties.xml"

OUTPUT_FILE = "../results/all_param_result"

RESULTS = "../plots/results_individual.json"

def generate_json(data, mode, properties):
  output_file = OUTPUT_FILE + "_" + mode + ".json"

  output_dict = dict()
  time = 0
  with open(output_file, 'w') as fp:
    for i in range(1, 1621):
      property_results = data[str(i)][mode]["properties"]
      property_dict = dict()
      for result in property_results:
        if result["type"] != "ctl":
          data_dict = dict()
          try:
            time = time + result["time"]
            data_dict["time"] = result["time"]
          except KeyError:
            data_dict["time"] = 0

          try:
            data_dict["result"] = result["result"]
          except:
            data_dict["result"] = "unknown"

          property_dict[result["name"]] = data_dict
      output_dict[str(i)] = property_dict
    json.dump(output_dict, fp)
  print time

def main():
  data_file = open(RESULTS, "r")
  data = json.load(data_file)
  data_file.close()

  modes = ['airspace_validation', 'nominal_verification',\
        'nominal_validation', 'extended_validation',\
        'extended_verification']

  mode = 'airspace_validation'
  properties = get_properties(VALIDATE_AIRSPACE, AIRSPACE_PROPERTIES)
  generate_json(data, mode, properties)

  mode = 'nominal_validation'
  properties = get_properties(VALIDATE_NOMINAL, NOMINAL_PROPERTIES)
  generate_json(data, mode, properties)

  mode = 'extended_validation'
  properties = get_properties(VALIDATE_EXTENDED, EXTENDED_PROPERTIES)
  generate_json(data, mode, properties)

  mode = 'nominal_verification'
  properties = get_properties(VERIFY_NOMINAL, NOMINAL_PROPERTIES)
  generate_json(data, mode, properties)

  mode = 'extended_verification'
  properties = get_properties(VERIFY_EXTENDED, EXTENDED_PROPERTIES)
  generate_json(data, mode, properties)









if __name__ == "__main__":
    main()