#define A (G p)

#define B (G q)

#define C  (G (p & q))

LTLSPEC (!A -> !B)

LTLSPEC (!A -> !C)

LTLSPEC (!B -> !A)

LTLSPEC (!B -> !C)

LTLSPEC (!C -> !A)

LTLSPEC (!C -> !B)


