# 1 "test.h"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 328 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "test.h" 2






LTLSPEC (!(G p) -> !(G q))

LTLSPEC (!(G p) -> !(G (p & q)))

LTLSPEC (!(G q) -> !(G p))

LTLSPEC (!(G q) -> !(G (p & q)))

LTLSPEC (!(G (p & q)) -> !(G p))

LTLSPEC (!(G (p & q)) -> !(G q))


(!a -> !b)
system_inst.Apply-Near-SELF-LTL-AC1 system_inst.Apply-Mid-SELF-LTL-AC1 unsat
system_inst.Apply-Near-SELF-LTL-AC2 system_inst.Apply-Mid-SELF-LTL-AC2 unsat
system_inst.Apply-Near-SELF-LTL-AC3 system_inst.Apply-Mid-SELF-LTL-AC3 unsat
system_inst.Apply-Near-SELF-LTL-AC4 system_inst.Apply-Mid-SELF-LTL-AC4 unsat
system_inst.Apply-Mid-SELF-LTL-AC1 system_inst.Apply-Near-SELF-LTL-AC1 unsat
system_inst.Apply-Mid-SELF-LTL-AC2 system_inst.Apply-Near-SELF-LTL-AC2 unsat
system_inst.Apply-Mid-SELF-LTL-AC3 system_inst.Apply-Near-SELF-LTL-AC3 unsat
system_inst.Apply-Mid-SELF-LTL-AC4 system_inst.Apply-Near-SELF-LTL-AC4 unsat
system_inst.Detect-Near-INVAR system_inst.NO-LOS-Near-INVAR unsat
system_inst.Detect-Mid-INVAR system_inst.NO-LOS-Mid-INVAR unsat
system_inst.Detect-Far-INVAR system_inst.NO-LOS-Far-INVAR unsat
system_inst.New-Conflict-Near-INVAR system_inst.NO-LOS-INVAR unsat
system_inst.New-Conflict-Near-INVAR system_inst.NO-LOS-Near-INVAR unsat
system_inst.New-Conflict-Mid-INVAR system_inst.NO-LOS-Near-INVAR unsat
system_inst.New-Conflict-Mid-INVAR system_inst.NO-LOS-Mid-INVAR unsat
system_inst.New-Conflict-Far-INVAR system_inst.NO-LOS-Mid-INVAR unsat
system_inst.New-Conflict-Far-INVAR system_inst.NO-LOS-Far-INVAR unsat
system_inst.Fast-Resolve-Near-INVAR system_inst.NO-LOS-Near-INVAR unsat
system_inst.Fast-Resolve-Mid-INVAR system_inst.NO-LOS-Mid-INVAR unsat
system_inst.Fast-Resolve-Far-INVAR system_inst.NO-LOS-Far-INVAR unsat
system_inst.Stay-GSEP-Near-INVAR system_inst.NO-LOS-Near-INVAR unsat
system_inst.Stay-GSEP-Mid-INVAR system_inst.NO-LOS-Mid-INVAR unsat
system_inst.Stay-GSEP-Far-INVAR system_inst.NO-LOS-Far-INVAR unsat
system_inst.Stay-SSEP-Near-INVAR system_inst.NO-LOS-Near-INVAR unsat
system_inst.Stay-SSEP-Mid-INVAR system_inst.NO-LOS-Mid-INVAR unsat
system_inst.Stay-SSEP-Far-INVAR system_inst.NO-LOS-Far-INVAR unsat

(a -> b)
system_inst.Apply-Near-SELF-LTL-AC1 system_inst.Apply-Mid-SELF-LTL-AC1 unsat
system_inst.Apply-Near-SELF-LTL-AC2 system_inst.Apply-Mid-SELF-LTL-AC2 unsat
system_inst.Apply-Near-SELF-LTL-AC3 system_inst.Apply-Mid-SELF-LTL-AC3 unsat
system_inst.Apply-Near-SELF-LTL-AC4 system_inst.Apply-Mid-SELF-LTL-AC4 unsat
system_inst.Apply-Mid-SELF-LTL-AC1 system_inst.Apply-Near-SELF-LTL-AC1 unsat
system_inst.Apply-Mid-SELF-LTL-AC2 system_inst.Apply-Near-SELF-LTL-AC2 unsat
system_inst.Apply-Mid-SELF-LTL-AC3 system_inst.Apply-Near-SELF-LTL-AC3 unsat
system_inst.Apply-Mid-SELF-LTL-AC4 system_inst.Apply-Near-SELF-LTL-AC4 unsat
system_inst.NO-LOS-INVAR system_inst.New-Conflict-Near-INVAR unsat
system_inst.NO-LOS-Near-INVAR system_inst.Detect-Near-INVAR unsat
system_inst.NO-LOS-Near-INVAR system_inst.New-Conflict-Near-INVAR unsat
system_inst.NO-LOS-Near-INVAR system_inst.New-Conflict-Mid-INVAR unsat
system_inst.NO-LOS-Near-INVAR system_inst.Fast-Resolve-Near-INVAR unsat
system_inst.NO-LOS-Near-INVAR system_inst.Stay-GSEP-Near-INVAR unsat
system_inst.NO-LOS-Near-INVAR system_inst.Stay-SSEP-Near-INVAR unsat
system_inst.NO-LOS-Mid-INVAR system_inst.Detect-Mid-INVAR unsat
system_inst.NO-LOS-Mid-INVAR system_inst.New-Conflict-Mid-INVAR unsat
system_inst.NO-LOS-Mid-INVAR system_inst.New-Conflict-Far-INVAR unsat
system_inst.NO-LOS-Mid-INVAR system_inst.Fast-Resolve-Mid-INVAR unsat
system_inst.NO-LOS-Mid-INVAR system_inst.Stay-GSEP-Mid-INVAR unsat
system_inst.NO-LOS-Mid-INVAR system_inst.Stay-SSEP-Mid-INVAR unsat
system_inst.NO-LOS-Far-INVAR system_inst.Detect-Far-INVAR unsat
system_inst.NO-LOS-Far-INVAR system_inst.New-Conflict-Far-INVAR unsat
system_inst.NO-LOS-Far-INVAR system_inst.Fast-Resolve-Far-INVAR unsat
system_inst.NO-LOS-Far-INVAR system_inst.Stay-GSEP-Far-INVAR unsat
system_inst.NO-LOS-Far-INVAR system_inst.Stay-SSEP-Far-INVAR unsat

(!a -> b)
system_inst.Apply-Near-ATC-LTL-AC1 system_inst.Apply-Near-SELF-LTL-AC1 unsat
system_inst.Apply-Near-ATC-LTL-AC1 system_inst.Apply-Mid-SELF-LTL-AC1 unsat
system_inst.Apply-Near-ATC-LTL-AC2 system_inst.Apply-Near-SELF-LTL-AC2 unsat
system_inst.Apply-Near-ATC-LTL-AC2 system_inst.Apply-Mid-SELF-LTL-AC2 unsat
system_inst.Apply-Near-ATC-LTL-AC3 system_inst.Apply-Near-SELF-LTL-AC3 unsat
system_inst.Apply-Near-ATC-LTL-AC3 system_inst.Apply-Mid-SELF-LTL-AC3 unsat
system_inst.Apply-Near-ATC-LTL-AC4 system_inst.Apply-Near-SELF-LTL-AC4 unsat
system_inst.Apply-Near-ATC-LTL-AC4 system_inst.Apply-Mid-SELF-LTL-AC4 unsat
system_inst.Apply-Mid-ATC-LTL-AC1 system_inst.Apply-Near-SELF-LTL-AC1 unsat
system_inst.Apply-Mid-ATC-LTL-AC1 system_inst.Apply-Mid-SELF-LTL-AC1 unsat
system_inst.Apply-Mid-ATC-LTL-AC2 system_inst.Apply-Near-SELF-LTL-AC2 unsat
system_inst.Apply-Mid-ATC-LTL-AC2 system_inst.Apply-Mid-SELF-LTL-AC2 unsat
system_inst.Apply-Mid-ATC-LTL-AC3 system_inst.Apply-Near-SELF-LTL-AC3 unsat
system_inst.Apply-Mid-ATC-LTL-AC3 system_inst.Apply-Mid-SELF-LTL-AC3 unsat
system_inst.Apply-Mid-ATC-LTL-AC4 system_inst.Apply-Near-SELF-LTL-AC4 unsat
system_inst.Apply-Mid-ATC-LTL-AC4 system_inst.Apply-Mid-SELF-LTL-AC4 unsat
system_inst.Apply-Far-ATC-LTL-AC1 system_inst.Apply-Far-SELF-LTL-AC1 unsat
system_inst.Apply-Far-ATC-LTL-AC2 system_inst.Apply-Far-SELF-LTL-AC2 unsat
system_inst.Apply-Far-ATC-LTL-AC3 system_inst.Apply-Far-SELF-LTL-AC3 unsat
system_inst.Apply-Far-ATC-LTL-AC4 system_inst.Apply-Far-SELF-LTL-AC4 unsat
system_inst.Apply-Near-SELF-LTL-AC1 system_inst.Apply-Near-ATC-LTL-AC1 unsat
system_inst.Apply-Near-SELF-LTL-AC1 system_inst.Apply-Mid-ATC-LTL-AC1 unsat
system_inst.Apply-Near-SELF-LTL-AC2 system_inst.Apply-Near-ATC-LTL-AC2 unsat
system_inst.Apply-Near-SELF-LTL-AC2 system_inst.Apply-Mid-ATC-LTL-AC2 unsat
system_inst.Apply-Near-SELF-LTL-AC3 system_inst.Apply-Near-ATC-LTL-AC3 unsat
system_inst.Apply-Near-SELF-LTL-AC3 system_inst.Apply-Mid-ATC-LTL-AC3 unsat
system_inst.Apply-Near-SELF-LTL-AC4 system_inst.Apply-Near-ATC-LTL-AC4 unsat
system_inst.Apply-Near-SELF-LTL-AC4 system_inst.Apply-Mid-ATC-LTL-AC4 unsat
system_inst.Apply-Mid-SELF-LTL-AC1 system_inst.Apply-Near-ATC-LTL-AC1 unsat
system_inst.Apply-Mid-SELF-LTL-AC1 system_inst.Apply-Mid-ATC-LTL-AC1 unsat
system_inst.Apply-Mid-SELF-LTL-AC2 system_inst.Apply-Near-ATC-LTL-AC2 unsat
system_inst.Apply-Mid-SELF-LTL-AC2 system_inst.Apply-Mid-ATC-LTL-AC2 unsat
system_inst.Apply-Mid-SELF-LTL-AC3 system_inst.Apply-Near-ATC-LTL-AC3 unsat
system_inst.Apply-Mid-SELF-LTL-AC3 system_inst.Apply-Mid-ATC-LTL-AC3 unsat
system_inst.Apply-Mid-SELF-LTL-AC4 system_inst.Apply-Near-ATC-LTL-AC4 unsat
system_inst.Apply-Mid-SELF-LTL-AC4 system_inst.Apply-Mid-ATC-LTL-AC4 unsat
system_inst.Apply-Far-SELF-LTL-AC1 system_inst.Apply-Far-ATC-LTL-AC1 unsat
system_inst.Apply-Far-SELF-LTL-AC2 system_inst.Apply-Far-ATC-LTL-AC2 unsat
system_inst.Apply-Far-SELF-LTL-AC3 system_inst.Apply-Far-ATC-LTL-AC3 unsat
system_inst.Apply-Far-SELF-LTL-AC4 system_inst.Apply-Far-ATC-LTL-AC4 unsat
