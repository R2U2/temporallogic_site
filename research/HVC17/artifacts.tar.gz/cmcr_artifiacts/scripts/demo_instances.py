[
# 1. GSEP-Only
    {"name": "C_ATC_SELF_4x0_None_None",
     "conf":[ "AC_MIX_4_GSEP_0_SSEP",
              "SSEP_SA_ATC_SELF",
              "GSEP_SSEP_INFO_NONE",
              "SSEP_ATC_INFO_NONE",
              "COM_STEPS 1",
              "BURDEN_UNDEF" ]},

# 2. SSEP-Only with Simple ACDR
    {"name": "C_SELF_SELF_0x4_Simple_ACDR",
     "conf":[ "AC_MIX_0_GSEP_4_SSEP",
              "SSEP_SA_SELF_SELF",
              "GSEP_SSEP_INFO_NONE",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 1",
              "BURDEN_UNDEF"],
     "make_nominal.cmd": "nominal_simple_cdr.map",
    },

# 3. SSEP-Only with Asymmetric ACDR
    {"name": "C_SELF_SELF_0x4_None_Far",
     "conf":[ "AC_MIX_0_GSEP_4_SSEP",
              "SSEP_SA_SELF_SELF",
              "GSEP_SSEP_INFO_NONE",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 1",
              "BURDEN_UNDEF"]},

# 4. SSEP-Only with Asymmetric ACDR and longer window
    {"name": "C_SELF_SELF_0x4_None_Far_COM2",
     "conf":[ "AC_MIX_0_GSEP_4_SSEP",
              "SSEP_SA_SELF_SELF",
              "GSEP_SSEP_INFO_NONE",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 2",
              "BURDEN_UNDEF"]},

# 5. Backup from ground
    {"name": "C_SATC_SATC_0x4_None_Far_COM2",
     "conf":[ "AC_MIX_0_GSEP_4_SSEP",
              "SSEP_SA_SATC_SATC",
              "GSEP_SSEP_INFO_NONE",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 2",
              "BURDEN_UNDEF"]},

# 6. Priority
    {"name": "C_SATC_SATC_0x4_None_Far_COM2_b_gsep",
     "conf":[ "AC_MIX_0_GSEP_4_SSEP",
              "SSEP_SA_SATC_SATC",
              "GSEP_SSEP_INFO_NONE",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 2",
              "BURDEN_GSEP"]},

# 7. Mixed Control
    {"name": "C_ATC_SELF_2x2_Cur_Far_COM2_b_undef",
     "conf":[ "AC_MIX_2_GSEP_2_SSEP",
              "SSEP_SA_ATC_SELF",
              "GSEP_SSEP_INFO_CURRENT",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 2",
              "BURDEN_UNDEF"]},

# 8a. GSEP-Burdening
     {"name": "C_ATC_SELF_2x2_Cur_Far_COM2_b_gsep",
     "conf":[ "AC_MIX_2_GSEP_2_SSEP",
              "SSEP_SA_ATC_SELF",
              "GSEP_SSEP_INFO_CURRENT",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 2",
              "BURDEN_GSEP"]},

# 8b. SSEP-Burdening
    {"name": "C_ATC_SELF_2x2_Cur_Far_COM2_b_ssep",
     "conf":[ "AC_MIX_2_GSEP_2_SSEP",
              "SSEP_SA_ATC_SELF",
              "GSEP_SSEP_INFO_CURRENT",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 2",
              "BURDEN_SSEP"]},

# 9. Additional Information
    {"name": "C_ATC_SELF_2x2_Far_Far_COM2_b_gsep",
     "conf":[ "AC_MIX_2_GSEP_2_SSEP",
              "SSEP_SA_ATC_SELF",
              "GSEP_SSEP_INFO_FAR",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 2",
              "BURDEN_GSEP"]},

# 10. Additional Information (with SSEP-burdening)
    {"name": "C_ATC_SELF_2x2_Far_Far_COM2_b_ssep",
     "conf":[ "AC_MIX_2_GSEP_2_SSEP",
              "SSEP_SA_ATC_SELF",
              "GSEP_SSEP_INFO_FAR",
              "SSEP_ATC_INFO_FAR",
              "COM_STEPS 2",
              "BURDEN_SSEP"]},



]
