# Class file for Dispatch properties
# Author: Rohit Dureja
import sys

class PropertyDispatch:
	# constructor function
	# properties: a list of property names to be checked
	def __init__(self, properties):
		self.properties = properties
		
		# store the property verification results
		self.property_result = []
		for prop in self.properties:
			self.property_result.append(None)

		# stores the dependence graph
		self.dependence_graph = {}

		# stores the properties for verification order
		self.property_queue = []

		# initially, without and dependence, all properties are in queue
		for prop in properties:
			self.property_queue.append(prop)

	def get_property(self):
		if len(self.property_queue) > 0:
			return self.property_queue[0]
		else:
			# print "No properties in queue"
			if None in self.property_result:
				print "Properties still remaining"
				sys.exit() 
			return None

	# returns the dependence relation for the properties
	def __mode(self, dependence):
		if dependence == "(!a->!b)":
			return False, False, False
		if dependence == "(a->b)":
			return True, True, False
		if dependence == "(!a->b)":
			return False, True, False
		print "Incorrent dependence specified. Has to be one of the following choices:"
		print "1. (!a->!b)"
		print "2. (a->b)"
		print "3. (!a->b)"
		return 0, 0, True

	# adds a property to the dependence graph
	def __add_property(self, propertyname):
		self.dependence_graph[propertyname] = {True : {}, False: {}}

	def get_results(self):
		return self.property_result

	def get_graph(self):
		return self.dependence_graph

	# add a dependence relation to the graph
	def add_dependence(self, property1, property2, dependence):
		a, b, Error = self.__mode(dependence)
		if Error:
			return 0
		else:
			if property1 not in self.dependence_graph:
				self.__add_property(property1)
			self.dependence_graph[property1][a][property2] = b

			# add the property to the queue
			if property1 not in self.property_queue:
				self.property_queue.append(property1)

	# remove a dependence for the graph
	def __remove_property(self, propertyname):
		return self.dependence_graph.pop(propertyname, None)

	def add_verification_result(self, propertyname, result):
		if result == None:
			idx = self.properties.index(propertyname)
			self.property_result[idx] = 'NA'

			# remove the property from the queue
			self.property_queue.pop(0)

		else:

			# print propertyname, ": ", result
			# add the verification result
			idx = self.properties.index(propertyname)
			self.property_result[idx] = result

			# remove the property from the queue
			self.property_queue.pop(0)
			# print self.property_result

			# remove the property from the dependence graph if it exists
			if propertyname in self.dependence_graph:
				pproperties = self.__remove_property(propertyname)
				dep_properties = pproperties[result] # returns a dictionary
				# add the dependent properties to the local queue
				local_queue = dep_properties

				# the properties discovered NOT dependent are added to property queue
				for prop in pproperties[not result]:
					# add the property to the queue
					if prop not in self.property_queue:
						idx = self.properties.index(prop)
						if self.property_result[idx] == None:
							self.property_queue.append(prop)
							# print "Added to queue: ", prop
				
				# Perform BFS on the graph
				while local_queue != {}:
					props = local_queue.keys()
					for prop in props:
						# remove the property if it was in property verification queue
						if prop in self.property_queue:
							# print prop
							self.property_queue.remove(prop)
							# print "LOCAL", local_queue
							# print propertyname, " made ", prop, local_queue[prop]
							# print "Removed from queue: ", prop

						# add the verification result
						idx = self.properties.index(prop)
						if self.property_result[idx] == None:
							self.property_result[idx] = local_queue[prop]
						elif self.property_result[idx] == 'NA':
							print "Nice!"
							self.property_result[idx] = local_queue[prop]
						else: # result was already determined. check if there is a mismatch
							if self.property_result[idx] != local_queue[prop]:
								print "Mismatch!"
								sys.exit()
							else:
								None
								# print "The result correlates"

						# remove the property from the dependence graph if it exists
						if prop in self.dependence_graph:
							dep_properties = self.__remove_property(prop)[local_queue[prop]] # returns a dictionary
							# print "DEP", dep_properties
							local_queue[prop] = dep_properties

						# remove prop from the local queue
						# print "LLOO", local_queue
						local_queue.pop(prop, None)
						# print "LLOO", local_queue

				# print self.dependence_graph
				# print self.property_result
				# print self.property_queue



