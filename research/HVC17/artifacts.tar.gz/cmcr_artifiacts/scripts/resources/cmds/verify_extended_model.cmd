set on_failure_script_quits 1
set pp_list "cpp"
set ocra_discrete_time 1
set dynamic_reorder
set counter_examples 0
set bmc_length 15

read_model -i extended.smv
go_bmc

check_invar_ic3 -P system_inst.NO-LOS-INVAR
check_invar_ic3 -P system_inst.NO-LOS-Near-INVAR
check_invar_ic3 -P system_inst.NO-LOS-Mid-INVAR
check_invar_ic3 -P system_inst.NO-LOS-Far-INVAR
check_invar_ic3 -P system_inst.Detect-Near-INVAR
check_invar_ic3 -P system_inst.Detect-Mid-INVAR
check_invar_ic3 -P system_inst.Detect-Far-INVAR
check_invar_ic3 -P system_inst.New-Conflict-Near-INVAR
check_invar_ic3 -P system_inst.New-Conflict-Mid-INVAR
check_invar_ic3 -P system_inst.New-Conflict-Far-INVAR
check_invar_ic3 -P system_inst.Fast-Resolve-Near-INVAR
check_invar_ic3 -P system_inst.Fast-Resolve-Mid-INVAR
check_invar_ic3 -P system_inst.Fast-Resolve-Far-INVAR
check_invar_ic3 -P system_inst.Ground-Aware-Near-INVAR
check_invar_ic3 -P system_inst.Ground-Aware-Mid-INVAR
check_invar_ic3 -P system_inst.Ground-Aware-Far-INVAR
check_invar_ic3 -P system_inst.Ground-Aware-TS-SA-INVAR
check_invar_ic3 -P system_inst.Ground-Aware-SS-SA-INVAR
check_invar_ic3 -P system_inst.Resolve-Near-ATC-INVAR
check_invar_ic3 -P system_inst.Resolve-Mid-ATC-INVAR
check_invar_ic3 -P system_inst.Resolve-Far-ATC-INVAR
check_invar_ic3 -P system_inst.Resolve-Near-SELF-INVAR
check_invar_ic3 -P system_inst.Resolve-Mid-SELF-INVAR
check_invar_ic3 -P system_inst.Resolve-Far-SELF-INVAR
check_invar_ic3 -P system_inst.Stay-GSEP-Near-INVAR
check_invar_ic3 -P system_inst.Stay-GSEP-Mid-INVAR
check_invar_ic3 -P system_inst.Stay-GSEP-Far-INVAR
check_invar_ic3 -P system_inst.Stay-SSEP-Near-INVAR
check_invar_ic3 -P system_inst.Stay-SSEP-Mid-INVAR
check_invar_ic3 -P system_inst.Stay-SSEP-Far-INVAR
time

check_ltlspec_klive -P system_inst.Apply-Near-ATC-LTL-AC1
check_ltlspec_klive -P system_inst.Apply-Near-ATC-LTL-AC2
check_ltlspec_klive -P system_inst.Apply-Near-ATC-LTL-AC3
check_ltlspec_klive -P system_inst.Apply-Near-ATC-LTL-AC4
check_ltlspec_klive -P system_inst.Apply-Mid-ATC-LTL-AC1
check_ltlspec_klive -P system_inst.Apply-Mid-ATC-LTL-AC2
check_ltlspec_klive -P system_inst.Apply-Mid-ATC-LTL-AC3
check_ltlspec_klive -P system_inst.Apply-Mid-ATC-LTL-AC4
check_ltlspec_klive -P system_inst.Apply-Far-ATC-LTL-AC1
check_ltlspec_klive -P system_inst.Apply-Far-ATC-LTL-AC2
check_ltlspec_klive -P system_inst.Apply-Far-ATC-LTL-AC3
check_ltlspec_klive -P system_inst.Apply-Far-ATC-LTL-AC4
check_ltlspec_klive -P system_inst.Apply-Near-SELF-LTL-AC1
check_ltlspec_klive -P system_inst.Apply-Near-SELF-LTL-AC2
check_ltlspec_klive -P system_inst.Apply-Near-SELF-LTL-AC3
check_ltlspec_klive -P system_inst.Apply-Near-SELF-LTL-AC4
check_ltlspec_klive -P system_inst.Apply-Mid-SELF-LTL-AC1
check_ltlspec_klive -P system_inst.Apply-Mid-SELF-LTL-AC2
check_ltlspec_klive -P system_inst.Apply-Mid-SELF-LTL-AC3
check_ltlspec_klive -P system_inst.Apply-Mid-SELF-LTL-AC4
check_ltlspec_klive -P system_inst.Apply-Far-SELF-LTL-AC1
check_ltlspec_klive -P system_inst.Apply-Far-SELF-LTL-AC2
check_ltlspec_klive -P system_inst.Apply-Far-SELF-LTL-AC3
check_ltlspec_klive -P system_inst.Apply-Far-SELF-LTL-AC4

show_property -o extended_verification.out
time
quit
