# script to perfom LTL satisfiability of two properties

set on_failure_script_quits 1
set pp_list cpp
set counter_examples 0
set cone_of_influence 1
set disable_syntactic_checks 1

# read the universal model
read_model -i {universal_model}

# construct the fsm
go_bmc

# check the LTL satsifability property
check_ltlspec_bmc -p "!{prop1} -> {prop2} IN system_inst"

quit