set on_failure_script_quits 1
set pp_list "cpp"
set ocra_discrete_time 1
set dynamic_reorder
set counter_examples 0
set forward_search 0

read_model -i extended.smv
go

time

# GCDR
check_ctlspec -P system_inst.atc.gcdr.fault_outage__dynamic.Possibility-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_detect_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_detect_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_detect_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_detect_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_detect_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_detect_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_resolve_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_resolve_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_resolve_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_resolve_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_resolve_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.atc.gcdr.fault_resolve_far__dynamic.Transient-CTL

# ADSB-Net
check_ctlspec -P system_inst.adsb_net.fault_adsb_out_ac_1__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.adsb_net.fault_adsb_out_ac_1__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.adsb_net.fault_adsb_out_ac_2__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.adsb_net.fault_adsb_out_ac_2__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.adsb_net.fault_adsb_out_ac_3__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.adsb_net.fault_adsb_out_ac_3__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.adsb_net.fault_adsb_out_ac_4__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.adsb_net.fault_adsb_out_ac_4__dynamic.bounded.Possibility-CTL

# Communication Layer
check_ctlspec -P system_inst.com.fault_com_ac_1_atc__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.com.fault_com_ac_1_atc__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.com.fault_com_ac_2_atc__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.com.fault_com_ac_2_atc__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.com.fault_com_ac_3_atc__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.com.fault_com_ac_3_atc__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.com.fault_com_ac_4_atc__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.com.fault_com_ac_4_atc__dynamic.bounded.Possibility-CTL

# AC1
check_ctlspec -P system_inst.ac_1.pilot.route_manager.fault_apply_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.pilot.route_manager.fault_apply_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.pilot.route_manager.fault_apply_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.pilot.route_manager.fault_apply_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.pilot.route_manager.fault_apply_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.pilot.route_manager.fault_apply_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.pilot.protocol_policy.fault_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.pilot.protocol_policy.fault_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.pilot.protocol_policy.fault_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.pilot.protocol_policy.fault_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.pilot.protocol_policy.fault_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.pilot.protocol_policy.fault_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.adsb_in.fault_adsb_in__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.ac_1.adsb_in.fault_adsb_in__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_outage__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_detect_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_detect_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_detect_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_detect_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_detect_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_detect_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_resolve_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_resolve_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_resolve_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_resolve_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_resolve_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_1.cdr.fault_resolve_far__dynamic.Transient-CTL

# AC2
check_ctlspec -P system_inst.ac_2.pilot.route_manager.fault_apply_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.pilot.route_manager.fault_apply_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.pilot.route_manager.fault_apply_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.pilot.route_manager.fault_apply_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.pilot.route_manager.fault_apply_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.pilot.route_manager.fault_apply_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.pilot.protocol_policy.fault_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.pilot.protocol_policy.fault_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.pilot.protocol_policy.fault_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.pilot.protocol_policy.fault_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.pilot.protocol_policy.fault_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.pilot.protocol_policy.fault_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.adsb_in.fault_adsb_in__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.ac_2.adsb_in.fault_adsb_in__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_outage__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_detect_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_detect_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_detect_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_detect_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_detect_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_detect_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_resolve_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_resolve_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_resolve_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_resolve_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_resolve_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_2.cdr.fault_resolve_far__dynamic.Transient-CTL

# AC3
check_ctlspec -P system_inst.ac_3.pilot.route_manager.fault_apply_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.pilot.route_manager.fault_apply_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.pilot.route_manager.fault_apply_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.pilot.route_manager.fault_apply_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.pilot.route_manager.fault_apply_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.pilot.route_manager.fault_apply_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.pilot.protocol_policy.fault_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.pilot.protocol_policy.fault_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.pilot.protocol_policy.fault_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.pilot.protocol_policy.fault_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.pilot.protocol_policy.fault_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.pilot.protocol_policy.fault_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.adsb_in.fault_adsb_in__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.ac_3.adsb_in.fault_adsb_in__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_outage__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_detect_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_detect_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_detect_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_detect_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_detect_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_detect_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_resolve_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_resolve_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_resolve_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_resolve_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_resolve_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_3.cdr.fault_resolve_far__dynamic.Transient-CTL

# AC4
check_ctlspec -P system_inst.ac_4.pilot.route_manager.fault_apply_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.pilot.route_manager.fault_apply_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.pilot.route_manager.fault_apply_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.pilot.route_manager.fault_apply_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.pilot.route_manager.fault_apply_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.pilot.route_manager.fault_apply_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.pilot.protocol_policy.fault_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.pilot.protocol_policy.fault_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.pilot.protocol_policy.fault_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.pilot.protocol_policy.fault_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.pilot.protocol_policy.fault_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.pilot.protocol_policy.fault_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.adsb_in.fault_adsb_in__dynamic.permanent.Possibility-CTL
check_ctlspec -P system_inst.ac_4.adsb_in.fault_adsb_in__dynamic.bounded.Possibility-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_outage__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_detect_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_detect_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_detect_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_detect_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_detect_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_detect_far__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_resolve_near__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_resolve_near__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_resolve_mid__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_resolve_mid__dynamic.Transient-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_resolve_far__dynamic.Possibility-CTL
check_ctlspec -P system_inst.ac_4.cdr.fault_resolve_far__dynamic.Transient-CTL
time

check_ltlspec -P system_inst.atc.gcdr.fault_outage__dynamic.Permanent-LTL
check_ltlspec -P system_inst.adsb_net.fault_adsb_out_ac_1__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.adsb_net.fault_adsb_out_ac_1__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.adsb_net.fault_adsb_out_ac_2__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.adsb_net.fault_adsb_out_ac_2__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.adsb_net.fault_adsb_out_ac_3__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.adsb_net.fault_adsb_out_ac_3__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.adsb_net.fault_adsb_out_ac_4__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.adsb_net.fault_adsb_out_ac_4__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.com.fault_com_ac_1_atc__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.com.fault_com_ac_1_atc__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.com.fault_com_ac_2_atc__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.com.fault_com_ac_2_atc__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.com.fault_com_ac_3_atc__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.com.fault_com_ac_3_atc__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.com.fault_com_ac_4_atc__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.com.fault_com_ac_4_atc__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.ac_1.adsb_in.fault_adsb_in__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.ac_1.adsb_in.fault_adsb_in__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.ac_1.cdr.fault_outage__dynamic.Permanent-LTL
check_ltlspec -P system_inst.ac_2.adsb_in.fault_adsb_in__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.ac_2.adsb_in.fault_adsb_in__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.ac_2.cdr.fault_outage__dynamic.Permanent-LTL
check_ltlspec -P system_inst.ac_3.adsb_in.fault_adsb_in__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.ac_3.adsb_in.fault_adsb_in__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.ac_3.cdr.fault_outage__dynamic.Permanent-LTL
check_ltlspec -P system_inst.ac_4.adsb_in.fault_adsb_in__dynamic.permanent.Permanent-LTL
check_ltlspec -P system_inst.ac_4.adsb_in.fault_adsb_in__dynamic.bounded.Bounded-LTL
check_ltlspec -P system_inst.ac_4.cdr.fault_outage__dynamic.Permanent-LTL
time

show_property -o validation_extended.out
quit
