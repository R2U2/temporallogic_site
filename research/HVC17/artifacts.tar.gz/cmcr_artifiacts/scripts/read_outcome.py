# Parse a dump from NuSMV property DB
#
# 1- Create a dump using the following command
# NuSMV > show_properties -o out.file
#
# 2- You can run this script as a shell and obtain a print
#    of that file (main() below)
#
# 3- Use this as a lightweight library to assert the expected
#    outcome of a check (check_expected_by_name)
#
# Author: Marco Gario <gario@fbk.eu>
from __future__ import print_function

import sys
from collections import namedtuple

OutcomeLine = namedtuple('OutcomeLine',
                         ['spec_type', 'result', 'trace_id', 'name'])

def parse_outcome(fname):
    """Parse an outcome file and returns a list of OutcomeLine"""
    outcome_list = []
    with open(fname, "r") as fin:
        for line in fin.readlines():
            if line[:3] == "  [":
                args = line.replace("[", "").replace("]", "").split()
                outcome_line = OutcomeLine(*args)
                outcome_list.append(outcome_line)

    # Check that there is only one instance with a given name
    names = [o.name for o in outcome_list if o.name != "N/A"]
    names_set = set(names)
    assert len(names) == len(names_set), \
           "Multiple properties with the same name %d != %d." % (len(names), len(names_set))

    outcome = dict((o.name, o) for o in outcome_list)
    return outcome

def get_result_by_name(outcome, name):
    """Returns the result of the property with the given name."""
    if name not in outcome:
        print("Cannot find property '%s'!" % name)
        exit(-2)

    return outcome[name].result

def check_expected_by_name(outcome, name, expected_result):
    """Checks that the result for the given property matches the expectation"""
    actual_result = get_result_by_name(outcome, name)
    return actual_result == expected_result

def filter_by_name(outcome, names_list):
    for n in names_list:
        if n in outcome:
            yield outcome[n]


def usage():
    print("%s <outcome_file>" % sys.argv[0])
    exit(-1)

def main():
    if len(sys.argv) != 2:
        usage()

    fname = sys.argv[1]
    outcome = parse_outcome(fname)
    for name in outcome:
        print("%s := %s" % (name, outcome[name].result))

if __name__ == "__main__":
    main()
