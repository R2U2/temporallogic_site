Getting Started
---------------

Before running any of the experiments make sure nuXmv is installed, 
and add it to environment PATH.

Files in the Directory
----------------------

heuristic1.py: Implements the GRIC algorithm on the benchmark.

instances.py: Generates the instances to be checked after running the
              GRIC algorithm. This file generates output in a format
              understood by the script present in the original benchmark.

dispatch.py: Class files for the PROPERTY-DISPATCH data structure.

heuristic2.py: Implements the DDOP algorithm on the benchmark. Relies on
                dispatch.py for proper operation. All generated instances
                by instances.py is checked dynamically with nuXmv.

demo_instances.py: Reference file to show the syntax for mentioning instance
                    description. Here for reference.

instances.list.csv: Simple file associating ID of the configuration to
                    the set of parameters.

scenario.py: Generates the SMV files for the reduced set of models. Takes as 
              input parameter configurations specified in demo_instances.py. This
              file is used as is from the original benchmark. Run scenario.py 
              without any parameters for further details.

extract_properties.py: This script extract all properties to be checked from the
                      SMV files. Added here for reference.

resources/ : This folder contains nuXmv scripts to perform several operation.
              Included as is from the original benchmark.

For doubts and questions: dureja@iastate.edu
