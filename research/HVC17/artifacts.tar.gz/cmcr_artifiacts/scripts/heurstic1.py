# This script implements GRIC algorithm on the the family of models.
# Author: Rohit Dureja
import re
from subprocess import call
import os
import glob

OSS_FOLDER = "../oss/"
BASE_FILE = "scenario_template.oss"
AC_MIX_HEADER = "acmix.h"
BURDENING_HEADER = "burdening.h"
GSEP_SSEP_INFO_HEADER = "gsepssepinfo.h"
SSEP_ATC_INFO_HEADER = "ssepatcinfo.h"
SSEP_TS_SS_SA_HEADER = "sseptsssa.h"

# Available paraemter options
AC_MIX_VALUES =  ["AC_MIX_4_GSEP_0_SSEP",
                  "AC_MIX_3_GSEP_1_SSEP",
                  "AC_MIX_2_GSEP_2_SSEP",
                  "AC_MIX_1_GSEP_3_SSEP",
                  "AC_MIX_0_GSEP_4_SSEP"]

SA_VALUES = ["SSEP_SA_ATC_ATC",
             "SSEP_SA_ATC_SELF",
             "SSEP_SA_SELF_ATC",
             "SSEP_SA_SELF_SELF",
             "SSEP_SA_ATC_SATC",
             "SSEP_SA_SATC_ATC",
             "SSEP_SA_SELF_SATC",
             "SSEP_SA_SATC_SELF",
             "SSEP_SA_SATC_SATC"]

GSEP_TO_SSEP_VALUES = ["GSEP_SSEP_INFO_CURRENT",
                       "GSEP_SSEP_INFO_FAR"]

SSEP_TO_ATC_VALUES = ["SSEP_ATC_INFO_FAR"]

BURDEN_VALUES = ["BURDEN_UNDEF",
                 "B_SSEP",
                 "B_GSEP"]
BURDEN_HEADER = "burdening.h"

COM_STEPS_VALUES = ["2", "1"]

MAPS_VALUES = ["nominal_simple_cdr.map",
               "nominal.map",
               "nominal_nr_cdr.map"]

# global count to maintain current instance number
instance_number = 0

def main():
	# run the heuristic for parameter dependence
	configuration_sequence = run_heuristic()

	# print the parameter configuration sequence
	for order in configuration_sequence:
		print order

	# clear temp files
	clear_temp_files(OSS_FOLDER)

# function that implements the actual heuristics
# iteration_number 	= number of times the heuristic has been run
#						(used to maintain intermediate temporary file)						  
def run_heuristic():
	iteration_number = 0
	sequence = []
	#########################################
	for ac_mix in AC_MIX_VALUES:
		order = []
		# generate temp name for intermediate files
		active_temp_file = "temp" + str(iteration_number) + '.oss'

		# run cpp and enable the AC_MIX parameters
		run_cpp(OSS_FOLDER, BASE_FILE, active_temp_file, [ac_mix], [AC_MIX_HEADER])
		iteration_number = iteration_number + 1
		# add paramters to order
		order.append(ac_mix)

		# get back unconfigured options
		options_left = unconfigured_options(OSS_FOLDER, active_temp_file)
		# print active_temp_file, options_left

	#########################################
		# check if burdening rule is in options
		if 'BURDENING_RULE' in options_left:
			# set source file to file that results after processing AC_MIX
			srcfile = active_temp_file
			# add paramters to order
			order.append('BURDENING_RULE')
			for burden in BURDEN_VALUES:
				# print burden

				# generate temp name for intermediate files
				active_temp_file = "temp" + str(iteration_number) + '.oss'

				# run cpp and enable the AC_MIX parameters
				run_cpp(OSS_FOLDER, srcfile, active_temp_file, ['CONF_BURDENING_RULE=' + burden, burden+'='+burden], [BURDENING_HEADER])
				iteration_number = iteration_number + 1

				# get back unconfigured options
				options_left = unconfigured_options(OSS_FOLDER, active_temp_file)
				# print active_temp_file, options_left
	#########################################
				# in the options left, check enabling which option 
				# minimizes the options left.
		while options_left:
			srcfile = active_temp_file
			next_option = get_next_option(srcfile, options_left)
			# print next_option
			#########################################
			if next_option == "GSEP_SSEP_INFO_LEVEL":
			 	# set source file to file that results after processing BURDEN
				srcfile = active_temp_file
				
				# add paramters to order
				order.append('GSEP_SSEP_INFO_LEVEL')
			 	
			 	for value in GSEP_TO_SSEP_VALUES:
			 		# generate temp name for intermediate files
					active_temp_file = "temp" + str(iteration_number) + '.oss'

					# run cpp and enable the AC_MIX parameters
					run_cpp(OSS_FOLDER, srcfile, active_temp_file, [value], [GSEP_SSEP_INFO_HEADER])
					iteration_number = iteration_number + 1

			#########################################
			if next_option == "SSEP_ATC_INFO_LEVEL":
			 	# set source file to file that results after processing BURDEN
				srcfile = active_temp_file
			 	
			 	# add paramters to order
				order.append('SSEP_ATC_INFO_LEVEL')

			 	for value in SSEP_TO_ATC_VALUES:
			 		# generate temp name for intermediate files
					active_temp_file = "temp" + str(iteration_number) + '.oss'

					# run cpp and enable the AC_MIX parameters
					run_cpp(OSS_FOLDER, srcfile, active_temp_file, ['CONF_SSEP_ATC_INFO_LEVEL'], [SSEP_ATC_INFO_HEADER])
					iteration_number = iteration_number + 1

			#########################################
			if next_option == "COM_STEPS":
			 	# set source file to file that results after processing BURDEN
				srcfile = active_temp_file
			 	
			 	# add paramters to order
				order.append('COM_STEPS')

			 	for value in COM_STEPS_VALUES:
			 		# generate temp name for intermediate files
					active_temp_file = "temp" + str(iteration_number) + '.oss'

					# run cpp and enable the AC_MIX parameters
					run_cpp(OSS_FOLDER, srcfile, active_temp_file, ['CONF_COM_STEPS='+value])
					iteration_number = iteration_number + 1

			#########################################
			if next_option == "ACDR":
			 	# set source file to file that results after processing BURDEN
				srcfile = active_temp_file
			 	
			 	# add paramters to order
				order.append('ACDR')

			 	for value in MAPS_VALUES:
			 		# generate temp name for intermediate files
					active_temp_file = "temp" + str(iteration_number) + '.oss'

					# run cpp and enable the AC_MIX parameters
					run_cpp(OSS_FOLDER, srcfile, active_temp_file, ['CONF_ACDR=---'])
					iteration_number = iteration_number + 1

			#########################################
			if next_option == "SSEP_SA_TS_SS":
			 	# set source file to file that results after processing BURDEN
				srcfile = active_temp_file
			 	
			 	# add paramters to order
				order.append('SSEP_SA_TS_SS')

			 	for value in SA_VALUES:
			 		# generate temp name for intermediate files
					active_temp_file = "temp" + str(iteration_number) + '.oss'

					# run cpp and enable the AC_MIX parameters
					run_cpp(OSS_FOLDER, srcfile, active_temp_file, [value], [SSEP_TS_SS_SA_HEADER])
					iteration_number = iteration_number + 1

			options_left = unconfigured_options(OSS_FOLDER, active_temp_file)
			# print active_temp_file, options_left
		sequence.append(order)

	# clear temp files
	clear_temp_files(OSS_FOLDER)
	
	# return the parameter configuration order
	return sequence




# returns the next parameters that should be enabled
def get_next_option(srcfile, options_left):
	tempfile = "temp.oss"
	
	# placeholders for left parameter count
	count = 100
	option = ""

	# GSEP to SSEP information sharing
	if "GSEP_SSEP_INFO_LEVEL" in options_left:
		run_cpp(OSS_FOLDER, srcfile, tempfile, ['CONF_GSEP_SSEP_INFO_LEVEL'])
		if count > len(unconfigured_options(OSS_FOLDER, tempfile)):
			count = len(unconfigured_options(OSS_FOLDER, tempfile))
			option = "GSEP_SSEP_INFO_LEVEL"
		# print "GSEP_SSEP_INFO_LEVEL", len(unconfigured_options(OSS_FOLDER, tempfile))

	# SSEP to ATC information sharing
	if "SSEP_ATC_INFO_LEVEL" in options_left:
		run_cpp(OSS_FOLDER, srcfile, tempfile, ['CONF_SSEP_ATC_INFO_LEVEL'])
		if count > len(unconfigured_options(OSS_FOLDER, tempfile)):
			count = len(unconfigured_options(OSS_FOLDER, tempfile))
			option = "SSEP_ATC_INFO_LEVEL"
		# print "SSEP_ATC_INFO_LEVEL", len(unconfigured_options(OSS_FOLDER, tempfile))

	# number of communication steps
	if "COM_STEPS" in options_left:
		run_cpp(OSS_FOLDER, srcfile, tempfile, ['CONF_COM_STEPS'])
		if count > len(unconfigured_options(OSS_FOLDER, tempfile)):
			count = len(unconfigured_options(OSS_FOLDER, tempfile))
			option = "COM_STEPS"
		# print "COM_STEPS", len(unconfigured_options(OSS_FOLDER, tempfile))

	# ACDR implementation
	if "ACDR" in options_left:
		run_cpp(OSS_FOLDER, srcfile, tempfile, ['CONF_ACDR'])
		if count > len(unconfigured_options(OSS_FOLDER, tempfile)):
			count = len(unconfigured_options(OSS_FOLDER, tempfile))
			option = "ACDR"
		# print "ACDR", len(unconfigured_options(OSS_FOLDER, tempfile))

	# SSEP strategic and tactical separation agents
	if "SSEP_SS_SA" in options_left:
		run_cpp(OSS_FOLDER, srcfile, tempfile, ['CONF_SSEP_SS_SA', 'CONF_SSEP_TS_SA'])
		if count > len(unconfigured_options(OSS_FOLDER, tempfile)):
			count = len(unconfigured_options(OSS_FOLDER, tempfile))
			option = "SSEP_SA_TS_SS"
		# print "SSEP_SS_SA", len(unconfigured_options(OSS_FOLDER, tempfile))

	return option




def clear_temp_files(directory):
	# store current cwd and move to OSS folder
	cwd = os.getcwd()
	os.chdir(directory)

	for fl in glob.glob("temp*.oss"):
		os.remove(fl)

	# return to the working directory
	os.chdir(cwd)


# function to run the cpp on the supplied file
def run_cpp(directory, ifile, ofile, defines = None, includes = None):
	# store current cwd and move to OSS folder
	cwd = os.getcwd()
	os.chdir(directory)

	command = ['cpp', '-P']
	if defines != None:
		for define in defines:
			command.append('-D'+ define)

	if includes != None:
		for include in includes:
			command.append('-include'+ include)

	# add name of source file and output file
	command.append(ifile)
	command.append(ofile)

	# run the c preprocessors
	call(command)

	# return to the working directory
	os.chdir(cwd)

# this function returns the unconfigured parameters options as a list.
def unconfigured_options(directory, filename):
	# store current cwd and move to OSS folder
	cwd = os.getcwd()
	os.chdir(directory)

	parameters = set()
	# open the file fo rreading
	unprocessed_file = open(filename, "r")

	for line in unprocessed_file.readlines():
		# check if CONF_ keyword in line
		if 'CONF_' in line:
			words = line.split()
			for word in words:
				# extract the unconfigured parameters
				if 'CONF_' in word:
					# match using regexes
					word = re.sub(r'CONF_', '', word).strip(';')
					word = re.sub(r'AC_\d_', '', word).strip(';')
					parameters.add(word)
	
	# close the file
	unprocessed_file.close()
	
	# get back to the cwd
	os.chdir(cwd)

	# return the unconfigured parameters set
	return parameters

if __name__ == "__main__":
    main()