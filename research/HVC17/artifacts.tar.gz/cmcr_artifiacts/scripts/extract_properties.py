import xml.etree.ElementTree

VALIDATE_AIRSPACE = "resources/cmds/validate_airspace.cmd"
VALIDATE_NOMINAL = "resources/cmds/validate_nominal_model.cmd"
VALIDATE_EXTENDED = "resources/cmds/validate_extended_model.cmd"
VERIFY_NOMINAL = "resources/cmds/verify_nominal_model.cmd"
VERIFY_EXTENDED = "resources/cmds/verify_extended_model.cmd"

AIRSPACE_PROPERTIES = "../oss/airspace_properties.xml"
NOMINAL_PROPERTIES = "../oss/nominal_properties.xml"
EXTENDED_PROPERTIES = "../oss/extended_properties.xml"

CMD_FILE = VERIFY_EXTENDED
XML_FILE = EXTENDED_PROPERTIES

def main():
	# get the LTL property names from file
	datafile = open(CMD_FILE, 'r')
	prop = []
	for line in datafile:
		if 'ltl' in line:
			prop.append(line.strip().split(" ")[2])
		elif 'invar' in line:
			prop.append(line.strip().split(" ")[2])
	datafile.close()

	# get root of the XML tree
	properties = xml.etree.ElementTree.parse(XML_FILE).getroot()
	read_properties = []
	# iterate over the XML tree to extract property and name
	for pprop in properties.findall('property'):
		name = pprop.find('name').text
		if name in prop:
			ptype = pprop.find('type').text
			pformula = pprop.find('formula').text.split("IN")[0].strip()
			# print pformula
			# Convert the Invar properties to LTL by adding "G"
			if ptype == "Invar":
				pformula = "G("+pformula+")"
				ptype = "LTL"
			read_properties.append([name,pformula])
		else:
			properties.remove(pprop)

	print len(read_properties)
	# # write to file
	# # tree = xml.etree.ElementTree(properties)
	# xml.etree.ElementTree.write('output.xml', pretty_print=True, xml_declaration=True)
	# print read_properties


if __name__ == "__main__":
	main()