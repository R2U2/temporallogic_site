# Script to implement DDOP: LTL Satisfiability 
import re
import os
import shutil
import subprocess
import xml.etree.ElementTree

LTLSAT_CMD_TEMPLATE = "../scripts/resources/cmds/ltlsat_template.cmd"
TEMP_DIR = "tmp/"
TEMPORARY_CMD = "temp.cmd"

VALIDATE_AIRSPACE = "resources/cmds/validate_airspace.cmd"
VALIDATE_NOMINAL = "resources/cmds/validate_nominal_model.cmd"
VALIDATE_EXTENDED = "resources/cmds/validate_extended_model.cmd"
VERIFY_NOMINAL = "resources/cmds/verify_nominal_model.cmd"
VERIFY_EXTENDED = "resources/cmds/verify_extended_model.cmd"

AIRSPACE_PROPERTIES = "../oss/airspace_properties.xml"
NOMINAL_PROPERTIES = "../oss/nominal_properties.xml"
EXTENDED_PROPERTIES = "../oss/extended_properties.xml"

# uncomment accordingly for each  model-checking phase
# For airspace validation
MODEL = "../oss/universal_airspace.smv"
CMD_FILE = VALIDATE_AIRSPACE
XML_FILE = AIRSPACE_PROPERTIES

# For nominal validation
MODEL = "../oss/universal_nominal_val.smv"
CMD_FILE = VALIDATE_NOMINAL
XML_FILE = NOMINAL_PROPERTIES

# For nominal verification
MODEL = "../oss/universal_nominal.smv"
CMD_FILE = VERIFY_NOMINAL
XML_FILE = NOMINAL_PROPERTIES

# For extended validation
MODEL = "../oss/universal_extended_val.smv"
CMD_FILE = VALIDATE_AIRSPACE
XML_FILE = EXTENDED_PROPERTIES

# For extended verification
MODEL = "../oss/universal_nominal.smv"
CMD_FILE = VERIFY_EXTENDED
XML_FILE = EXTENDED_PROPERTIES

def main():
	# get the LTL property names from file
	datafile = open(CMD_FILE, 'r')
	prop = []
	for line in datafile:
		if 'ltl' in line:
			prop.append(line.strip().split(" ")[2])
		elif 'invar' in line:
			prop.append(line.strip().split(" ")[2])
	datafile.close()

		# get root of the XML tree
	properties = xml.etree.ElementTree.parse(XML_FILE).getroot()
	read_properties = []
	# iterate over the XML tree to extract property and name
	for pprop in properties.findall('property'):
		name = pprop.find('name').text
		if name in prop:
			ptype = pprop.find('type').text
			pformula = pprop.find('formula').text.split("IN")[0].strip().replace("system_inst.", "")
			# print pformula
			# Convert the Invar properties to LTL by adding "G"
			if ptype == "Invar":
				pformula = "G("+pformula+")"
				ptype = "LTL"
			read_properties.append([name,pformula])
		else:
			properties.remove(pprop)

	print "Number of LTL properties: " + str(len(read_properties))

	for i in range(len(read_properties)):
		for j in range(len(read_properties)):
			if i != j:
				check_satisfiability(read_properties[i], read_properties[j], MODEL)

	# remove the tmp directory
	shutil.rmtree(TEMP_DIR, ignore_errors=True)

# check the satisfiability of the two properties against the universal model.
def check_satisfiability(property1, property2, model):
	# open the ltlsat template file
	template = open(LTLSAT_CMD_TEMPLATE, "r")

	# read the contents and close the file
	contents = template.read()
	template.close()

	# set the parameters
	fields = {'universal_model': model, 'prop1' : property1[1], 'prop2' : property2[1]}

	# generate the resulting file contents
	new = contents.format(**fields)
 
	# create a tmp directory if one doesn't exists
	if os.path.exists(TEMP_DIR) == False:
		os.mkdir(TEMP_DIR)

	# create the temporary cmd to send to nuXmv
	cmdfile = open(TEMP_DIR+TEMPORARY_CMD, "w")
	cmdfile.write(new)
	cmdfile.close()

	# get the results from nuXmv
	# print TEMP_DIR+TEMPORARY_CMD
	[text_result, error] = run_nuXmv("nuXmv",["-source", TEMP_DIR+TEMPORARY_CMD])
	if error == None:
		# print text_result
		if "false" not in text_result:
			print property1[0], property2[0], "unsat"

# run nuXmv with the supplied cmd file
def run_nuXmv(binary, options = None):
	command = [binary]
	for option in options:
		command.append(option)
	
	try:
		out = subprocess.check_output("nuXmv -source tmp/temp.cmd", shell=True)
		return [out, None]
	except subprocess.CalledProcessError as err:
		return [None, err.returncode]


if __name__ == "__main__":
    main()