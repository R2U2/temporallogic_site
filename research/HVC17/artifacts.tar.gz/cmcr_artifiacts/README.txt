This README deals with the structure of files for the original benchmark.
It is copied as is from the original benchmark repo with minor 
modifications.
-----------

The structure of this directory is as follows:

- oss/
- smv_files/
- mappings/
- scripts/


oss/
----

In oss/ we put the architectural definition (OCRA) of each component.
The file scenario_template.oss is the starting point. It describes the
system architecture and it imports all other files.  Flags used by the
pre-processor are documented in that file.

config.h contains additional pre-processor flags that are expanded
into a more machine-friendly way. This file is also responsible for
raising warnings if some configuration flag is not set.


smv_files/
----------

SMV Files are divided into:
-- nominal
-- extended
-- dummy
-- inner_models

inner_models is where the actual implementation of the component is
done. The files within nominal/ and extended/ simply import the
corresponding file from inner_models, and set some flags.

Models within dummy are obtained by simply calling
ocra_print_implementation_template. These are used whenever we want to
let a component free to perform anything.

Each inner_model is structured as 3 wrapping MODULEs.

1. Environment for OCRA: This is the 'main' and is required by ocra
   SMV implementation format.
2. Extended Model Wrapper: This is the wrapper that multiplexes the
   component with its error model.
3. Nominal Model: Usually called *_Nominal, can be a standard SMV
   implementation or still simply a container for more specialized
   sub-components (e.g., ACDR)


mappings/
---------

This directory contains the mapping of SMV implementations to
architecture components. The most important ones are:

* airspace.map
* nominal.map
* extended.map

Notice that a mapping must refer to a nominal, extended or dummy
model, and cannot use an inner_model directly.


faults.xml and groups.txt
-------------------------

faults.xml contains the definition of the faults used in the model.
We can use a single file since:

- The architecture never changes
- The inner_model define a fault symbol for both the nominal and
  extended model. In the nominal case, this is simply a DEFINE False.

groups.txt contains the splitting of faults in three groups to perform
the sensitivity analysis.


scripts/
--------

This directory contains the tools for running the automated analysis.

The tool scenario.py has multiple options. In a nutshell, it should be
invoked as:

  python scenario.py <instance generator>

(run it without arguments for more info).

This takes a python file defining the list of scenario instances to be
analyze, and runs all the steps of the analysis. The result is place
in a directory with the name of the scenario instance, within the
scripts/ directory.

See demo_instances.py for an idea on how to define each scenario
instance.

In order to run the analysis, scenario.py relies on the files defined
in resources. There we have NuXmv cmd templates (within the cmds/
directory) or more simple text-based files defining expected results
(for model validation) or other data.

See the scripts/README.txt for more information.

plots/
------

This directory contains scripts to generate the plots in the paper, as
well as several other plots.

For more information see plots/README.txt.


For doubts and questions: dureja@iastate.edu
