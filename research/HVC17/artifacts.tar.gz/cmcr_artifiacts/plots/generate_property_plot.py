# script to generate plots for instances using heuristic 1
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
import numpy as np
import json
import math
from random import shuffle
from matplotlib import rc

# nominal
ctr1 = [39, 0, 0, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 39, 39, 39, 44, 44, 39, 39, 39, 44, 39, 39, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 39, 39, 39, 44, 44, 39, 39, 39, 50, 39, 39, 50, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 39, 39, 39, 44, 44, 39, 39, 39, 44, 39, 39, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 39, 39, 39, 44, 44, 39, 39, 39, 50, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 39, 39, 39, 44, 44, 39, 39, 39, 50, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 39, 39, 39, 44, 44, 39, 39, 39, 50, 39, 39, 50, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 44, 44, 39, 44, 44, 39, 44, 39, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 50, 44, 39, 50, 50, 50, 50, 50, 50, 50, 44, 39, 50, 49, 39, 50, 39, 50, 50, 44, 50, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 44, 44, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 44, 39, 50, 49, 39, 50, 50, 50, 50, 50, 50, 50, 44, 39, 50, 49, 39, 50, 44, 50, 50, 44, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 50, 44, 39, 50, 50, 50, 50, 50, 50, 50, 50, 39, 50, 50, 39, 50, 39, 50, 50, 44, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 50, 50, 39, 50, 50, 50, 50, 50, 50, 50, 50, 39, 50, 50, 39, 50, 50, 0, 50, 50, 50, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 35, 39, 39, 35, 39, 39, 39, 39, 39, 39, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 44, 39, 35, 44, 44, 35, 44, 39, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 35, 39, 39, 35, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 50, 44, 39, 50, 50, 50, 50, 50, 50, 50, 39, 35, 50, 44, 35, 50, 39, 50, 50, 44, 50, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 39, 44, 44, 39, 44, 44, 44, 44, 44, 44, 44, 44, 35, 44, 44, 35, 44, 44, 44, 44, 44, 44, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 39, 35, 39, 39, 35, 39, 39, 39, 39, 39, 39, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 44, 39, 50, 49, 39, 50, 50, 50, 50, 50, 50, 50, 44, 35, 50, 49, 35, 50, 44, 50, 50, 49, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 39, 50, 44, 39, 50, 50, 50, 50, 50, 50, 50, 39, 35, 50, 50, 35, 50, 39, 50, 50, 44, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 50, 39, 50, 50, 39, 50, 50, 50, 50, 50, 50, 50, 50, 35, 50, 50, 35, 50, 50, 50, 50, 50, 50, 39, 39, 39, 39, 39, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 39, 35, 44, 44, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39, 39, 39, 39, 39, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 39, 35, 50, 44, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 44, 35, 44, 44, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 39, 39, 39, 39, 39, 39, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 44, 35, 50, 49, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 39, 35, 50, 50, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 35, 50, 50, 35, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
# extended
ctr2 = [42, 0, 0, 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 43, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 0, 0, 0, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 44, 46, 46, 46, 46, 46, 46, 0, 0, 0, 46, 46, 46, 46, 46, 46, 46, 46, 46, 0, 0, 0, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 0, 0, 0, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 46, 0, 0, 0, 46, 46, 46, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 42, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 0, 0, 0, 0, 0, 0, 0, 0, 0, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 45, 0, 0, 0, 45, 45, 45, 45, 45, 45, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 0, 0, 0, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 48, 42, 42, 42, 42, 42, 42, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 46, 46, 46, 46, 46, 46, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 50, 50, 50, 50, 50, 50, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

def main():
  x = [x for x in range(1, 1621)]
  shuffle(ctr2)
  y = [None if a == 0 else a for a in ctr2]

  tr = [z for z in y if z != None]
  mean = np.mean(np.array(tr))
  median = np.median(np.array(tr))
  dev = np.std(np.array(tr))
  print mean, median, dev


  # plot figure for nominal verification
  f = plt.figure() # init the figure module
  plt.rc('font', **{'size' : 12, 'family': 'serif', 'serif': ['Times']})
  plt.rc('text', usetex=True)
  plt.rcParams['xtick.major.size'] = 10
  plt.rcParams['xtick.major.width'] = 1
  plt.rcParams['xtick.minor.size'] = 5
  plt.rcParams['xtick.minor.width'] = 0.5
  plt.rcParams['ytick.major.size'] = 10
  plt.rcParams['ytick.major.width'] = 1
  plt.rcParams['ytick.minor.size'] = 5
  plt.rcParams['ytick.minor.width'] = 0.5
  fig = f.add_subplot(111)
  f.set_size_inches(8, 1.5)

  # generate the x-axis major ticks
  x_majorticks = np.arange(0, 1621, 200)
  x_majorticks[len(x_majorticks)-1] = 1620
  x_majorticks[0] = 1

  # generate the x-axis minor ticks
  x_minorticks = np.arange(0, 1621, 40)
  x_minorticks[0] = 1

   # generate the y-axis major ticks
  y_majorticks = np.arange(25, 61, 10)
  y_majorticks[-1] = 54
  # y_majorticks=  np.append(y_majorticks, y[-1])

  # generate the y-axis minor ticks
  y_minorticks = np.arange(25, 61, 2)

  # set the xlabel, ylabel, title, and plot
  fig.set_xlabel("Number of configured instances (models)")
  fig.set_ylabel("Number of LTL \nproperties checked")
  # fig.set_title("Number of LTL properties checked for each instance \n(nominal verification)")
  fig.plot(x,y, linestyle='None', marker='o', markeredgecolor='black', markerfacecolor='red', markersize = 3) # plot the main data
  # fig.plot([0, 1620], [med, med], 'k--') # plot a line for the last data value
  # fig.legend(loc='lower right')

  # set the major and minor ticks
  fig.set_xticks(x_majorticks)
  fig.set_xticks(x_minorticks, minor=True)
  fig.set_yticks(y_majorticks)
  fig.set_yticks(y_minorticks, minor = True)

  # enable the grid
  fig.grid(which='minor', alpha=0.2)
  fig.grid(which='major', alpha=0.5)

  # set the axis lengths and formatting of the ticks
  fig.axis([1, np.amax(x_majorticks), 25, np.amax(y_majorticks)+0.2])
  # fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

  # set the aspect ratio
  fig.set_aspect('auto')

  # save the figure
  f.savefig("fig50.pdf", bbox_inches='tight')

  shuffle(ctr1)
  y = [None if a == 0 else a for a in ctr1]

  tr = [z for z in y if z != None]
  mean = np.mean(np.array(tr))
  median = np.median(np.array(tr))
  dev = np.std(np.array(tr))
  print mean, median, dev

  # plot figure for nominal verification
  f = plt.figure() # init the figure module
  fig = f.add_subplot(111)
  f.set_size_inches(8, 1.5)

  # generate the x-axis major ticks
  x_majorticks = np.arange(0, 1621, 200)
  x_majorticks[len(x_majorticks)-1] = 1620
  x_majorticks[0] = 1

  # generate the x-axis minor ticks
  x_minorticks = np.arange(0, 1621, 40)
  x_minorticks[0] = 1

   # generate the y-axis major ticks
  y_majorticks = np.arange(25, 61, 10)
  y_majorticks[-1] = 54
  # y_majorticks=  np.append(y_majorticks, y[-1])

  # generate the y-axis minor ticks
  y_minorticks = np.arange(25, 61, 2)

  # set the xlabel, ylabel, title, and plot
  fig.set_xlabel("Number of configured instances (models)")
  fig.set_ylabel("Number of LTL \nproperties checked")
  # fig.set_title("Number of LTL properties checked for each instance \n(extended verification)")
  fig.plot(x,y, linestyle='None', marker='o', markeredgecolor='black', markerfacecolor='red', markersize = 3) # plot the main data
  # fig.plot([0, x[-1]], [y[-1], y[-1]], 'k--') # plot a line for the last data value
  # fig.legend(loc='lower right')

  # set the major and minor ticks
  fig.set_xticks(x_majorticks)
  fig.set_xticks(x_minorticks, minor=True)
  fig.set_yticks(y_majorticks)
  fig.set_yticks(y_minorticks, minor = True)

  # enable the grid
  fig.grid(which='minor', alpha=0.2)
  fig.grid(which='major', alpha=0.5)

  # set the axis lengths and formatting of the ticks
  fig.axis([1, np.amax(x_majorticks), 25, np.amax(y_majorticks)+0.2])
  # fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

  # set the aspect ratio
  fig.set_aspect('auto')

  # save the figure
  f.savefig("fig51.pdf", bbox_inches='tight')

  # # generate the y-axis minor ticks
  # y_minorticks = np.arange(0, math.ceil(y[-1])+1, 0.2)
  #############################################################
  #   QUERY:  Generate a cumulative time vs instances plot
  #       for mode = airspace_validation and don't include
  #       instances that did not complete.
  # NAME: fig9.pdf
  #############################################################
  # mode = modes[0] # set mode to airspace validation

  # x = [] # x-values. will store in the instance number
  # y = [] # y-values. will store the cumulative time
  # incomplete = []

  # print "Total instances: ", len(data)
  # time = 0
  # ctr = 1
  # for config in data.keys():
  #   instance_time = 0
  #   if data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
  #     incomplete.append(config)
  #   else:
  #     instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
  #     instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
  #     for prop in range(len(data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
  #       instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
  #     time = time + (instance_time/3600)
  #     x.append(ctr)
  #     y.append(time)
  #   ctr = ctr + 1

  # # print the incomplete instances
  # print mode, "incomplete instances = ", len(incomplete)

  # # plot the figure
  # f = plt.figure() # init the figure module
  # fig = f.add_subplot(111)

  # # generate the x-axis major ticks
  # x_majorticks = np.arange(0, 1621, 200)
  # x_majorticks[len(x_majorticks)-1] = 1620
  # x_majorticks[0] = 1

  # # generate the x-axis minor ticks
  # x_minorticks = np.arange(0, 1621, 40)
  # x_minorticks[0] = 1

  # # generate the y-axis major ticks
  # y_majorticks = np.arange(0, math.ceil(y[-1]), 1)
  # y_majorticks=  np.append(y_majorticks, y[-1])

  # # generate the y-axis minor ticks
  # y_minorticks = np.arange(0, math.ceil(y[-1])+1, 0.2)

  # # set the xlabel, ylabel, title, and plot
  # fig.set_xlabel("Number of instances")
  # fig.set_ylabel("Model checking time (in hours)")
  # fig.set_title("Cumulative Model Checking Time for Airspace Validation \n (all instances)")
  # fig.plot(x,y, 'b-', label='heuristic 1') # plot the main data
  # fig.plot([0, x[-1]], [y[-1], y[-1]], 'k--') # plot a line for the last data value
  # fig.legend(loc='lower right')

  # # set the major and minor ticks
  # fig.set_xticks(x_majorticks)
  # fig.set_xticks(x_minorticks, minor=True)
  # fig.set_yticks(y_majorticks)
  # fig.set_yticks(y_minorticks, minor = True)

  # # enable the grid
  # fig.grid(which='minor', alpha=0.2)
  # fig.grid(which='major', alpha=0.5)

  # # set the axis lengths and formatting of the ticks
  # fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+0.2])
  # fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

  # # set the aspect ratio
  # fig.set_aspect('auto')

  # # save the figure
  # f.savefig("fig9.pdf")



if __name__ == "__main__":
  main()