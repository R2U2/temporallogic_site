This folder contains scripts to generate all the plots in the original paper.
(Across all filenames: heuristic 1 implements the GRIC algorithm, while
heuristic 2 implements the DDOP algorithm.)

The directory contains the following files:

results.zip
----

This archive contains JSON files for all verification results. Extract the archive
before running any of the other scripts. Place all the files in the archive in the
same directory as the .py files.

original_generate_results.py
----------------------------

The script generates plots for the verification results of the original benchmark
using individual-model checking. Refer to the comments in the script for more 
details.

heuristic1_generate_plots.py
----------------------------

The script plots the verification results using the GRIC algorithm. Refer to the 
comments in the script for more details.

combine_original_heuristic1_generate_plots.py
----------------------------

The script plots the verification results using the GRIC algorithm and individual-
model checking. Refer to the comments in the script for more details.

heuristic2_generate_plots.py
----------------------------

The script plots the verification results using the DDOP algorithm. Refer to the 
comments in the script for more details.

combine_original_heuristic1_heuristic2_generate_plots.py
--------------------------------------------------------

The script plots the verification results using the GRIC algorithm, individual-
model checking, and CMCR. Refer to the comments in the script for more details.


generate_property_plot.py
----------------------------

The script plots the the variation in the LTL properties checked using DDOP. 
Refer to the comments in the script for more details.


General comment: All scripts require numpy installed.

For doubts and questions: dureja@iastate.edu
