# script to generate plots for instances using heuristic 2
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
import numpy as np
import json
import math

def main():
	# open the heuristic_1 file for reading
	data_file = open("collated_results_heuristic2.json", "r")

	# load the contents from the file, which creates a new directory
	data = json.load(data_file)
	data_file.close()

	# queries on data
	modes = ['airspace_validation', 'nominal_verification',\
				'nominal_validation', 'extended_validation',\
				'extended_verification']

	#############################################################
	#   QUERY: 	Generate a cumulative time vs instances plot
	# 			for mode = nominal_verification and don't include
	# 			instances that did not complete.
	#	NAME:	fig25.pdf
	#############################################################
	mode = modes[1] # set mode to nominal_verification
	
	x = [] # x-values. will store in the instance number
	y = [] # y-values. will store the cumulative time
	incomplete = []

	print "Total instances: ", len(data)
	time = 0.9
	ctr = 1
	for config in data.keys():
		instance_time = 0
		if data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x.append(ctr)
			y.append(time)
		ctr = ctr + 1

	# print the incomplete instances
	print mode, "incomplete instances = ", len(incomplete)

	# plot the figure
	f = plt.figure() # init the figure module
	fig = f.add_subplot(111)

	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 200)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

	# generate the y-axis major ticks
	y_majorticks = np.arange(0, math.ceil(y[-1]), 1)
	y_majorticks=  np.append(y_majorticks, y[-1])

	# generate the y-axis minor ticks
	y_minorticks = np.arange(0, math.ceil(y[-1])+1, 0.2)

	# set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Number of instances")
	fig.set_ylabel("Model checking time (in hours)")
	fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
	fig.plot(x,y, 'b-', label='heuristic 2') # plot the main data
	fig.plot([0, x[-1]], [y[-1], y[-1]], 'k--') # plot a line for the last data value
	fig.legend(loc='lower right')

	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# enable the grid
	fig.grid(which='minor', alpha=0.2)                                                
	fig.grid(which='major', alpha=0.5) 

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+0.2])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	fig.set_aspect('auto')

	# save the figure
	f.savefig("fig25.pdf")

	#############################################################
	#   QUERY: 	Generate a cumulative time vs instances plot
	# 			for mode = nominal_verification and include
	# 			instances that did not complete.
	#	NAME:	fig26.pdf
	#############################################################
	mode = modes[1] # set mode to nominal_verification
	
	x = [] # x-values. will store in the instance number
	y = [] # y-values. will store the cumulative time
	incomplete = []
	incomplete_properties = {}

	time = 0.9
	ctr = 1
	for config in data.keys():
		instance_time = 0
		
		if data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
			incomplete_properties[config] = []
			instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'complete'] == True:
					if data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
						instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
				else:
					incomplete_properties[config].append(data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'name'])
		else:
			instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
		time = time + (instance_time/3600)
		x.append(ctr)
		y.append(time)
		ctr = ctr + 1

	# print the incomplete instances
	print mode, "incomplete instances = ", len(incomplete)
	# print "number of incomplete properties = ", len(incomplete_properties[incomplete[0]])
	# print "incomplete properties = ", incomplete_properties

	# plot the figure
	f = plt.figure() # init the figure module
	fig = f.add_subplot(111)

	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 200)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

	# generate the y-axis major ticks
	y_majorticks = np.arange(0, math.ceil(y[-1]), 2)
	y_majorticks[-1] =  y[-1]

	# generate the y-axis minor ticks
	y_minorticks = np.arange(0, math.ceil(y[-1])+1, 0.4)

	# set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Number of instances")
	fig.set_ylabel("Model checking time (in hours)")
	fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (all instances)")
	fig.plot(x,y, 'b-', label='heuristic 1') # plot the main data
	fig.plot([0, x[-1]], [y[-1], y[-1]], 'k--') # plot a line for the last data value
	fig.legend(loc='lower right')

	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# enable the grid
	fig.grid(which='minor', alpha=0.2)                                                
	fig.grid(which='major', alpha=0.5) 

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+0.3])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	fig.set_aspect('auto')

	# save the figure
	f.savefig("fig26.pdf")

	#############################################################
	#   QUERY: 	Generate a cumulative time vs instances plot
	# 			for mode = extended_verification and don't include
	# 			instances that did not complete.
	#	NAME:	fig27.pdf
	#############################################################
	mode = modes[4] # set mode to extended_verification
	
	x = [] # x-values. will store in the instance number
	y = [] # y-values. will store the cumulative time
	incomplete = []

	print "Total instances: ", len(data)
	time = 0.9
	ctr = 1
	for config in data.keys():
		instance_time = 0
		if data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
			incomplete.append(config)
		else:
			instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
			instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
			for prop in range(len(data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
				if data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
					instance_time += data[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
			time = time + (instance_time/3600)
			x.append(ctr)
			y.append(time)
		ctr = ctr + 1

	# print the incomplete instances
	print mode, "incomplete instances = ", len(incomplete)

	# plot the figure
	f = plt.figure() # init the figure module
	fig = f.add_subplot(111)

	# generate the x-axis major ticks
	x_majorticks = np.arange(0, 1621, 200)
	x_majorticks[len(x_majorticks)-1] = 1620
	x_majorticks[0] = 1

	# generate the x-axis minor ticks
	x_minorticks = np.arange(0, 1621, 40)
	x_minorticks[0] = 1

	# generate the y-axis major ticks
	y_majorticks = np.arange(0, math.ceil(y[-1]), 1)
	y_majorticks=  np.append(y_majorticks, y[-1])

	# generate the y-axis minor ticks
	y_minorticks = np.arange(0, math.ceil(y[-1])+1, 0.2)

	# set the xlabel, ylabel, title, and plot
	fig.set_xlabel("Number of instances")
	fig.set_ylabel("Model checking time (in hours)")
	fig.set_title("Cumulative Model Checking Time for Extended Verification \n (excluding incomplete instances)")
	fig.plot(x,y, 'b-', label='heuristic 2') # plot the main data
	fig.plot([0, x[-1]], [y[-1], y[-1]], 'k--') # plot a line for the last data value
	fig.legend(loc='lower right')

	# set the major and minor ticks
	fig.set_xticks(x_majorticks)
	fig.set_xticks(x_minorticks, minor=True)
	fig.set_yticks(y_majorticks)
	fig.set_yticks(y_minorticks, minor = True)

	# enable the grid
	fig.grid(which='minor', alpha=0.2)                                                
	fig.grid(which='major', alpha=0.5) 

	# set the axis lengths and formatting of the ticks
	fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+0.2])
	fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

	# set the aspect ratio
	fig.set_aspect('auto')

	# save the figure
	f.savefig("fig27.pdf")


if __name__ == "__main__":
	main()
