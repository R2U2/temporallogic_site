# script to generate combined plots of original and heuristic 1 and heuristic 2
import matplotlib.pyplot as plt
from matplotlib.ticker import FormatStrFormatter
import numpy as np
import json
import math

def main():
  # open the result file for reading the original results
  data_file = open("collated_results_original.json", "r")

  # load the contents from the file, which creates a new directory
  data_original = json.load(data_file)
  data_file.close()

  # open the result file for reading the heuristic 1 results
  data_file = open("collated_results_heuristic1.json", "r")

  # load the contents from the file, which creates a new directory
  data_heuristic1 = json.load(data_file)
  data_file.close()

  # open the result file for reading the heuristic2 results
  # data_file = open("collated_results_heuristic1_heuristic2.json", "r")
  data_file = open("collated_results_heuristic2.json", "r")

  # load the contents from the file, which creates a new directory
  data_heuristic2 = json.load(data_file)
  data_file.close()

  # open the result file for reading the heuristic 1 + heuristic2 results
  # data_file = open("collated_results_heuristic1_heuristic2.json", "r")
  data_file = open("collated_results_heuristic1_heuristic2.json", "r")

  # load the contents from the file, which creates a new directory
  data_heuristic12 = json.load(data_file)
  data_file.close()

  # queries on data
  modes = ['airspace_validation', 'nominal_verification',\
        'nominal_validation', 'extended_validation',\
        'extended_verification']

  #############################################################
  #   QUERY:  Generate a cumulative time vs instances plot
  #       for mode = nominal_validation and don't include
  #       instances that did not complete.
  #   NAME: fig60.pdf
  #############################################################
  mode = modes[2] # set mode to nominal_validation

  # original
  x1 = [] # x-values. will store in the instance number
  y1 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_original.keys():
    instance_time = 0
    if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
        data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
          instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x1.append(ctr)
      y1.append(time)
    ctr = ctr + 1

  # print the incomplete instances
  # print mode, "incomplete instances = ", len(incomplete)

  # heuristic 1
  x2 = [] # x-values. will store in the instance number
  y2 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_heuristic1.keys():
    instance_time = 0
    if data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
        data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
          instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x2.append(ctr)
      y2.append(time)
    ctr = ctr + 1

  # heuristic 1 + heuristic 2
  x3 = [] # x-values. will store in the instance number
  y3 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 0.2
  ctr = 1
  for config in data_heuristic12.keys():
    instance_time = 0
    if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
          data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
            instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x3.append(ctr)
      y3.append(time)
    ctr = ctr + 1

  # heuristic 2
  x4 = [] # x-values. will store in the instance number
  y4 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 0.2
  ctr = 1
  for config in data_heuristic2.keys():
    instance_time = 0
    if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
          data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
            instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x4.append(ctr)
      y4.append(time)
    ctr = ctr + 1

  # plot the figure
  f = plt.figure() # init the figure module
  plt.rc('font', **{'size' : 26, 'family': 'serif', 'serif': ['Times']})
  plt.rc('text', usetex=True)
  plt.rcParams['xtick.major.size'] = 10
  plt.rcParams['xtick.major.width'] = 1
  plt.rcParams['xtick.minor.size'] = 5
  plt.rcParams['xtick.minor.width'] = 0.5
  plt.rcParams['ytick.major.size'] = 10
  plt.rcParams['ytick.major.width'] = 1
  plt.rcParams['ytick.minor.size'] = 5
  plt.rcParams['ytick.minor.width'] = 0.5
  fig = f.add_subplot(111)
  f.set_size_inches(8, 6)

  # generate the x-axis major ticks
  x_majorticks = np.arange(0, 1621, 400)
  x_majorticks[len(x_majorticks)-1] = 1620
  x_majorticks[0] = 1

  # generate the x-axis minor ticks
  x_minorticks = np.arange(0, 1621, 40)
  x_minorticks[0] = 1

  # generate the y-axis major ticks
  y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 4)
  y_majorticks=  np.append(y_majorticks, y1[-1])
  # y_majorticks=  np.append(y_majorticks, y2[-1])
  y_majorticks=  np.append(y_majorticks, y3[-1])
  # y_majorticks=  np.append(y_majorticks, y4[-1])

  # generate the y-axis minor ticks
  y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+1, 0.4)

  # set the xlabel, ylabel, title, and plot
  fig.set_xlabel("Number of configured instances (models)")
  fig.set_ylabel("Model checking time (in hours)")
  # fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
  # string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
  # fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
  fig.plot(x1,y1, '-bo', label='individual', markevery=(75, 150), markersize=16) # plot the main data
  fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
  fig.plot(x2,y2, '-rs', label=r'\textsc{GenPC}', markevery=(75, 150), markersize=16) # plot the main data
  # fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
  fig.plot(x4,y4, '-c^', label=r'\textsc{CheckRP}', markevery=150, markersize=16) # plot the main data
  # fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
  fig.plot(x3,y3, '-gd', label=r'\textsc{CMCR}', markevery=150, markersize=16) # plot the main data
  fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
  fig.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0., fontsize=24)

  # set the major and minor ticks
  fig.set_xticks(x_majorticks)
  fig.set_xticks(x_minorticks, minor=True)
  fig.set_yticks(y_majorticks)
  fig.set_yticks(y_minorticks, minor = True)

  # enable the grid
  fig.grid(which='minor', alpha=0.1)
  fig.grid(which='major', alpha=0.3)

  # set the axis lengths and formatting of the ticks
  fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+1])
  fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

  # set the aspect ratio
  fig.set_aspect('auto')

  # save the figure
  f.savefig("fig60.pdf", bbox_inches='tight')


  #############################################################
  #   QUERY:  Generate a cumulative time vs instances plot
  #       for mode = extended_validation and don't include
  #       instances that did not complete.
  #   NAME: fig61.pdf
  #############################################################
  mode = modes[3] # set mode to extended_validation

  # original
  x1 = [] # x-values. will store in the instance number
  y1 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_original.keys():
    instance_time = 0
    if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
        data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
          instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x1.append(ctr)
      y1.append(time)
    ctr = ctr + 1

  # print the incomplete instances
  # print mode, "incomplete instances = ", len(incomplete)

  # heuristic 1
  x2 = [] # x-values. will store in the instance number
  y2 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_heuristic1.keys():
    instance_time = 0
    if data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
        data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
          instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x2.append(ctr)
      y2.append(time)
    ctr = ctr + 1

  # heuristic 1 + heuristic 2
  x3 = [] # x-values. will store in the instance number
  y3 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 1.5
  ctr = 1
  for config in data_heuristic12.keys():
    instance_time = 0
    if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
          data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
            instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x3.append(ctr)
      y3.append(time)
    ctr = ctr + 1

  # heuristic 2
  x4 = [] # x-values. will store in the instance number
  y4 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 1.5
  ctr = 1
  for config in data_heuristic2.keys():
    instance_time = 0
    if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
          data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
            instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x4.append(ctr)
      y4.append(time)
    ctr = ctr + 1

  # plot the figure
  f = plt.figure() # init the figure module
  plt.rc('font', **{'size':26,'family': 'serif', 'serif': ['Times']})
  plt.rc('text', usetex=True)
  plt.rcParams['xtick.major.size'] = 10
  plt.rcParams['xtick.major.width'] = 1
  plt.rcParams['xtick.minor.size'] = 5
  plt.rcParams['xtick.minor.width'] = 0.5
  plt.rcParams['ytick.major.size'] = 10
  plt.rcParams['ytick.major.width'] = 1
  plt.rcParams['ytick.minor.size'] = 5
  plt.rcParams['ytick.minor.width'] = 0.5
  fig = f.add_subplot(111)
  f.set_size_inches(8, 6)

  # generate the x-axis major ticks
  x_majorticks = np.arange(0, 1621, 400)
  x_majorticks[len(x_majorticks)-1] = 1620
  x_majorticks[0] = 1

  # generate the x-axis minor ticks
  x_minorticks = np.arange(0, 1621, 40)
  x_minorticks[0] = 1

  # generate the y-axis major ticks
  y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 30)
  y_majorticks =  np.append(y_majorticks, y1[-1])
  # y_majorticks=  np.append(y_majorticks, y2[-1])
  y_majorticks =  np.append(y_majorticks, y3[-1])
  # y_majorticks=  np.append(y_majorticks, y4[-1])

  # generate the y-axis minor ticks
  y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+50, 3)
  print y_majorticks
  print y_minorticks

  # set the xlabel, ylabel, title, and plot
  fig.set_xlabel("Number of configured instances (models)")
  fig.set_ylabel("Model checking time (in hours)")
  # fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
  # string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
  # fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
  fig.plot(x1,y1, '-bo', label='individual', markevery=(75, 150), markersize=16) # plot the main data
  fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
  fig.plot(x2,y2, '-rs', label=r'\textsc{GenPC}', markevery=(75, 150), markersize=16) # plot the main data
  # fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
  fig.plot(x4,y4, '-c^', label=r'\textsc{CheckRP}', markevery=150, markersize=16) # plot the main data
  # fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
  fig.plot(x3,y3, '-gd', label=r'\textsc{CMCR}', markevery=150, markersize=16) # plot the main data
  fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
  fig.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0., fontsize=24)

  # set the major and minor ticks
  fig.set_xticks(x_majorticks)
  fig.set_xticks(x_minorticks, minor=True)
  fig.set_yticks(y_majorticks)
  fig.set_yticks(y_minorticks, minor = True)

  # # enable the grid
  fig.grid(which='minor', alpha=0.1)
  fig.grid(which='major', alpha=0.3)

  # set the axis lengths and formatting of the ticks
  fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+10])
  fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

  # set the aspect ratio
  fig.set_aspect('auto')

  # save the figure
  f.savefig("fig61.pdf", bbox_inches='tight')

  #############################################################
  #   QUERY:  Generate a cumulative time vs instances plot
  #       for mode = nominal_verification and don't include
  #       instances that did not complete.
  #   NAME: fig62.pdf
  #############################################################
  mode = modes[1] # set mode to nominal_verification

  # original
  x1 = [] # x-values. will store in the instance number
  y1 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_original.keys():
    instance_time = 0
    if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x1.append(ctr)
      y1.append(time)
    ctr = ctr + 1

  # print the incomplete instances
  # print mode, "incomplete instances = ", len(incomplete)

  # heuristic 1
  x2 = [] # x-values. will store in the instance number
  y2 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_heuristic1.keys():
    instance_time = 0
    if data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x2.append(ctr)
      y2.append(time)
    ctr = ctr + 1

  # heuristic 1 + heuristic 2
  x3 = [] # x-values. will store in the instance number
  y3 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 0.9
  ctr = 1
  for config in data_heuristic12.keys():
    instance_time = 0
    if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x3.append(ctr)
      y3.append(time)
    ctr = ctr + 1

  # heuristic 2
  x4 = [] # x-values. will store in the instance number
  y4 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 0.9
  ctr = 1
  for config in data_heuristic2.keys():
    instance_time = 0
    if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x4.append(ctr)
      y4.append(time)
    ctr = ctr + 1

  # plot the figure
  f = plt.figure() # init the figure module
  plt.rc('font', **{'size':26,'family': 'serif', 'serif': ['Times']})
  plt.rc('text', usetex=True)
  plt.rcParams['xtick.major.size'] = 10
  plt.rcParams['xtick.major.width'] = 1
  plt.rcParams['xtick.minor.size'] = 5
  plt.rcParams['xtick.minor.width'] = 0.5
  plt.rcParams['ytick.major.size'] = 10
  plt.rcParams['ytick.major.width'] = 1
  plt.rcParams['ytick.minor.size'] = 5
  plt.rcParams['ytick.minor.width'] = 0.5
  fig = f.add_subplot(111)
  f.set_size_inches(8, 6)


  # generate the x-axis major ticks
  x_majorticks = np.arange(0, 1621, 400)
  x_majorticks[len(x_majorticks)-1] = 1620
  x_majorticks[0] = 1

  # generate the x-axis minor ticks
  x_minorticks = np.arange(0, 1621, 40)
  x_minorticks[0] = 1

  # generate the y-axis major ticks
  y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 7)
  y_majorticks[-2] =  y3[-1]
  y_majorticks =  np.append(y_majorticks, y1[-1])
  # y_majorticks =  np.append(y_majorticks, y3[-1])
  # y_majorticks=  np.append(y_majorticks, y4[-1])

  # generate the y-axis minor ticks
  y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+4, 1)
  print y_majorticks
  print y_minorticks

  # set the xlabel, ylabel, title, and plot
  fig.set_xlabel("Number of configured instances (models)")
  fig.set_ylabel("Model checking time (in hours)")
  # fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
  # string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
  # fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
  fig.plot(x1,y1, '-bo', label='individual', markevery=(75, 150), markersize=16) # plot the main data
  fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
  fig.plot(x2,y2, '-rs', label=r'\textsc{GenPC}', markevery=(75, 150), markersize=16) # plot the main data
  # fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
  fig.plot(x4,y4, '-c^', label=r'\textsc{CheckRP}', markevery=150, markersize=16) # plot the main data
  # fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
  fig.plot(x3,y3, '-gd', label=r'\textsc{CMCR}', markevery=150, markersize=16) # plot the main data
  fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
  fig.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0., fontsize=24)

  # set the major and minor ticks
  fig.set_xticks(x_majorticks)
  fig.set_xticks(x_minorticks, minor=True)
  fig.set_yticks(y_majorticks)
  fig.set_yticks(y_minorticks, minor = True)

  # # enable the grid
  fig.grid(which='minor', alpha=0.1)
  fig.grid(which='major', alpha=0.3)

  # set the axis lengths and formatting of the ticks
  fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+2])
  fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

  # set the aspect ratio
  fig.set_aspect('auto')

  # save the figure
  f.savefig("fig62.pdf", bbox_inches='tight')

  #############################################################
  #   QUERY:  Generate a cumulative time vs instances plot
  #       for mode = extended verification and don't include
  #       instances that did not complete.
  #   NAME: fig63.pdf
  #############################################################
  mode = modes[4] # set mode to extended_verification

  # original
  x1 = [] # x-values. will store in the instance number
  y1 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_original.keys():
    instance_time = 0
    if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x1.append(ctr)
      y1.append(time)
    ctr = ctr + 1

  # print the incomplete instances
  # print mode, "incomplete instances = ", len(incomplete)

  # heuristic 1
  x2 = [] # x-values. will store in the instance number
  y2 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_heuristic1.keys():
    instance_time = 0
    if data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x2.append(ctr)
      y2.append(time)
    ctr = ctr + 1

  # heuristic 1 + heuristic 2
  x3 = [] # x-values. will store in the instance number
  y3 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 0.9
  ctr = 1
  for config in data_heuristic12.keys():
    instance_time = 0
    if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x3.append(ctr)
      y3.append(time)
    ctr = ctr + 1

  # heuristic 2
  x4 = [] # x-values. will store in the instance number
  y4 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 0.9
  ctr = 1
  for config in data_heuristic2.keys():
    instance_time = 0
    if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x4.append(ctr)
      y4.append(time)
    ctr = ctr + 1

  # plot the figure
  f = plt.figure() # init the figure module
  plt.rc('font', **{'size':26,'family': 'serif', 'serif': ['Times']})
  plt.rc('text', usetex=True)
  plt.rcParams['xtick.major.size'] = 10
  plt.rcParams['xtick.major.width'] = 1
  plt.rcParams['xtick.minor.size'] = 5
  plt.rcParams['xtick.minor.width'] = 0.5
  plt.rcParams['ytick.major.size'] = 10
  plt.rcParams['ytick.major.width'] = 1
  plt.rcParams['ytick.minor.size'] = 5
  plt.rcParams['ytick.minor.width'] = 0.5
  fig = f.add_subplot(111)
  f.set_size_inches(8, 6)

  # generate the x-axis major ticks
  x_majorticks = np.arange(0, 1621, 400)
  x_majorticks[len(x_majorticks)-1] = 1620
  x_majorticks[0] = 1

  # generate the x-axis minor ticks
  x_minorticks = np.arange(0, 1621, 40)
  x_minorticks[0] = 1

  # generate the y-axis major ticks
  y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 10)
  y_majorticks[-1] = y1[-1]
  # y_majorticks =  np.append(y_majorticks, y1[-1])
  y_majorticks =  np.append(y_majorticks, y3[-1])
  # y_majorticks[-2] =  y3[-1]
  # y_majorticks=  np.append(y_majorticks, y4[-1])

  # generate the y-axis minor ticks
  y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+4, 1)
  print y_majorticks
  print y_minorticks

  # set the xlabel, ylabel, title, and plot
  fig.set_xlabel("Number of configured instances (models)")
  fig.set_ylabel("Model checking time (in hours)")
  # fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
  # string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
  # fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
  fig.plot(x1,y1, '-bo', label='individual', markevery=(75, 150), markersize=16) # plot the main data
  fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
  fig.plot(x2,y2, '-rs', label=r'\textsc{GenPC}', markevery=(75, 150), markersize=16) # plot the main data
  # fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
  fig.plot(x4,y4, '-c^', label=r'\textsc{CheckRP}', markevery=150, markersize=16) # plot the main data
  # fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
  fig.plot(x3,y3, '-gd', label=r'\textsc{CMCR}', markevery=150, markersize=16) # plot the main data
  fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
  fig.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0., fontsize=24)

  # set the major and minor ticks
  fig.set_xticks(x_majorticks)
  fig.set_xticks(x_minorticks, minor=True)
  fig.set_yticks(y_majorticks)
  fig.set_yticks(y_minorticks, minor = True)

  # # enable the grid
  fig.grid(which='minor', alpha=0.1)
  fig.grid(which='major', alpha=0.3)

  # set the axis lengths and formatting of the ticks
  fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+3])
  fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

  # set the aspect ratio
  fig.set_aspect('auto')

  # save the figure
  f.savefig("fig63.pdf", bbox_inches='tight')

    #############################################################
  #   QUERY:  Generate a cumulative time vs instances plot
  #       for mode = airspace validation and don't include
  #       instances that did not complete.
  #   NAME: fig64.pdf
  #############################################################
  mode = modes[0] # set mode to airspace_validation

  # original
  x1 = [] # x-values. will store in the instance number
  y1 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_original.keys():
    instance_time = 0
    if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
        data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
          instance_time += data_original[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x1.append(ctr)
      y1.append(time)
    ctr = ctr + 1

  # print the incomplete instances
  # print mode, "incomplete instances = ", len(incomplete)

  # heuristic 1
  x2 = [] # x-values. will store in the instance number
  y2 = [] # y-values. will store the cumulative time
  incomplete = []

  time = 0
  ctr = 1
  for config in data_heuristic1.keys():
    instance_time = 0
    if data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
        data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
          instance_time += data_heuristic1[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x2.append(ctr)
      y2.append(time)
    ctr = ctr + 1

  # heuristic 1 + heuristic 2
  x3 = [] # x-values. will store in the instance number
  y3 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 0.2
  ctr = 1
  for config in data_heuristic12.keys():
    instance_time = 0
    if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          if data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
          data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
            instance_time += data_heuristic12[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x3.append(ctr)
      y3.append(time)
    ctr = ctr + 1

  # heuristic 2
  x4 = [] # x-values. will store in the instance number
  y4 = [] # y-values. will store the cumulative time
  incomplete = []

  # print "Total instances: ", len(data)
  time = 0.2
  ctr = 1
  for config in data_heuristic2.keys():
    instance_time = 0
    if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'complete'] == False:
      incomplete.append(config)
    else:
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'read_model_time']
      # instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'build_model_time']
      for prop in range(len(data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")][u'properties'])):
        if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'h2'] == True:
          if data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'ltl' or \
          data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'type'] == 'invar':
            instance_time += data_heuristic2[unicode(str(config), "utf-8")][unicode(mode, "utf-8")]['properties'][prop][u'time']
      time = time + (instance_time/3600)
      x4.append(ctr)
      y4.append(time)
    ctr = ctr + 1

  # plot the figure
  f = plt.figure() # init the figure module
  plt.rc('font', **{'size':26,'family': 'serif', 'serif': ['Times']})
  plt.rc('text', usetex=True)
  plt.rcParams['xtick.major.size'] = 10
  plt.rcParams['xtick.major.width'] = 1
  plt.rcParams['xtick.minor.size'] = 5
  plt.rcParams['xtick.minor.width'] = 0.5
  plt.rcParams['ytick.major.size'] = 10
  plt.rcParams['ytick.major.width'] = 1
  plt.rcParams['ytick.minor.size'] = 5
  plt.rcParams['ytick.minor.width'] = 0.5
  fig = f.add_subplot(111)
  f.set_size_inches(8, 6)

  # generate the x-axis major ticks
  x_majorticks = np.arange(0, 1621, 400)
  x_majorticks[len(x_majorticks)-1] = 1620
  x_majorticks[0] = 1

  # generate the x-axis minor ticks
  x_minorticks = np.arange(0, 1621, 40)
  x_minorticks[0] = 1

  # generate the y-axis major ticks
  y_majorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1])), 2)
  y_majorticks[-1] = y1[-1]
  # y_majorticks =  np.append(y_majorticks, y1[-1])
  # y_majorticks =  np.append(y_majorticks, y3[-1])
  y_majorticks[-2] =  y3[-1]
  # y_majorticks=  np.append(y_majorticks, y4[-1])

  # generate the y-axis minor ticks
  y_minorticks = np.arange(0, max(math.ceil(y1[-1]), math.ceil(y2[-1]), math.ceil(y3[-1]), math.ceil(y4[-1]))+1, 0.2)
  print y_majorticks
  print y_minorticks

  # set the xlabel, ylabel, title, and plot
  fig.set_xlabel("Number of configured instances (models)")
  fig.set_ylabel("Model checking time (in hours)")
  # fig.set_title("Cumulative Model Checking Time for Nominal Verification \n (excluding incomplete instances)")
  # string = str(len(incomplete)) + " of 1620 did not complete\nwithin 24 hours"
  # fig.text(0.3, 0.9, string, horizontalalignment='center', verticalalignment='top', multialignment='center', transform=fig.transAxes)
  fig.plot(x1,y1, '-bo', label='individual', markevery=(75, 150), markersize=16) # plot the main data
  fig.plot([0, x1[-1]], [y1[-1], y1[-1]], 'k--') # plot a line for the last data value
  fig.plot(x2,y2, '-rs', label=r'\textsc{GenPC}', markevery=(75, 150), markersize=16) # plot the main data
  # fig.plot([0, x2[-1]], [y2[-1], y2[-1]], 'k--') # plot a line for the last data value
  fig.plot(x4,y4, '-c^', label=r'\textsc{CheckRP}', markevery=150, markersize=16) # plot the main data
  # fig.plot([0, x4[-1]], [y4[-1], y4[-1]], 'k--') # plot a line for the last data value
  fig.plot(x3,y3, '-gd', label=r'\textsc{CMCR}', markevery=150, markersize=16) # plot the main data
  fig.plot([0, x3[-1]], [y3[-1], y3[-1]], 'k--') # plot a line for the last data value
  fig.legend(bbox_to_anchor=(0., 1.02, 1., .102), loc=3, ncol=2, mode="expand", borderaxespad=0., fontsize=24)

  # set the major and minor ticks
  fig.set_xticks(x_majorticks)
  fig.set_xticks(x_minorticks, minor=True)
  fig.set_yticks(y_majorticks)
  fig.set_yticks(y_minorticks, minor = True)

  # # enable the grid
  fig.grid(which='minor', alpha=0.1)
  fig.grid(which='major', alpha=0.3)

  # set the axis lengths and formatting of the ticks
  fig.axis([1, np.amax(x_majorticks), 0, np.amax(y_majorticks)+0.5])
  fig.yaxis.set_major_formatter(FormatStrFormatter('%.2f'))

  # set the aspect ratio
  fig.set_aspect('auto')

  # save the figure
  f.savefig("fig64.pdf", bbox_inches='tight')



if __name__ == "__main__":
  main()