#ifdef __SSEPATCINFO_H__
#define __SSEPATCINFO_H__
/* Define how much information is shared btw SSEP and GSEP */
#ifdef SSEP_ATC_INFO_NONE
#define CONF_SSEP_ATC_INFO_LEVEL 0
#endif

#ifdef SSEP_ATC_INFO_CURRENT
#define CONF_SSEP_ATC_INFO_LEVEL 1
#endif

#ifdef SSEP_ATC_INFO_NEAR
#define CONF_SSEP_ATC_INFO_LEVEL 2
#endif

#ifdef SSEP_ATC_INFO_MID
#define CONF_SSEP_ATC_INFO_LEVEL 3
#endif

#ifdef SSEP_ATC_INFO_FAR
#define CONF_SSEP_ATC_INFO_LEVEL 4
#endif

#ifndef CONF_SSEP_ATC_INFO_LEVEL
#error "SSEP_ATC_INFO_LEVEL was not defined"
#endif
#endif