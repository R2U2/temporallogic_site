#ifndef CONF_BURDENING_RULE
 If BURDENING_RULE is undefined, then we need to explicitely say it,
   by setting BURDEN_UNDEF. Otherwise, we throw an error. 
#error "BURDENING_RULE was not defined"
#endif