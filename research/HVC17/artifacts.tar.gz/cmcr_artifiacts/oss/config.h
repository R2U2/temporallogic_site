#ifndef __CONFIG_H__
#define __CONFIG_H__

/* Define how much information is shared btw GSEP and SSEP */
#ifdef GSEP_SSEP_INFO_NONE
#define CONF_GSEP_SSEP_INFO_LEVEL 0
#endif

#ifdef GSEP_SSEP_INFO_CURRENT
#define CONF_GSEP_SSEP_INFO_LEVEL 1
#endif

#ifdef GSEP_SSEP_INFO_NEAR
#define CONF_GSEP_SSEP_INFO_LEVEL 2
#endif

#ifdef GSEP_SSEP_INFO_MID
#define CONF_GSEP_SSEP_INFO_LEVEL 3
#endif

#ifdef GSEP_SSEP_INFO_FAR
#define CONF_GSEP_SSEP_INFO_LEVEL 4
#endif

#ifndef CONF_GSEP_SSEP_INFO_LEVEL
#error "GSEP_SSEP_INFO_LEVEL was not defined"
#endif


/* Define how much information is shared btw SSEP and GSEP */
#ifdef SSEP_ATC_INFO_NONE
#define CONF_SSEP_ATC_INFO_LEVEL 0
#endif

#ifdef SSEP_ATC_INFO_CURRENT
#define CONF_SSEP_ATC_INFO_LEVEL 1
#endif

#ifdef SSEP_ATC_INFO_NEAR
#define CONF_SSEP_ATC_INFO_LEVEL 2
#endif

#ifdef SSEP_ATC_INFO_MID
#define CONF_SSEP_ATC_INFO_LEVEL 3
#endif

#ifdef SSEP_ATC_INFO_FAR
#define CONF_SSEP_ATC_INFO_LEVEL 4
#endif

#ifndef CONF_SSEP_ATC_INFO_LEVEL
#error "SSEP_ATC_INFO_LEVEL was not defined"
#endif

/* Define who is responsible for Separation Assurance of the SSEPs */

#ifdef SSEP_SA_ATC_ATC
#define CONF_SSEP_TS_SA SA_ATC
#define CONF_SSEP_SS_SA SA_ATC
#endif

#ifdef SSEP_SA_ATC_SELF
#define CONF_SSEP_TS_SA SA_ATC
#define CONF_SSEP_SS_SA SA_SELF
#endif

#ifdef SSEP_SA_SELF_ATC
#define CONF_SSEP_TS_SA SA_SELF
#define CONF_SSEP_SS_SA SA_ATC
#endif

#ifdef SSEP_SA_SELF_SELF
#define CONF_SSEP_TS_SA SA_SELF
#define CONF_SSEP_SS_SA SA_SELF
#endif

#ifdef SSEP_SA_SELF_SATC
#define CONF_SSEP_TS_SA SA_SELF
#define CONF_SSEP_SS_SA SA_SATC
#endif

#ifdef SSEP_SA_SATC_SELF
#define CONF_SSEP_TS_SA SA_SATC
#define CONF_SSEP_SS_SA SA_SELF
#endif

#ifdef SSEP_SA_SATC_SATC
#define CONF_SSEP_TS_SA SA_SATC
#define CONF_SSEP_SS_SA SA_SATC
#endif

#ifdef SSEP_SA_ATC_SATC
#define CONF_SSEP_TS_SA SA_ATC
#define CONF_SSEP_SS_SA SA_SATC
#endif

#ifdef SSEP_SA_SATC_ATC
#define CONF_SSEP_TS_SA SA_SATC
#define CONF_SSEP_SS_SA SA_ATC
#endif


#ifndef CONF_SSEP_TS_SA
#error "SSEP_TS_SA was not defined"
#endif

#ifndef CONF_SSEP_SS_SA
#error "SSEP_SS_SA was not defined"
#endif

/* get ride of the line CONF_ACDR */
#define CONF_ACDR --

/* Define the burdening rules */

#ifdef BURDEN_SSEP
#define BURDENING_RULE B_SSEP
#endif

#ifdef BURDEN_GSEP
#define BURDENING_RULE B_GSEP
#endif

#ifndef BURDENING_RULE
/* If BURDENING_RULE is undefined, then we need to explicitely say it,
   by setting BURDEN_UNDEF. Otherwise, we throw an error. */
#ifndef BURDEN_UNDEF
#error "BURDENING_RULE was not defined"
#endif
#endif

#endif /* __CONFIG_H__ */
