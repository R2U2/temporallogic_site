#ifndef __GSEPSSEPINFO_H__
#define __GSEPSSEPINFO_H__

/* Define how much information is shared btw GSEP and SSEP */
#ifdef GSEP_SSEP_INFO_NONE
#define CONF_GSEP_SSEP_INFO_LEVEL 0
#endif

#ifdef GSEP_SSEP_INFO_CURRENT
#define CONF_GSEP_SSEP_INFO_LEVEL 1
#endif

#ifdef GSEP_SSEP_INFO_NEAR
#define CONF_GSEP_SSEP_INFO_LEVEL 2
#endif

#ifdef GSEP_SSEP_INFO_MID
#define CONF_GSEP_SSEP_INFO_LEVEL 3
#endif

#ifdef GSEP_SSEP_INFO_FAR
#define CONF_GSEP_SSEP_INFO_LEVEL 4
#endif

#ifndef CONF_GSEP_SSEP_INFO_LEVEL
#error "GSEP_SSEP_INFO_LEVEL was not defined"
#endif

#endif