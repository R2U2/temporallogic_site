#ifndef __HEADER_H__
#define __HEADER_H__

/* Trajectories data-type definition */
#define TRJ_TYPE 0..4
#define TRJ_NOP 0
#define AC_ID_TYPE 1..4

/* Macros to check if trajectories are different */
#define DIFFERENT_FROM(ac, ac1, ac2, ac3) \
((ac != ac1) & (ac != ac2) & (ac != ac3))

#define DIFFERENT_FROM_4(ac, ac1, ac2, ac3, ac4)            \
((ac != ac1) & (ac != ac2) & (ac != ac3) & (ac != ac4))

#define ALL_DIFFERENT(ac1, ac2, ac3, ac4) \
((ac1 != ac2) & (ac1 != ac3) & (ac1 != ac4) &        \
 (ac2 != ac3) & (ac2 != ac4) & \
 (ac3 != ac4))

#define ALL_DIFFERENT_WNOP(ac1, ac2, ac3, ac4)     \
  ((ac1 = TRJ_NOP ? TRUE : ( (ac1 != ac2) & (ac1 != ac3) & (ac1 != ac4))) & \
   (ac2 = TRJ_NOP ? TRUE : ( (ac2 != ac3) & (ac2 != ac4))) &             \
   (ac3 = TRJ_NOP ? TRUE : ( (ac3 != ac4) )))

/* Assign next(target) to value if value is not TRJ_NOP, otherwise
   maintain its value. */
#define ASSIGN_NEXT_IF_NOT_NOP(target, value) \
  (next(target) = ((value = TRJ_NOP) ? (target) : (value)))


#define DEFAULT_IF_NOP(var, default_val) \
  ((var = TRJ_NOP) ? (default_val) : (var))


#define INFO_LEVEL_TYPE 0 .. 4
#define INFO_LEVEL_NONE 0
#define INFO_LEVEL_CURRENT 1
#define INFO_LEVEL_NEAR 2
#define INFO_LEVEL_MID 3
#define INFO_LEVEL_FAR 4

/* Defines who is in charge of Separation Assurance */
#define SA_TYPE 0 .. 2
#define SA_ATC 0
#define SA_SELF 1
#define SA_SATC 2

#define B_TYPE 0..1
#define B_SSEP 0
#define B_GSEP 1

#define MAX_COM_STEPS 3
#define MAX_CONSECUTIVE_FAULTS 3

#define ENABLE_FAULTS_COUNT 0

#endif /* __HEADER_H__ */
