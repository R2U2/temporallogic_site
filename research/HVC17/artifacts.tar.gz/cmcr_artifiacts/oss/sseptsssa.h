#ifdef SSEP_SA_ATC_ATC
#define CONF_SSEP_TS_SA SA_ATC
#define CONF_SSEP_SS_SA SA_ATC
#endif

#ifdef SSEP_SA_ATC_SELF
#define CONF_SSEP_TS_SA SA_ATC
#define CONF_SSEP_SS_SA SA_SELF
#endif

#ifdef SSEP_SA_SELF_ATC
#define CONF_SSEP_TS_SA SA_SELF
#define CONF_SSEP_SS_SA SA_ATC
#endif

#ifdef SSEP_SA_SELF_SELF
#define CONF_SSEP_TS_SA SA_SELF
#define CONF_SSEP_SS_SA SA_SELF
#endif

#ifdef SSEP_SA_SELF_SATC
#define CONF_SSEP_TS_SA SA_SELF
#define CONF_SSEP_SS_SA SA_SATC
#endif

#ifdef SSEP_SA_SATC_SELF
#define CONF_SSEP_TS_SA SA_SATC
#define CONF_SSEP_SS_SA SA_SELF
#endif

#ifdef SSEP_SA_SATC_SATC
#define CONF_SSEP_TS_SA SA_SATC
#define CONF_SSEP_SS_SA SA_SATC
#endif

#ifdef SSEP_SA_ATC_SATC
#define CONF_SSEP_TS_SA SA_ATC
#define CONF_SSEP_SS_SA SA_SATC
#endif

#ifdef SSEP_SA_SATC_ATC
#define CONF_SSEP_TS_SA SA_SATC
#define CONF_SSEP_SS_SA SA_ATC
#endif


#ifndef CONF_SSEP_TS_SA
#error "SSEP_TS_SA was not defined"
#endif

#ifndef CONF_SSEP_SS_SA
#error "SSEP_SS_SA was not defined"
#endif