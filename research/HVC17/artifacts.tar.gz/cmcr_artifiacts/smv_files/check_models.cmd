set on_failure_script_quits 1
set pp_list "cpp"
set dynamic_reorder

#
# Dummy
#

echo "Dummy ACDR"
read_model -i dummy/ACDR.smv
go
check_fsm
compute_reachable
reset

echo "Dummy GCDR"
read_model -i dummy/GCDR.smv
go
check_fsm
compute_reachable
reset

echo "Dummy Operator"
read_model -i dummy/Operator.smv
go
check_fsm
compute_reachable
reset

echo "Dummy ProtocolPolicy"
read_model -i dummy/ProtocolPolicy.smv
go
check_fsm
compute_reachable
reset


#
# Nominal
#
echo "Nominal ACDR"
read_model -i nominal/ACDR.smv
go
check_fsm
compute_reachable
reset

echo "Nominal ACDR_simple"
read_model -i nominal/ACDR_simple.smv
go
check_fsm
compute_reachable
reset

echo "Nominal ACDR_nonreceptive"
read_model -i nominal/ACDR_nonreceptive.smv
go
check_fsm
compute_reachable
reset


echo "Nominal ADSBIn"
read_model -i nominal/ADSBIn.smv
go
check_fsm
compute_reachable
reset


echo "Nominal ADSBNet"
read_model -i nominal/ADSBNet.smv
go
check_fsm
compute_reachable
reset

echo "Nominal CommunicationLayer"
read_model -i nominal/CommunicationLayer.smv
go
check_fsm
compute_reachable
reset

echo "Nominal GCDR"
read_model -i nominal/GCDR.smv
go_bmc
reset

echo "Nominal Operator"
read_model -i nominal/Operator.smv
go
check_fsm
compute_reachable
reset

echo "Nominal ProtocolPolicy"
read_model -i nominal/ProtocolPolicy.smv
go
check_fsm
compute_reachable
reset

echo "Nominal RouteManager"
read_model -i nominal/RouteManager.smv
go
check_fsm
compute_reachable
reset

#
# Extended
#
echo "Extended ACDR"
read_model -i extended/ACDR.smv
go
check_fsm
compute_reachable
reset

echo "Extended ACDR_simple"
read_model -i extended/ACDR_simple.smv
go
check_fsm
compute_reachable
reset


echo "Extended ADSBIn"
read_model -i extended/ADSBIn.smv
go
check_fsm
compute_reachable
reset


echo "Extended ADSBNet"
read_model -i extended/ADSBNet.smv
go
check_fsm
compute_reachable
reset

echo "Extended CommunicationLayer"
read_model -i extended/CommunicationLayer.smv
go
check_fsm
compute_reachable
reset

echo "Extended GCDR (BMC Only)"
read_model -i nominal/GCDR.smv
go_bmc
reset

echo "Extended ProtocolPolicy"
read_model -i extended/ProtocolPolicy.smv
go
check_fsm
compute_reachable
reset

echo "Extended RouteManager"
read_model -i extended/RouteManager.smv
go
check_fsm
compute_reachable
reset


quit