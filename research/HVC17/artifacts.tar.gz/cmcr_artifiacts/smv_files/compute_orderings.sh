#!/bin/bash

cd extended
for i in `ls *.smv`
do
    echo $i
    echo "go;compute_reachable;write_order -o $i.ord;quit" | ~/nasa/esmc -cpp -dynamic -int $i
done

cd ../nominal
for i in `ls *.smv`
do
    echo $i
    echo "go;compute_reachable;write_order -o $i.ord;quit" | ~/nasa/esmc -cpp -dynamic -int $i
done
